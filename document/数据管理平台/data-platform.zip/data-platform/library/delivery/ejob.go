package delivery

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"time"

	"icode.baidu.com/baidu/gdp/codec"
	"icode.baidu.com/baidu/gdp/ghttp"
	"icode.baidu.com/baidu/gdp/net/ral"
)

type Ejob struct {
	JobName        string
	JobID          string
	UserParams     map[string]any
	CallbackURL    string
	CallbackParams map[string]any
	Package        string

	postBody map[string]any

	command string
}

func NewEjob() *Ejob {
	return &Ejob{}
}

func (e *Ejob) WithJobName(name string) *Ejob {
	e.JobName = name
	return e
}

func (e *Ejob) WithJobID(id string) *Ejob {
	e.JobID = id
	return e
}

func (e *Ejob) WithUserParams(params map[string]any) *Ejob {
	e.UserParams = params
	return e
}

func (e *Ejob) WithCallbackURL(url string) *Ejob {
	e.CallbackURL = url
	return e
}

func (e *Ejob) WithCallbackParams(params map[string]any) *Ejob {
	e.CallbackParams = params
	return e
}

func (e *Ejob) WithPostBody(body map[string]any) *Ejob {
	e.postBody = body
	return e
}

func (e *Ejob) WithPackage(p string) *Ejob {
	e.Package = p
	return e
}

func (e *Ejob) WithCommand(cmd string) *Ejob {
	e.command = cmd
	return e
}

type ejobResponse struct {
	Status  int    `json:"status"`
	Message string `json:"msg"`
}

func (e *Ejob) SetCommand(command string) {
	e.command = command
}

func (e *Ejob) Send(ctx context.Context) error {
	hd := http.Header{}
	hd.Add("Content-Type", "application/json")

	req := &ghttp.RalRequest{
		Method: "POST",
		Path:   "/ejob",
		Header: hd,
	}
	err := e.params()
	if err != nil {
		return err
	}
	err = req.WithBody(e.postBody, codec.JSONEncoder)
	if err != nil {
		return err
	}
	ralResp := &ghttp.RalResponse{}
	if err := ral.RAL(ctx, "ral_ejob_platform", req, ralResp); err != nil {
		return fmt.Errorf("request ejob platform failed: %w", err)
	}
	rawResp := ralResp.Response()
	defer rawResp.Body.Close()
	rep, _ := io.ReadAll(rawResp.Body)
	resUserInfo := ejobResponse{}
	err = json.Unmarshal(rep, &resUserInfo)
	if err != nil {
		return fmt.Errorf("unmarshal job resp failed: %w", err)
	}
	if resUserInfo.Status == 0 {
		return nil
	}
	return fmt.Errorf("job send failed, %s", string(rep))
}

func (e *Ejob) params() error {
	icodePackage := "baidu/ps-se/operation-etl"
	// icodePackage :=  "ftp://work:yandong123@yandong03-2020.bcc-bdbl.baidu.com://home/work/Codes/baidu/ps-se/operation-etl/output/package.tar.gz"
	if e.Package != "" {
		icodePackage = e.Package
	}
	nowTime := time.Now()
	body := make(map[string]any)
	body["job_id"] = e.JobID
	body["pdb"] = "sdata"
	body["job_name"] = e.JobName
	body["force_start"] = true
	body["owner"] = "yandong03"
	body["retry_count"] = 1
	body["package"] = icodePackage
	userParamsBytes, err := json.Marshal(e.UserParams)
	if err != nil {
		return err
	}
	params := map[string]any{
		"ROUTINE_TYPE": "NONE",
		"HOUR":         fmt.Sprintf("%d", nowTime.Hour()),
		"MONTH":        nowTime.Format("01"),
		"DAY":          fmt.Sprintf("%d", nowTime.Day()),
		"MINUTE":       fmt.Sprintf("%d", nowTime.Minute()),
		"SECOND":       fmt.Sprintf("%d", nowTime.Second()),
		"YEAR":         fmt.Sprintf("%d", nowTime.Year()),
		"DATE":         nowTime.Format("20060102"),
		"OWNER":        "yandong03",
		"user_params":  string(userParamsBytes),
	}
	content := map[string]any{
		"dependency": make([]string, 0),
		"cb_url":     e.CallbackURL,
		"cb_params":  e.CallbackParams,
		"command":    "cd sdata_deliver && sh run.sh",
		"params":     params,
	}
	if e.command != "" {
		content["command"] = e.command
	}
	body["job_content"] = content
	e.postBody = body
	return nil
}
