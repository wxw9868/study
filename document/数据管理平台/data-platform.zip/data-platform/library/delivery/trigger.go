/*
 * @Author: yandong03 yandong03@baidu.com
 * @Date: 2024-08-01 16:39:43
 * @LastEditors: yandong03 yandong03@baidu.com
 * @LastEditTime: 2024-08-05 10:19:09
 * @FilePath: /data-platform/library/delivery/trigger.go
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
package delivery

import (
	"context"
	"encoding/json"
	"fmt"
	"time"

	"icode.baidu.com/baidu/ps-se-go/restful/field"
	custom_field "icode.baidu.com/baidu/search/data-platform/library/field"
	"icode.baidu.com/baidu/search/data-platform/library/resource"
	"icode.baidu.com/baidu/search/data-platform/model/dao/mdb"
)

func Deliver(ctx context.Context, meta *mdb.DataMeta, summary map[string]any, eventType string, creator string, version int) error {
	job := buildTaskContent(meta, version)

	if err := job.Send(ctx); err != nil {
		return fmt.Errorf("send task failed, %w", err)
	}
	summary["postBody"] = job.postBody
	summaryBytes, _ := json.Marshal(summary)
	ins := mdb.EventLog{
		EventType:  eventType,
		Content:    string(summaryBytes),
		DID:        meta.ID,
		Creator:    custom_field.UserType(creator),
		DebugLevel: resource.LevelNotice,
		CreateTime: field.Timestamp(time.Now()),
		UpdateTime: field.Timestamp(time.Now()),
	}

	if err := mdb.WithContext(ctx, ins.Database()).Create(&ins).Error; err != nil {
		return err
	}
	return nil
}

func buildTaskContent(meta *mdb.DataMeta, version int) *Ejob {
	wantVersion := meta.Version
	if version > 0 {
		wantVersion = version
	}
	// hostname := "http://yandong03-2020.bcc-bdbl.baidu.com:8556"
	hostname := "http://sdata.baidu-int.com"
	content := map[string]any{
		"version":        wantVersion,
		"online_version": meta.OnlineVersion,
		"data_url":       fmt.Sprintf("%s/api/dimension/history/version_data?did=%d&version=%d&with_schema=true", hostname, meta.ID, wantVersion),
		"target": map[string]any{
			"type":   meta.TargetType,
			"params": meta.TargetParams,
		},
	}

	callbackURL := fmt.Sprintf("%s/api/dimension/meta/delivery_cb", hostname)
	// callbackURL := "http://yandong03-2020.bcc-bdbl.baidu.com:8556/api/dimension/meta/delivery_cb"
	callbackParams := map[string]any{
		"id":                 meta.ID,
		"version":            wantVersion,
		"pre_online_version": meta.OnlineVersion,
	}
	jobName := "sdata_delivery_" + meta.Name
	jobID := fmt.Sprintf("%s_%d", meta.Name, wantVersion)

	return &Ejob{
		JobName:        jobName,
		JobID:          jobID,
		UserParams:     content,
		CallbackURL:    callbackURL,
		CallbackParams: callbackParams,
	}
}
