/*
 * @Author: houming01 houming01@baidu.com
 * @Date: 2025-04-01 14:50:02
 * @LastEditors: houming01 houming01@baidu.com
 * @LastEditTime: 2025-04-01 18:24:19
 * @FilePath: /data-platform/library/delivery/dqc_trigger.go
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
package delivery

import (
	"context"
	"fmt"
	"math/rand"
)

func DeliverDqc(ctx context.Context, id string) error {
	hostname := "http://sdata.baidu-int.com"
	callbackURL := fmt.Sprintf("%s/api/dqc/task/sync/status/%s", hostname, id)

	content := map[string]any{
		"id": id,
	}
	a := rand.Intn(100)

	ejob := NewEjob().
		WithJobName(fmt.Sprintf("dqc_task_%s_%d", id, a)).
		WithJobID(fmt.Sprintf("dqc_task_%s_%d", id, a)).
		WithCommand("cd dqc_task && sh run.sh").
		WithPostBody(content).
		WithCallbackURL(callbackURL).
		WithUserParams(content).
		WithPackage("baidu/search/sdata-etl")

	return ejob.Send(ctx)
}
