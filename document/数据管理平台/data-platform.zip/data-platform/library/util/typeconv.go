package util

import (
	"fmt"
	"math"
)

func hasDecimalPlaces(f float64) bool {
	_, fracPart := math.Modf(f)
	return fracPart != 0.0
}

func ToString(value interface{}) string {
	switch v := value.(type) {
	case float64:
		if hasDecimalPlaces(v) {
			return fmt.Sprintf("%.6f", v)
		} else {
			return fmt.Sprintf("%d", int64(v))
		}
	case int64:
		return fmt.Sprintf("%d", v)
	case string:
		return v
	}
	return ""
}
