/*
 * @Author: yandong03 yandong03@baidu.com
 * @Date: 2024-08-02 17:58:56
 * @LastEditors: yandong03 yandong03@baidu.com
 * @LastEditTime: 2024-08-21 14:10:21
 * @FilePath: /data-platform/library/util/cron.go
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
package util

import (
	"context"
	"fmt"
	"time"

	"github.com/robfig/cron/v3"
	"icode.baidu.com/baidu/gdp/env"
	"icode.baidu.com/baidu/gdp/logit"
	"icode.baidu.com/baidu/search/data-platform/library/distributelock"
)

type Cron struct {
	*cron.Cron
	ctx context.Context
}

type CronService interface {
	Run() error
	Logger() logit.Logger
	ExecuteDuration() time.Duration
}

func CronWrapper(runner CronService, id string) func() {
	return func() {
		logger := runner.Logger()
		ctx := context.Background()
		ctx = logit.NewContext(ctx)
		var redisKey string
		if env.RunMode() == env.RunModeRelease {
			redisKey = "sdata_distribute_lock_prod_" + id
		} else {
			redisKey = "sdata_distribute_lock_" + id
		}
		locker, err := distributelock.LockWithReleaseDelay(redisKey, 4*time.Minute)
		if err != nil {
			logger.Error(ctx, "get redis lock failed", logit.Error("err", err), logit.String("key", redisKey))
			return
		}
		defer func() {
			_, err := locker.Unlock()
			if err != nil {
				logger.Error(ctx, "unlock failed", logit.Error("err", err), logit.String("key", redisKey))
			}
		}()

		start := time.Now()
		err = runner.Run()
		stop := time.Now()
		seconds := int(stop.Sub(start).Seconds())
		logit.AddAllLevel(ctx, logit.Int("cost_sec", seconds))
		if err != nil {
			logger.Error(ctx, "cron job failed", logit.Error("err", err))
		} else {
			logger.Notice(ctx, "cron job success", logit.String("id", id))
		}
	}
}

func NewCron(ctx context.Context) *Cron {
	scheduler := cron.New()

	return &Cron{
		ctx:  ctx,
		Cron: scheduler,
	}
}

func (c *Cron) AddJob(ctx context.Context, spec string, id string, runner CronService) error {
	_, err := c.AddFunc(spec, CronWrapper(runner, id))
	if err != nil {
		return fmt.Errorf("add job failed: %w", err)
	}
	return nil
}
