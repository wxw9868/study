package util

import (
	"encoding/json"
	"fmt"
	"strconv"
	"strings"
	"time"

	"icode.baidu.com/baidu/search/data-platform/model/dao/mdb"
)

type TooLTT struct {
	Message MessageBody `json:"message"`
}

type MessageBody struct {
	Header Header           `json:"header"`
	Body   []map[string]any `json:"body"`
}

type Header struct {
	Toid []int64 `json:"toid"`
}

func TdsData(msg *TooLTT) (mdb.SLATdsMonitor, error) {
	var data mdb.SLATdsMonitor
	data.TaskURL = msg.Message.Body[1]["href"].(string)
	err := parseTaskData(msg.Message.Body[0]["content"].(string), &data)
	if err != nil {
		return mdb.SLATdsMonitor{}, err
	}
	err = parseTaskData(msg.Message.Body[2]["content"].(string), &data)
	if err != nil {
		return mdb.SLATdsMonitor{}, err
	}
	return data, nil
}

// 将tds发送数据切割方便赋值结构体
func TdsDataReduce(data string) []string {
	lines := strings.Split(data, "\n")
	values := make([]string, 0)
	for _, line := range lines {
		// 按冒号空格分割
		parts := strings.SplitN(line, "： ", 2)
		if len(parts) >= 2 {
			value := strings.TrimSpace(parts[1])
			if value != "" {
				values = append(values, value)
			}
		}
	}
	return values
}

// string转int
func StringToInt(data string) (int, error) {
	num, err := strconv.Atoi(data)
	if err != nil {
		return 0, err
	}
	return num, err
}

// string转time完整年月日
func StringToTimeAll(data string) (time.Time, error) {
	nowTime, err := time.ParseInLocation("2006-01-02 15:04:05", data, time.Local)
	if err != nil {
		return time.Time{}, err
	}
	return nowTime, err
}

// 解析字符串并赋值给结构体的函数
func parseTaskData(input string, data *mdb.SLATdsMonitor) error {
	lines := strings.Split(strings.TrimSpace(input), "\n")

	for _, line := range lines {
		parts := strings.SplitN(line, "：", 2)
		if len(parts) != 2 {
			continue // 忽略不符合格式的行
		}
		key, value := strings.TrimSpace(parts[0]), strings.TrimSpace(parts[1])
		switch key {
		case "任务ID":
			taskIDStr, err := StringToInt(value)
			if err != nil {
				return fmt.Errorf("解析任务ID失败: %w", err)
			}
			data.TaskID = taskIDStr
		case "任务名称":
			data.TaskName = value
		case "监控ID":
			monitorIDStr, err := StringToInt(value)
			if err != nil {
				return fmt.Errorf("解析监控ID失败: %w", err)
			}
			data.MonitorID = monitorIDStr
		case "监控名称":
			data.MonitorName = value
		case "监控描述":
			data.MonitorDescription = value
		case "报警类型":
			data.MonitorType = value
		case "任务状态":
			data.TaskStatus = value
		case "基准时间":
			createTime, err := StringToTimeAll(value)
			if err != nil {
				return fmt.Errorf("解析基准时间失败: %w", err)
			}
			data.CreateTime = createTime
		case "运行时长":
			data.RunTime = value
		case "算子名称":
			data.MonitorOperator = value
		case "重试次数":
			retryCountStr, err := StringToInt(value)
			if err != nil {
				return fmt.Errorf("解析基准重试次数失败: %w", err)
			}
			data.RetryCount = retryCountStr
		case "任务状态获取时间":
			updateTime, err := StringToTimeAll(value)
			if err != nil {
				return fmt.Errorf("解析任务状态获取时间失败: %w", err)
			}
			data.UpdateTime = updateTime
		}
	}
	return nil
}

// json转string
func JSONToString(data []map[string]string) (string, error) {
	// 将 map 转换为 JSON 格式的字符串
	jsonStr, err := json.Marshal(data)
	if err != nil {
		fmt.Println("Error marshaling map to JSON:", err)
		return "", err
	}
	// 将 JSON 字节数组转换为字符串
	jsonStrStr := string(jsonStr)
	return jsonStrStr, nil
}
