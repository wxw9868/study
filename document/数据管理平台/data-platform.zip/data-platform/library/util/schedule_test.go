/*
 * @Author: yandong03 yandong03@baidu.com
 * @Date: 2024-08-05 15:09:09
 * @LastEditors: yandong03 yandong03@baidu.com
 * @LastEditTime: 2024-08-06 18:46:07
 * @FilePath: /data-platform/library/util/schedule_test.go
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
package util

import (
	"testing"
	"time"
)

func TestIsOverTime(t *testing.T) {

	dateUpdateTimeStr := "2024-08-03 15:27:30"
	dateUpdateTime, _ := time.Parse("2006-01-02 15:04:05", dateUpdateTimeStr)
	nowTimeStr := "2024-08-04 15:27:30"
	nowTime, _ := time.Parse("2006-01-02 15:04:05", nowTimeStr)

	if IsOverTime("17:00", dateUpdateTime, nowTime, 5, 5) != false {
		t.Errorf("TestIsOverTime failed: cond1")
	}

	if IsOverTime("15:20", dateUpdateTime, nowTime, 5, 5) != true {
		t.Errorf("TestIsOverTime failed: cond2")
	}

	if IsOverTime("15:20", dateUpdateTime, nowTime, 5, 1) != false {
		t.Errorf("TestIsOverTime failed: cond3")
	}

	if IsOverTime("15:20", dateUpdateTime, nowTime, 1, 5) != false {
		t.Errorf("TestIsOverTime failed: cond4")
	}

	nowTimeStr = "2024-08-06 17:30:10"
	nowTime, _ = time.Parse("2006-01-02 15:04:05", nowTimeStr)

	if IsOverTime("17:25", dateUpdateTime, nowTime, 5, 5) != true {
		t.Errorf("TestIsOverTime failed: cond5")
	}

	nowTimeStr = "2024-08-06 17:35:10"
	nowTime, _ = time.Parse("2006-01-02 15:04:05", nowTimeStr)

	if IsOverTime("17:25", dateUpdateTime, nowTime, 5, 5) != false {
		t.Errorf("TestIsOverTime failed: cond6")
	}
}
