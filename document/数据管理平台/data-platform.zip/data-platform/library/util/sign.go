/*
 * @Author: yandong03 yandong03@baidu.com
 * @Date: 2024-08-01 14:43:15
 * @LastEditors: yandong03 yandong03@baidu.com
 * @LastEditTime: 2024-08-01 14:52:27
 * @FilePath: /data-platform/library/util/sign.go
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
package util

import (
	"crypto/md5"
	"encoding/hex"
	"encoding/json"
)

func SignData(data any) string {
	jsonData, _ := json.Marshal(data)
	hasher := md5.New()
	hasher.Write(jsonData)
	hash := hasher.Sum(nil)
	md5String := hex.EncodeToString(hash)
	return md5String
}
