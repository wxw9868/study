/*
 * @Author: yandong03 yandong03@baidu.com
 * @Date: 2024-08-01 11:13:06
 * @LastEditors: yandong03 yandong03@baidu.com
 * @LastEditTime: 2024-09-04 10:06:57
 * @FilePath: /data-platform/library/util/schedule.go
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
package util

import (
	"strconv"
	"strings"
	"time"
)

func ScheduleNow(scheduleParams map[string]any, allowDiff time.Duration, now time.Time) bool {
	var scheduleType string
	if t, ok := scheduleParams["type"].(string); ok {
		scheduleType = t
	}
	if scheduleType == "period" {
		return true
	}
	_, ok := scheduleParams["fixedTime"]
	if !ok {
		return false
	}
	var fixedTime string
	if v, ok := scheduleParams["fixedTime"].(string); ok {
		fixedTime = v
	}
	hourMin := strings.Split(fixedTime, ":")
	hour, _ := strconv.Atoi(hourMin[0])
	minute, _ := strconv.Atoi(hourMin[1])

	fixedNow := time.Date(now.Year(), now.Month(), now.Day(), hour, minute, 0, 0, now.Location())

	diff := now.Sub(fixedNow)
	if diff < 0 {
		diff = diff * -1
	}
	return diff <= allowDiff
}

func IsOverTime(basedTime string, dateUpdateTime time.Time, now time.Time, timeoutMinute int, allowDiffMinute int) bool {
	// 今天已经更新了，不需要检测
	if dateUpdateTime.Year() == now.Year() && dateUpdateTime.Month() == now.Month() && dateUpdateTime.Day() == now.Day() {
		return false
	}
	// 判断当前时间是否满足报警条件
	hourMin := strings.Split(basedTime, ":")
	hour, _ := strconv.Atoi(hourMin[0])
	minute, _ := strconv.Atoi(hourMin[1])

	fixedNow := time.Date(now.Year(), now.Month(), now.Day(), hour, minute, 0, 0, now.Location())

	diff := int(now.Sub(fixedNow).Minutes())
	// 未到检测时间
	if diff < 0 {
		return false
	}
	if diff < timeoutMinute {
		return false
	}
	if diff >= timeoutMinute+allowDiffMinute {
		return false
	}
	return true
}
