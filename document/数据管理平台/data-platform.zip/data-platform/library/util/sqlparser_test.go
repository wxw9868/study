/*
 * @Author: yandong03 yandong03@baidu.com
 * @Date: 2024-08-19 13:20:23
 * @LastEditors: yandong03 yandong03@baidu.com
 * @LastEditTime: 2024-08-19 19:29:29
 * @FilePath: /data-platform/library/util/sqlparser_test.go
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
package util

import "testing"

func TestParseSql(t *testing.T) {
	sql := `
	CREATE TABLE dqc_meta (
	  id bigint(20) NOT NULL AUTO_INCREMENT,
	  name varchar(128) NOT NULL,
	  chname varchar(256) NOT NULL,
	  source_type varchar(64) NOT NULL DEFAULT '' COMMENT '来源',
	  source_params varchar(1024) NOT NULL DEFAULT '' COMMENT '来源参数',
	  data_schema text NOT NULL,
	  creator varchar(45) NOT NULL COMMENT '创建人',
	  modifier varchar(45) NOT NULL COMMENT '最近更新人',
	  create_time timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
	  update_time timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
	  PRIMARY KEY (id)
	) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;`

	ExtractColumnFromCreateSQL(sql)
}
