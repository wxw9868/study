package util

import (
	"context"
	"encoding/json"
	"io"
	"net/http"
	"net/url"

	"icode.baidu.com/baidu/gdp/codec"
	"icode.baidu.com/baidu/gdp/ghttp"
	"icode.baidu.com/baidu/gdp/logit"
	"icode.baidu.com/baidu/gdp/net/ral"
)

type Hibot struct {
	HibotToken string  `toml:"token"`
	HibotGroup []int64 `toml:"group_id"`
}

type RobotMessage struct {
	Messages []MessageType
}

func (rm *RobotMessage) StructData() []any {
	msg := []any{}
	for _, m := range rm.Messages {
		msg = append(msg, m.StructData())
	}
	return msg
}

func (rm *RobotMessage) AppendMessage(m MessageType) {
	rm.Messages = append(rm.Messages, m)
}

type MessageType interface {
	StructData() map[string]any
}

type TextMessage struct {
	content string
}

func NewTextMessage(content string) MessageType {
	return &TextMessage{
		content: content,
	}
}

func (tm *TextMessage) StructData() map[string]any {
	return map[string]any{
		"type":    "TEXT",
		"content": tm.content,
	}
}

type LinkMessage struct {
	href string
}

func NewLinkMessage(href string) MessageType {
	return &LinkMessage{
		href: href,
	}
}

func (tm *LinkMessage) StructData() map[string]any {
	return map[string]any{
		"type": "LINK",
		"href": tm.href,
	}
}

type AtMessage struct {
	AtUserIds []string
}

func NewAtMessage(userID ...string) MessageType {
	return &AtMessage{
		AtUserIds: userID,
	}
}

func (am *AtMessage) StructData() map[string]any {
	return map[string]any{
		"type":      "AT",
		"atall":     false,
		"atuserids": am.AtUserIds,
	}
}

type MdMessage struct {
	content string
}

func (mm *MdMessage) StructData() map[string]any {
	return map[string]any{
		"type":    "MD",
		"content": mm.content,
	}
}

func NewMdMessage(content string) MessageType {
	return &MdMessage{
		content: content,
	}
}

func NewHibotGroup(token string, groupID []int64) *Hibot {
	return &Hibot{
		HibotToken: token,
		HibotGroup: groupID,
	}
}

// SendGroupMsgByType 给如流群发送消息
// groupIDS 接受消息的如流群，支持多个
// content  推送的消息，支持类型：TEXT / LINK / AT / IMAGE / MD
//
//	Json字符串：[
//		{\"type\":\"TEXT\",\"content\":\"阿斯顿发斯蒂芬\"},
//		{\"type\":\"LINK\",\"href\":\"https:\/\/baidu.com\/s?wd=百度\",\"label\":\"百度\"},
//		{\"type\":\"AT\",\"atall\":false,\"atuserids\":[\"wangming07\"]}
//	]

func (hg *Hibot) SendGroupMsg(ctx context.Context, content RobotMessage) (string, error) {
	hd := http.Header{}
	hd.Add("Content-Type", "application/json")
	ralReq := &ghttp.RalRequest{
		Method: "POST",
		Path:   "/api/msg/groupmsgsend",
		Header: hd,
		Query: url.Values{
			// 运营机器人Token
			"access_token": []string{hg.HibotToken},
		},
	}

	msgData := map[string]any{
		"header": map[string]any{
			"toid": hg.HibotGroup,
		},
		"body": []map[string]any{},
	}

	msgData["body"] = content.StructData()
	postData := map[string]any{
		"message": msgData,
	}

	logit.AddNotice(ctx, logit.AutoField("postData", postData))

	// 设置 Body，注意和 上面的 Content-Type 要匹配
	err := ralReq.WithBody(postData, codec.JSONEncoder)
	if err != nil {
		logit.AddNotice(ctx, logit.AutoField("postData", err.Error()))
		return "", err
	}
	ralResp := &ghttp.RalResponse{}
	err = ral.RAL(ctx, "ral_hibot", ralReq, ralResp)
	if err != nil {
		logit.AddNotice(ctx, logit.AutoField("ral_err", err.Error()))
		return "", err
	}
	rawResp := ralResp.Response()
	defer rawResp.Body.Close()

	rep, _ := io.ReadAll(rawResp.Body)

	logit.AddNotice(ctx, logit.ByteString("send_resp", rep))

	// 定义返回数据结构
	var sendReq struct {
		ErrCode int32  `json:"errcode"`
		ErrMsg  string `json:"errmsg"`
	}

	// 解析结果
	err = json.Unmarshal(rep, &sendReq)
	if err != nil {
		return "", err
	}

	return string(rep), nil
}
