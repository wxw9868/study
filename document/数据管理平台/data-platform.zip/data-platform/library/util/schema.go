/*
 * @Author: yandong03 yandong03@baidu.com
 * @Date: 2024-08-09 11:35:50
 * @LastEditors: yandong03 yandong03@baidu.com
 * @LastEditTime: 2024-08-21 17:19:33
 * @FilePath: /data-platform/library/util/schema.go
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
package util

import (
	"context"
	"fmt"
	"strconv"
	"strings"
)

func ExtractRequiredKeys(schema map[string]any) map[string]bool {
	ret := make(map[string]bool, 0)
	if keys, ok := schema["required"].([]any); ok {
		for _, key := range keys {
			if str, strok := key.(string); strok {
				ret[str] = true
			}
		}
		return ret
	}
	return ret
}

func SchemaToFieldMap(schema map[string]any) map[string]string {
	ret := make(map[string]string)
	if _, ok := schema["properties"]; !ok {
		return ret
	}
	properties, ok := schema["properties"].(map[string]any)
	if !ok {
		return ret
	}
	for k, v := range properties {
		fieldType, ok := v.(map[string]any)
		if !ok {
			continue
		}
		if title, ok := fieldType["title"]; ok {
			if titleStr, ok := title.(string); ok {
				ret[titleStr] = k
			}
		}
	}
	return ret
}

func SchemaToFieldType(schema map[string]any) map[string]string {
	ret := make(map[string]string)
	if _, ok := schema["properties"]; !ok {
		return ret
	}
	properties, ok := schema["properties"].(map[string]any)
	if !ok {
		return ret
	}
	for k, v := range properties {
		fieldType, ok := v.(map[string]any)
		if !ok {
			continue
		}
		if typ, ok := fieldType["type"]; ok {
			if typStr, ok := typ.(string); ok {
				ret[k] = typStr
			}
		}
	}
	return ret
}

func ExtractUniqueKeys(schema map[string]any) []string {
	ret := make([]string, 0)
	properties, ok := schema["properties"].(map[string]any)
	if !ok {
		return ret
	}
	for k := range properties {
		ret = append(ret, k)
	}

	uniqueKeys, ok := schema["uniqueKeys"].([]any)
	if !ok {
		return ret
	}
	ret = make([]string, 0)
	for _, key := range uniqueKeys {
		if keyStr, ok := key.(string); ok {
			ret = append(ret, keyStr)
		}
	}
	return ret
}

// 将obj中的value按照uniquekeys的顺序拼接成唯一id
func GetObjectUniqueIDByUniqueKeys(obj map[string]any, uniqueKeys []string) string {
	var ret []string
	for _, key := range uniqueKeys {
		if val, ok := obj[key]; ok {

			ret = append(ret, fmt.Sprintf("%v", val))
		}
	}
	return strings.Join(ret, "|")
}

func GetSchemaOrder(schema map[string]any) []string {
	ret := make([]string, 0)
	properties, ok := schema["properties"].(map[string]any)
	if !ok {
		return ret
	}
	for k := range properties {
		ret = append(ret, k)
	}

	orderKeys, ok := schema["order"].([]any)
	if !ok {
		return ret
	}
	ret = make([]string, 0)
	for _, key := range orderKeys {
		if keyStr, ok := key.(string); ok {
			ret = append(ret, keyStr)
		}
	}
	return ret
}

func getDefaultValue(dataType string) any {
	switch dataType {
	case "string":
		return ""
	case "integer":
		return 0
	case "number":
		return float64(0)
	case "boolean":
		return false
	default:
		return nil
	}
}

func TransfromDataByDataSchema(data map[string]string, dataTypeMap map[string]string, requiredKeys map[string]bool) (map[string]any, error) {
	result := make(map[string]any)

	for key, dataType := range dataTypeMap {
		dataValue, ok := data[key]
		if !ok {
			if _, requireOk := requiredKeys[key]; !requireOk {
				result[key] = getDefaultValue(dataType)
			}
			continue
		}
		switch dataType {
		case "string":
			result[key] = dataValue
		case "integer":
			intValue, err := strconv.Atoi(dataValue)
			if err != nil {
				return nil, fmt.Errorf("failed to convert data field %s to int", key)
			}
			result[key] = intValue
		case "number":
			floatValue, err := strconv.ParseFloat(dataValue, 64)
			if err != nil {
				return nil, fmt.Errorf("failed to convert data field %s to float64", key)
			}
			result[key] = floatValue
		case "boolean":
			boolValue, err := strconv.ParseBool(dataValue)
			if err != nil {
				return nil, fmt.Errorf("failed to convert data field %s to bool", key)
			}
			result[key] = boolValue
		default:
			return nil, fmt.Errorf("unsupported data type %s in schema", dataType)
		}
	}
	return result, nil
}

func ParseTextBySchema(ctx context.Context, text string, schema map[string]any) ([]map[string]any, error) {
	lines := strings.Split(text, "\n")
	var filteredLines []string
	for _, line := range lines {
		if line != "" {
			filteredLines = append(filteredLines, line)
		}
	}
	dataTypeMap := SchemaToFieldType(schema)
	columnOrder := GetSchemaOrder(schema)
	requiredKeys := ExtractRequiredKeys(schema)
	result := make([]map[string]any, 0)
	for _, line := range filteredLines {
		values := strings.Split(line, "\t")
		if len(values) != len(columnOrder) {
			continue
		}

		obj := make(map[string]string)
		for i, header := range columnOrder {
			obj[header] = values[i]
		}

		if len(obj) != len(columnOrder) {
			continue
		}
		transformIten, err := TransfromDataByDataSchema(obj, dataTypeMap, requiredKeys)
		if err == nil {
			result = append(result, transformIten)
		} else {
			// 先保留
			fmt.Println(err)
		}
	}

	return result, nil
}
