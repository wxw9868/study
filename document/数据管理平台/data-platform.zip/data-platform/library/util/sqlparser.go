/*
 * @Author: yandong03 yandong03@baidu.com
 * @Date: 2024-08-19 13:08:29
 * @LastEditors: yandong03 yandong03@baidu.com
 * @LastEditTime: 2024-08-19 19:29:05
 * @FilePath: /data-platform/library/util/sqlparser.go
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
package util

import (
	"fmt"
	"strings"

	"github.com/pingcap/tidb/pkg/parser"
	"github.com/pingcap/tidb/pkg/parser/ast"

	// 导入解析驱动
	_ "github.com/pingcap/tidb/pkg/types/parser_driver"
)

type Column struct {
	Name string `json:"name"`
	Type string `json:"type"`
}

func ExtractColumnFromCreateSQL(sql string) ([]*Column, error) {
	node, err := parse(sql)
	if err != nil {
		return nil, fmt.Errorf("parse error: %w", err)
	}
	var stmt *ast.CreateTableStmt
	switch t := node.(type) {
	case *ast.CreateTableStmt:
		stmt = t
	default:
		return nil, fmt.Errorf("not create statement")
	}

	cols := []*Column{}
	for _, col := range stmt.Cols {
		cols = append(cols, &Column{
			Name: col.Name.Name.O,
			Type: convertMySQLTypeToHiveType(col.Tp.String()),
		})
	}
	return cols, nil
}

// ConvertMySQLTypeToHiveType converts MySQL column types to Hive column types.
func convertMySQLTypeToHiveType(mysqlType string) string {
	mysqlType = strings.ToLower(mysqlType)

	switch {
	case strings.HasPrefix(mysqlType, "int"):
		return "int"
	case strings.HasPrefix(mysqlType, "tinyint"):
		return "int"
	case strings.HasPrefix(mysqlType, "smallint"):
		return "int"
	case strings.HasPrefix(mysqlType, "mediumint"):
		return "int"
	case strings.HasPrefix(mysqlType, "bigint"):
		return "int"
	case strings.HasPrefix(mysqlType, "float"):
		return "float"
	case strings.HasPrefix(mysqlType, "double"):
		return "double"
	case strings.HasPrefix(mysqlType, "decimal"):
		return "double"
	case strings.HasPrefix(mysqlType, "char"):
		return "string"
	case strings.HasPrefix(mysqlType, "varchar"):
		return "string"
	case strings.HasPrefix(mysqlType, "text"):
		return "string"
	case strings.HasPrefix(mysqlType, "blob"):
		return "binary"
	case strings.HasPrefix(mysqlType, "date"):
		return "string"
	case strings.HasPrefix(mysqlType, "datetime"), strings.HasPrefix(mysqlType, "timestamp"):
		return "string"
	case strings.HasPrefix(mysqlType, "time"):
		return "string"
	case strings.HasPrefix(mysqlType, "year"):
		return "int"
	default:
		return "string"
	}
}

func parse(sql string) (ast.StmtNode, error) {
	p := parser.New()

	stmtNodes, _, err := p.ParseSQL(sql)
	if err != nil {
		return nil, err
	}
	if len(stmtNodes) < 1 {
		return nil, fmt.Errorf("stmt empty")
	}
	return stmtNodes[0], nil
}
