/*
 * @Author: yandong03 yandong03@baidu.com
 * @Date: 2024-07-29 20:19:52
 * @LastEditors: yandong03 yandong03@baidu.com
 * @LastEditTime: 2024-11-18 10:53:59
 * @FilePath: /data-platform/library/field/user.go
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
package field

import (
	"context"
	"reflect"

	"icode.baidu.com/baidu/gdp/uuap"
)

type UserType string

func (ut UserType) GetDefault(ctx context.Context, value interface{}) interface{} {
	user := uuap.SSOUserFromCtx(ctx)
	if user == nil {
		return UserType("")
	}
	return UserType(user.UserName)
}

func (ut UserType) GetDefaultPrepare(rt reflect.Type, value string) (interface{}, error) {
	return value, nil
}
