/*
 * @Author: yandong03 yandong03@baidu.com
 * @Date: 2024-09-12 20:08:41
 * @LastEditors: yandong03 yandong03@baidu.com
 * @LastEditTime: 2024-09-14 14:29:00
 * @FilePath: /data-platform/library/afs/cmd.go
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
package afs

import (
	"bufio"
	"errors"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
)

func runAfsshellCommand(ugi string, args ...string) error {
	if len(args) == 0 {
		return errors.New("no arguments provided")
	}
	ugiList := strings.Split(ugi, ",")
	if len(ugiList) != 2 {
		return errors.New("ugi not valid")
	}
	newArgs := []string{
		"--username=" + ugiList[0],
		"--password=" + ugiList[1],
	}
	newArgs = append(newArgs, args...)
	cmd := exec.Command("bin/afsshell", newArgs...)

	if err := cmd.Run(); err != nil {
		return err
	}

	return nil
}

func Touchz(ugi, path string) error {
	if path == "" {
		return errors.New("path cannot be empty")
	}
	// 获取path的父级目录
	idx := strings.LastIndex(path, "/")
	dir := ""
	if idx != -1 {
		dir = path[:idx]
	} else {
		return fmt.Errorf("invalid path: %s", path)
	}
	if err := runAfsshellCommand(ugi, "mkdir", dir); err != nil {
		return err
	}
	return runAfsshellCommand(ugi, "put", "./data/.done", path)
}

func Mkdir(ugi, path string) error {
	if path == "" {
		return errors.New("path cannot be empty")
	}
	return runAfsshellCommand(ugi, "mkdir", path)
}

func ReadFile(ugi, remotePath string) ([]byte, error) {
	if remotePath == "" {
		return nil, errors.New("remotePath cannot be empty")
	}

	tempDir := "./temp_dir"
	if err := os.MkdirAll(tempDir, os.ModePerm); err != nil {
		return nil, fmt.Errorf("failed to create temp directory: %w", err)
	}
	defer os.RemoveAll(tempDir)

	if err := runAfsshellCommand(ugi, "get", remotePath, tempDir); err != nil {
		return nil, fmt.Errorf("failed to download remotePath: %w", err)
	}

	info, err := os.Stat(tempDir)
	if err != nil {
		return nil, fmt.Errorf("failed to stat temp directory: %w", err)
	}

	var allLines []string
	if info.IsDir() {
		err := filepath.Walk(tempDir, func(path string, f os.FileInfo, err error) error {
			if err != nil {
				return err
			}
			if !f.IsDir() && len(allLines) < 100 {
				lines, err := readLimitedLines(path, 100-len(allLines))
				if err != nil {
					return fmt.Errorf("failed to read file %s: %w", path, err)
				}
				allLines = append(allLines, lines...)
			}
			return nil
		})
		if err != nil {
			return nil, fmt.Errorf("error while reading directory: %w", err)
		}
	} else {
		lines, err := readLimitedLines(tempDir, 100)
		if err != nil {
			return nil, fmt.Errorf("failed to read local file: %w", err)
		}
		allLines = append(allLines, lines...)
	}

	allData := []byte(strings.Join(allLines, "\n") + "\n")
	return allData, nil
}

func readLimitedLines(filePath string, n int) ([]string, error) {
	file, err := os.Open(filePath)
	if err != nil {
		return nil, fmt.Errorf("failed to open file %s: %w", filePath, err)
	}
	defer file.Close()

	var lines []string
	scanner := bufio.NewScanner(file)
	for i := 0; i < n && scanner.Scan(); i++ {
		lines = append(lines, scanner.Text())
	}

	if err := scanner.Err(); err != nil {
		return nil, fmt.Errorf("error while reading file %s: %w", filePath, err)
	}

	return lines, nil
}
