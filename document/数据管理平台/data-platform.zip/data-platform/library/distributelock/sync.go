/*
 * @Author: yandong03 yandong03@baidu.com
 * @Date: 2024-08-05 11:04:50
 * @LastEditors: yandong03 yandong03@baidu.com
 * @LastEditTime: 2024-08-05 11:24:52
 * @FilePath: /data-platform/library/distribute_lock/sync.go
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
package distributelock

// IDataSync 分布式锁接口
type IDataSync interface {
	Lock(name string) error
	Unlock() (bool, error)

	WithLock(string, func() error) error // 排他访问
}
