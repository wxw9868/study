package distributelock

import (
	"context"
	"errors"
	"log"
	"net"
	"time"

	goredislib "github.com/go-redis/redis"
	goredislib_v8 "github.com/go-redis/redis/v8"
	"github.com/go-redsync/redsync/v3"
	"github.com/go-redsync/redsync/v3/redis"
	"github.com/go-redsync/redsync/v3/redis/goredis"
	"icode.baidu.com/baidu/gdp/logit"
	"icode.baidu.com/baidu/gdp/net/servicer"
	gdpredis "icode.baidu.com/baidu/gdp/redis"
)

// DLocker 分布式锁结构
type DLocker struct {
	mutex        *redsync.Mutex
	delayRelease bool
}

// HugeLocks 分布式锁组件实例
var HugeLocks *redsync.Redsync

// InitDistributeLock  初始化分布式锁
//
//	需要提前ral初始化
func InitDistributeLock(ctx context.Context) error {
	distributeLockRedis := "distribute_lock_redis"
	redisServicer := servicer.DefaultMapper.Servicer(distributeLockRedis)
	if redisServicer == nil {
		return errors.New("services file not found: distribute_lock_redis.toml")

	}
	ctxNew := logit.WithContext(ctx)
	_, err := InitHugeLocks(ctxNew, distributeLockRedis)
	if err != nil {
		return err
	}
	return nil
}

// InitHugeLocks 初始化分布式锁组件
func InitHugeLocks(ctx context.Context, redisServiceName string) (bool, error) {
	var (
		netAddr net.Addr
		opts    *goredislib.Options
	)
	var err error

	// 每次获取池时候先获取addr, 如果存在则复用
	redisServicer := servicer.DefaultMapper.Servicer(redisServiceName)
	if netAddr, err = redisServicer.Connector().Pick(ctx); err != nil {
		return false, errors.New("distribute_lock: get netAddr error")
	}

	// redis配置
	if tmp := redisServicer.Option().Value("Redis"); tmp != nil {
		switch val := tmp.(type) {
		case *goredislib.Options:
			opts = val
		case *goredislib_v8.Options:
			opts = &goredislib.Options{
				Network:            val.Network,
				Addr:               val.Addr,
				Dialer:             nil,
				OnConnect:          nil,
				Password:           val.Password,
				DB:                 val.DB,
				MaxRetries:         val.MaxRetries,
				MinRetryBackoff:    val.MinRetryBackoff,
				MaxRetryBackoff:    val.MaxRetryBackoff,
				DialTimeout:        val.DialTimeout,
				ReadTimeout:        val.ReadTimeout,
				WriteTimeout:       val.WriteTimeout,
				PoolSize:           val.PoolSize,
				MinIdleConns:       val.MinIdleConns,
				MaxConnAge:         val.MaxConnAge,
				PoolTimeout:        val.PoolTimeout,
				IdleTimeout:        val.IdleTimeout,
				IdleCheckFrequency: val.IdleCheckFrequency,
				TLSConfig:          val.TLSConfig,
			}
		case *gdpredis.Options:
			opts = &goredislib.Options{
				Network:            val.Network,
				Addr:               val.Addr,
				Dialer:             nil,
				OnConnect:          nil,
				Password:           val.Password,
				DB:                 val.DB,
				MaxRetries:         val.MaxRetries,
				MinRetryBackoff:    val.MinRetryBackoff,
				MaxRetryBackoff:    val.MaxRetryBackoff,
				DialTimeout:        val.DialTimeout,
				ReadTimeout:        val.ReadTimeout,
				WriteTimeout:       val.WriteTimeout,
				PoolSize:           val.PoolSize,
				MinIdleConns:       val.MinIdleConns,
				MaxConnAge:         val.MaxConnAge,
				PoolTimeout:        val.PoolTimeout,
				IdleTimeout:        val.IdleTimeout,
				IdleCheckFrequency: val.IdleCheckFrequency,
				TLSConfig:          val.TLSConfig,
			}
		case map[string]interface{}:
			valMap := map[string]interface{}{}
			redisServicer.Option().Range(func(k, v interface{}) bool {
				if kStrVal, ok := k.(string); ok {
					valMap[kStrVal] = v
				}
				return true
			})
			for k, v := range val {
				valMap[k] = v
			}
			opts = &goredislib.Options{}
			if v, ok := valMap["Password"]; ok {
				opts.Password = v.(string)
			}
			if v, ok := valMap["DB"]; ok {
				opts.DB = int(v.(int64))
			}
			if v, ok := valMap["Retry"]; ok {
				opts.MaxRetries = int(v.(int64))
			}
			if v, ok := valMap["ReadTimeOut"]; ok {
				opts.ReadTimeout = time.Duration(v.(int64)) * time.Millisecond
			}
			if v, ok := valMap["WriteTimeOut"]; ok {
				opts.WriteTimeout = time.Duration(v.(int64)) * time.Millisecond
			}
			if v, ok := valMap["ConnTimeOut"]; ok {
				opts.DialTimeout = time.Duration(v.(int64)) * time.Millisecond
			}
		default:
			return false, errors.New("distribute_lock: format redis opt error")
		}
	}

	opts.Dialer = func() (conn net.Conn, err error) {
		if netAddr == nil {
			if netAddr, err = redisServicer.Connector().Pick(ctx); err != nil {
				log.Println("distribute_lock: get dial error")
				return nil, err
			}
		}

		return redisServicer.Connector().Connect(ctx, netAddr)
	}

	cli := goredislib.NewClient(opts)
	pool := goredis.NewGoredisPool(cli)

	HugeLocks = redsync.New([]redis.Pool{pool})

	err = cli.Ping().Err()
	if err != nil {
		return true, err
	}

	return true, nil
}

// Lock 获取锁，如果失败则返回err
func (ds *DLocker) Lock(name string) error {
	var err error
	ds.mutex = HugeLocks.NewMutex(name, redsync.SetExpiry(time.Second*2), redsync.SetTries(1),
		redsync.SetRetryDelay(time.Millisecond*100))
	err = ds.mutex.Lock()
	return err
}

// Lock 获取锁，如果失败则返回err
func (ds *DLocker) LockWithReleaseDelay(name string, duration time.Duration) error {
	var err error
	ds.mutex = HugeLocks.NewMutex(name, redsync.SetExpiry(duration), redsync.SetTries(1),
		redsync.SetRetryDelay(time.Millisecond*100))
	err = ds.mutex.Lock()
	ds.delayRelease = true
	return err
}

// Unlock 释放锁
func (ds *DLocker) Unlock() (bool, error) {
	if ds.delayRelease {
		// 按锁expired时间自行release
		return false, nil
	}
	return ds.mutex.Unlock()
}

// WithLock 尝试获取名称为lock的锁，如果失败，返回err，如果成功，执行fn
func (ds *DLocker) WithLock(lock string, fn func() error) error {
	if err := ds.Lock(lock); err != nil {
		return err
	}
	defer func() {
		_, err := ds.Unlock()
		if err != nil {
			log.Println("distribute_lock: unlock error")
		}
	}()

	return fn()
}

// Lock 加锁
func Lock(name string) (IDataSync, error) {
	newLocker := &DLocker{}
	err := newLocker.Lock(name)
	if err != nil {
		return newLocker, err
	}
	return newLocker, nil
}

// WithLock 加锁执行fn
func WithLock(key string, fn func() error) error {
	newLocker := &DLocker{}
	return newLocker.WithLock(key, fn)
}

// Lock 加锁
func LockWithReleaseDelay(name string, duration time.Duration) (IDataSync, error) {
	newLocker := &DLocker{}
	err := newLocker.LockWithReleaseDelay(name, duration)
	if err != nil {
		return newLocker, err
	}
	return newLocker, nil
}
