/*
 * @Author: yandong03 yandong03@baidu.com
 * @Date: 2024-07-24 18:00:37
 * @LastEditors: yandong03 yandong03@baidu.com
 * @LastEditTime: 2024-08-02 10:19:40
 * @FilePath: /data-platform/library/resource/platform.go
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
package resource

type Platform struct {
	Webroot string
	Service map[string]interface{}
}

const EventCreateMeta string = "1"
const EventEditMeta string = "2"
const EditContentData string = "3"
const SyncData string = "4"
const AutoDeliveryData string = "5"
const ManualDeliveryData string = "6"
const UpdateOnlineVersion string = "7"

const LevelNotice = 1
const LevelDebug = 8
