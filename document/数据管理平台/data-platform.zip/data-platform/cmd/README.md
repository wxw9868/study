# cmd

其他的使用 go 实现的子功能，每个目录下一个功能。  
使用 build.sh 脚本编译，编译产出目录为 ../bin。

到项目的根目录下去运行：
```
./bin/demo-hello
```

或者

```
./bin/demo-hello -conf ./conf_qa/app.toml
```
