/*
 * @Author: yandong03 yandong03@baidu.com
 * @Date: 2024-07-23 14:52:50
 * @LastEditors: yandong03 yandong03@baidu.com
 * @LastEditTime: 2024-08-05 16:35:33
 * @FilePath: /data-platform/model/dao/mdb/data_history.go
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
package mdb

import (
	"context"
	"database/sql"

	"gorm.io/gorm"

	"icode.baidu.com/baidu/ps-se-go/restful/field"
	custom_field "icode.baidu.com/baidu/search/data-platform/library/field"
	"icode.baidu.com/baidu/search/data-platform/library/resource"
)

const TableNameDataHistory = "data_history"

// Gorm 说明文档：
//   [This] V2: https://gorm.io/docs/models.html#Creating-Updating-Time-Unix-Milli-Nano-Seconds-Tracking
// 	        V1： https://v1.gorm.io/docs/models.html
// 更新数据时，只会兼容Gorm中的部分属性
//
// 结构体中定义的属性由两部分程序接管：
// 	1. column/primaryKey/default 由自由程序接管处理
//  2. <-:create/->/<- 由GORM程序接管处理(在执行GORM中方法的时会自动识别，无需程序关注)

// DataHistory 结构体映射到数据库的 data_history 表
type DataHistory struct {
	ID          int64                 `gorm:"column:id;primaryKey;autoIncrement" json:"id"`
	DID         int64                 `gorm:"column:did;not null" json:"did"`
	Version     int                   `gorm:"column:version;not null" json:"version"`
	DataSign    string                `gorm:"column:data_sign;not null" json:"dataSign"`
	Content     field.JSON            `gorm:"column:content;type:mediumtext;not null" json:"content"`
	Creator     custom_field.UserType `gorm:"column:creator;not null" json:"creator" default:"current"`
	CommentInfo string                `gorm:"column:comment_info;not null" json:"commentInfo"`
	CreateTime  field.Timestamp       `gorm:"<-:create;column:create_time;autoCreateTime;not null" json:"createTime" default:"now"`
	UpdateTime  field.Timestamp       `gorm:"->;column:update_time;autoUpdateTime;not null;autoUpdateTime" json:"updateTime" default:"now"`
}

func (*DataHistory) TableName() string {
	return TableNameDataHistory
}

func (*DataHistory) Database() *gorm.DB {
	return resource.GormClientDataPlat
}

func (*DataHistory) MaxVersion(ctx context.Context, did int64) (int, error) {
	var max sql.NullInt64
	err := WithContext(ctx, resource.GormClientDataPlat).Model(&DataHistory{}).Where("did = ?", did).Select("max(version)").Row().Scan(&max)

	if err != nil {
		return 0, err
	}
	if !max.Valid {
		return 0, nil
	}
	return int(max.Int64), nil
}

func (*DataHistory) MaxVersionData(ctx context.Context, did int64) (*DataHistory, error) {
	dest := DataHistory{}
	result := WithContext(ctx, resource.GormClientDataPlat).Where("did = ?", did).Order("version desc").Limit(1).First(&dest)

	if result.Error != nil {
		return nil, result.Error
	}

	return &dest, nil
}

func (*DataHistory) GetLatestData(ctx context.Context, id int64) (*DataHistory, error) {
	dest := DataHistory{}
	result := WithContext(ctx, resource.GormClientDataPlat).Where("did = ?", id).Order("version desc").Limit(1).First(&dest)

	if result.Error != nil {
		return nil, result.Error
	}

	return &dest, nil
}

func (*DataHistory) GetTargetVersionData(ctx context.Context, did int64, version int) (*DataHistory, error) {
	dest := DataHistory{}
	result := WithContext(ctx, resource.GormClientDataPlat).Where("did = ? and version = ?", did, version).First(&dest)

	if result.Error != nil {
		return nil, result.Error
	}

	return &dest, nil
}

func (*DataHistory) GetNearestDataByVersion(ctx context.Context, did int64, version int) (*DataHistory, error) {
	dest := DataHistory{}
	result := WithContext(ctx, resource.GormClientDataPlat).Where("did = ? and version < ?", did, version).Order("version desc").Limit(1).First(&dest)
	if result.Error != nil {
		return nil, result.Error
	}
	return &dest, nil
}
