/*
 * @Author: yandong03 yandong03@baidu.com
 * @Date: 2024-07-24 18:01:29
 * @LastEditors: yandong03 yandong03@baidu.com
 * @LastEditTime: 2024-08-01 16:19:41
 * @FilePath: /data-platform/model/dao/mdb/event_log.go
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
package mdb

import (
	"context"

	"gorm.io/gorm"
	"icode.baidu.com/baidu/ps-se-go/restful/field"

	custom_field "icode.baidu.com/baidu/search/data-platform/library/field"
	"icode.baidu.com/baidu/search/data-platform/library/resource"
)

const TableNameEventLog = "event_logs"

// Gorm 说明文档：
//   [This] V2: https://gorm.io/docs/models.html#Creating-Updating-Time-Unix-Milli-Nano-Seconds-Tracking
// 	        V1： https://v1.gorm.io/docs/models.html
// 更新数据时，只会兼容Gorm中的部分属性
//
// 结构体中定义的属性由两部分程序接管：
// 	1. column/primaryKey/default 由自由程序接管处理
//  2. <-:create/->/<- 由GORM程序接管处理(在执行GORM中方法的时会自动识别，无需程序关注)

type EventLog struct {
	ID         int64                 `gorm:"column:id;primaryKey;autoIncrement;comment:唯一标识" json:"id"`
	DID        int64                 `gorm:"column:did;comment:数据源ID" json:"did"`
	EventType  string                `gorm:"column:event_type;comment:留痕类型, 1、创建维表, 2、编辑数据, 3、数据同步, 4、自动数据配送, 5、手动触发配送" json:"eventType"`
	Content    string                `gorm:"column:content;type:varchar(512);comment:记录事件的详细信息" json:"content"`
	Creator    custom_field.UserType `gorm:"column:creator;comment:触发人，特殊的有几个系统角色, system_delivery：系统配送器, system_syncer:系统同步器" json:"creator" default:"current"`
	DebugLevel int                   `gorm:"column:debug_level;comment:为了方便的记录一些系统日志，通过debug_level限制留痕日志的展示层级，用于系统管理员查看更详细的信息" json:"debugLevel,omitempty"`
	CreateTime field.Timestamp       `gorm:"<-:create;column:create_time;autoCreateTime;comment:创建时间" json:"createTime,omitempty" default:"now"`
	UpdateTime field.Timestamp       `gorm:"->;column:update_time;autoUpdateTime;autoUpdateTime;comment:更新时间" json:"updateTime,omitempty" default:"now"`
}

// TableName Activity's table name
func (*EventLog) TableName() string {
	return TableNameEventLog
}

func (*EventLog) Database() *gorm.DB {
	return resource.GormClientDataPlat
}

func (el *EventLog) add(ctx context.Context, EventType string, did int64, Content string, Creator custom_field.UserType, DebugLevel int) error {
	ins := EventLog{
		EventType:  EventType,
		Content:    Content,
		Creator:    Creator,
		DID:        did,
		DebugLevel: DebugLevel,
	}

	if err := WithContext(ctx, ins.Database()).Create(&ins).Error; err != nil {
		return err
	}
	return nil
}

func (el *EventLog) AddNotice(ctx context.Context, eventType string, did int64, content string, creator custom_field.UserType) error {
	return el.add(ctx, eventType, did, content, creator, resource.LevelNotice)
}

func (el *EventLog) AddDebug(ctx context.Context, eventType string, did int64, content string, creator custom_field.UserType) error {
	return el.add(ctx, eventType, did, content, creator, resource.LevelDebug)
}
