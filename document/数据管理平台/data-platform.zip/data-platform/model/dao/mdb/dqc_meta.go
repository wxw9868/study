/*
 * @Author: yandong03 yandong03@baidu.com
 * @Date: 2024-08-14 19:51:49
 * @LastEditors: yandong03 yandong03@baidu.com
 * @LastEditTime: 2024-08-20 12:55:09
 * @FilePath: /data-platform/model/dao/mdb/dqc_meta.go
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
package mdb

import (
	"gorm.io/gorm"
	"icode.baidu.com/baidu/ps-se-go/restful/field"

	custom_field "icode.baidu.com/baidu/search/data-platform/library/field"
	"icode.baidu.com/baidu/search/data-platform/library/resource"
)

const TableNameDqcMeta = "dqc_meta"

// Gorm 说明文档：
//   [This] V2: https://gorm.io/docs/models.html#Creating-Updating-Time-Unix-Milli-Nano-Seconds-Tracking
// 	        V1： https://v1.gorm.io/docs/models.html
// 更新数据时，只会兼容Gorm中的部分属性
//
// 结构体中定义的属性由两部分程序接管：
// 	1. column/primaryKey/default 由自由程序接管处理
//  2. <-:create/->/<- 由GORM程序接管处理(在执行GORM中方法的时会自动识别，无需程序关注)

type DqcMeta struct {
	ID           int64                 `gorm:"column:id;primaryKey;autoIncrement" json:"id"`
	Name         string                `gorm:"column:name;unique" json:"name" validate:"required"`
	Chname       string                `gorm:"column:chname" json:"chname"`
	SourceType   string                `gorm:"column:source_type" json:"sourceType"`
	SourceParams field.JSONObject      `gorm:"column:source_params" json:"sourceParams"`
	Schema       field.JSONObject      `gorm:"column:schema;type:text" json:"schema"`
	NoticeConfig field.JSONObject      `gorm:"column:notice_config;type:text" json:"noticeConfig"`
	Creator      custom_field.UserType `gorm:"column:creator" json:"creator" default:"current"`
	Modifier     custom_field.UserType `gorm:"column:modifier" json:"modifier" default:"current"`
	CreateTime   field.Timestamp       `gorm:"<-:create;column:create_time;autoCreateTime;" json:"createTime" default:"now"`
	UpdateTime   field.Timestamp       `gorm:"->;column:update_time;autoUpdateTime;autoUpdateTime" json:"updateTime" default:"now"`
}

// TableName Activity's table name
func (*DqcMeta) TableName() string {
	return TableNameDqcMeta
}

func (*DqcMeta) Database() *gorm.DB {
	return resource.GormClientDataPlat
}
