package mdb

import (
	"gorm.io/gorm"
	"icode.baidu.com/baidu/ps-se-go/restful/field"
	custom_field "icode.baidu.com/baidu/search/data-platform/library/field"
	"icode.baidu.com/baidu/search/data-platform/library/resource"
)

const TableNameDQCJob = "dqc_job"

// Gorm 说明文档：
//   [This] V2: https://gorm.io/docs/models.html#Creating-Updating-Time-Unix-Milli-Nano-Seconds-Tracking
// 	        V1： https://v1.gorm.io/docs/models.html
// 更新数据时，只会兼容Gorm中的部分属性
//
// 结构体中定义的属性由两部分程序接管：
// 	1. column/primaryKey/default 由自由程序接管处理
//  2. <-:create/->/<- 由GORM程序接管处理(在执行GORM中方法的时会自动识别，无需程序关注)

type DqcJob struct {
	ID          int                   `gorm:"column:id;primaryKey;autoIncrement" json:"id"`
	Title       string                `gorm:"column:title;size:256;not null" json:"title" validate:"required"`
	Description string                `gorm:"column:description;size:1024;not null" json:"description" validate:"required"`
	Status      int8                  `gorm:"column:status;size:4;not null" json:"status"` // 使用 int8 对应 tinyint
	Creator     custom_field.UserType `gorm:"column:creator;size:45;not null" json:"creator" default:"current"`
	CreateTime  field.Timestamp       `gorm:"<-:create;column:create_time;autoCreateTime" json:"createTime"`
	UpdateTime  field.Timestamp       `gorm:"->;column:update_time;autoUpdateTime" json:"updateTime"`
}

// TableName DQCJob's table name
func (*DqcJob) TableName() string {
	return TableNameDQCJob
}

func (*DqcJob) Database() *gorm.DB {
	return resource.GormClientDataPlat
}
