package mdb

import (
	"gorm.io/gorm"
	"icode.baidu.com/baidu/ps-se-go/restful/field"

	custom_field "icode.baidu.com/baidu/search/data-platform/library/field"
	"icode.baidu.com/baidu/search/data-platform/library/resource"
)

const TableNameAsyncTask = "async_task"

type AsyncTask struct {
	ID           int64                 `gorm:"column:id;primaryKey;autoIncrement;comment:唯一标识" json:"id"`
	TaskType     string                `gorm:"column:task_type;size:45;not null" json:"taskType"`
	Name         string                `gorm:"column:name;size:256;not null" json:"name"`
	TaskParams   field.JSONObject      `gorm:"column:task_params;type:text" json:"taskParams"`
	SubmitParams string                `gorm:"column:submit_params;size:512;not null" json:"submitParams"`
	TaskResult   field.JSONObject      `gorm:"column:task_result;type:text" json:"taskResult"`
	Status       int                   `gorm:"column:status;type:tinyint;not null;default:0" json:"status"`
	Creator      custom_field.UserType `gorm:"column:creator;size:45;not null" json:"creator"`
	CreateTime   field.Timestamp       `gorm:"column:create_time;not null;default:CURRENT_TIMESTAMP" json:"createTime"`
	UpdateTime   field.Timestamp       `gorm:"column:update_time;not null;default:CURRENT_TIMESTAMP;autoUpdateTime" json:"updateTime"`
}

func (st *AsyncTask) TableName() string {
	return TableNameAsyncTask
}

func (st *AsyncTask) Database() *gorm.DB {
	return resource.GormClientDataPlat
}
