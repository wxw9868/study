/*
 * @Author: yandong03 yandong03@baidu.com
 * @Date: 2024-11-07 14:34:44
 * @LastEditors: yandong03 yandong03@baidu.com
 * @LastEditTime: 2024-11-07 14:36:29
 * @FilePath: /data-platform/model/dao/mdb/user_feature.go
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
package mdb

import (
	"time"

	"gorm.io/gorm"
	"icode.baidu.com/baidu/ps-se-go/restful/field"

	custom_field "icode.baidu.com/baidu/search/data-platform/library/field"
	"icode.baidu.com/baidu/search/data-platform/library/resource"
)

const TableNameUserFeature = "user_feature"

// Gorm 说明文档：
//   [This] V2: https://gorm.io/docs/models.html#Creating-Updating-Time-Unix-Milli-Nano-Seconds-Tracking
// 	        V1： https://v1.gorm.io/docs/models.html
// 更新数据时，只会兼容Gorm中的部分属性
//
// 结构体中定义的属性由两部分程序接管：
// 	1. column/primaryKey/default 由自由程序接管处理
//  2. <-:create/->/<- 由GORM程序接管处理(在执行GORM中方法的时会自动识别，无需程序关注)

type UserFeature struct {
	ID          int64                 `gorm:"column:id;primaryKey;autoIncrement;comment:唯一标识" json:"id"`
	Name        string                `gorm:"column:table_name" json:"tableName"`
	TableType   string                `gorm:"column:table_type" json:"tableType"`
	Category    string                `gorm:"column:category" json:"category"`
	TableParams field.JSONObject      `gorm:"column:table_params" json:"tableParams"`
	TableColumn field.JSONObject      `gorm:"column:table_column" json:"tableColumn"`
	TableDesc   string                `gorm:"column:table_desc" json:"tableDesc"`
	Creator     custom_field.UserType `gorm:"column:creator" json:"creator" default:"current"`
	CreateTime  time.Time             `gorm:"<-:create;column:create_time" json:"createTime,omitempty"`
	UpdateTime  time.Time             `gorm:"->;column:update_time" json:"updateTime,omitempty"`
}

func (st *UserFeature) TableName() string {
	return TableNameUserFeature
}

func (st *UserFeature) Database() *gorm.DB {
	return resource.GormClientDataPlat
}
