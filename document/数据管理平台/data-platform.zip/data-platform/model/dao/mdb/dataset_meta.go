/*
 * @Author: weiyongcheng weiyongcheng@baidu.com
 * @Date: 2024-11-25 16:51:49
 * @LastEditors: weiyongcheng weiyongcheng@baidu.com
 * @LastEditTime: 2024-11-25 16:55:09
 * @FilePath: /data-platform/model/dao/mdb/dataset_meta.go
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
package mdb

import (
	"context"
	"gorm.io/gorm"

	"icode.baidu.com/baidu/ps-se-go/restful/field"
	custom_field "icode.baidu.com/baidu/search/data-platform/library/field"
	"icode.baidu.com/baidu/search/data-platform/library/resource"
)

const TableNameDatasetMeta = "dataset_meta"

type DatasetMeta struct {
	ID            int64                 `gorm:"column:id;primaryKey;autoIncrement" json:"id"`
	Name          string                `gorm:"column:name;unique" json:"name" validate:"required"`
	Chname        string                `gorm:"column:chname" json:"chname"`
	DataSchema    field.JSONObject      `gorm:"column:data_schema;type:text" json:"dataSchema"` // 数据集 schema json 结构
	PreviewData   string                `gorm:"column:preview_data;type:text" json:"previewData"`
	HasHeader     int                   `gorm:"column:has_header" json:"hasHeader"`
	TargetType    string                `gorm:"column:target_type;default:afs" json:"targetType"`
	TargetParams  field.JSONObject      `gorm:"column:target_params" json:"targetParams"`
	DataSource    string                `gorm:"column:data_source" json:"dataSource"`
	Description   string                `gorm:"column:desc" json:"description"`
	Creator       custom_field.UserType `gorm:"column:creator" json:"creator" default:"current"`
	Modifier      custom_field.UserType `gorm:"column:modifier" json:"modifier" default:"current"`
	ContactPerson string                `gorm:"column:contact_person" json:"contactPerson"`
	CreateTime    field.Timestamp       `gorm:"<-:create;column:create_time;autoCreateTime" json:"createTime" default:"now"`
	UpdateTime    field.Timestamp       `gorm:"->;column:update_time;autoUpdateTime" json:"updateTime" default:"now"`
}

func (*DatasetMeta) TableName() string {
	return TableNameDatasetMeta
}

func (*DatasetMeta) Database() *gorm.DB {
	return resource.GormClientDataPlat
}

func (*DatasetMeta) GetAllData(ctx context.Context) (*[]DatasetMeta, error) {
	var datasetData []DatasetMeta
	result := WithContext(ctx, resource.GormClientDataPlat).Find(&datasetData)

	if result.Error != nil {
		return nil, result.Error
	}

	return &datasetData, nil
}

func (*DatasetMeta) UpdateData(ctx context.Context, dataset DatasetMeta) (any, error) {
	result := WithContext(ctx, resource.GormClientDataPlat).Save(&dataset)
	if result.Error != nil {
		return nil, result.Error
	}

	return result, nil
}
