package mdb

import (
	"gorm.io/gorm"
	"icode.baidu.com/baidu/ps-se-go/restful/field"
	custom_field "icode.baidu.com/baidu/search/data-platform/library/field"
	"icode.baidu.com/baidu/search/data-platform/library/resource"
)

const TableNameDQCTask = "dqc_task"

// Gorm 说明文档：
//   [This] V2: https://gorm.io/docs/models.html#Creating-Updating-Time-Unix-Milli-Nano-Seconds-Tracking
// 	        V1： https://v1.gorm.io/docs/models.html
// 更新数据时，只会兼容Gorm中的部分属性
//
// 结构体中定义的属性由两部分程序接管：
// 	1. column/primaryKey/default 由自由程序接管处理
//  2. <-:create/->/<- 由GORM程序接管处理(在执行GORM中方法的时会自动识别，无需程序关注)

type DqcTask struct {
	ID            int                   `gorm:"column:id;primaryKey;autoIncrement" json:"id"`
	JobID         int                   `gorm:"column:job_id;not null" json:"jobId"`
	FatherID      int                   `gorm:"column:father_id;not null" json:"fatherId"`
	Title         string                `gorm:"column:title;size:128;not null" json:"title" validate:"required"`
	Description   string                `gorm:"column:description;size:1024;not null" json:"description" validate:"required"`
	Type          string                `gorm:"column:type;size:45;not null;comment:'类型，单表校检还是多表校检'" json:"type"`
	DataIDs       custom_field.JSONList `gorm:"column:data_ids;size:45;not null;default:'[]'" json:"dataIds"`
	Progress      string                `gorm:"column:progress;default:''" json:"progress"`
	Params        field.JSONObject      `gorm:"column:params;type:text;default:'{}'" json:"params"`
	Rules         custom_field.JSONList `gorm:"column:rules;type:text" json:"rules"`                // 使用自定义类型或 `string` 替代
	Status        int8                  `gorm:"column:status;size:4;not null" json:"status"`        // 使用 int8 对应 tinyint
	DqcStatus     int8                  `gorm:"column:dqc_status;size:4;not null" json:"dqcStatus"` // 使用 int8 对应 tinyint
	TriggerSource string                `gorm:"column:trigger_source;size:4;not null" json:"triggerSource"`
	MDResult      string                `gorm:"column:md_result;type:text" json:"mdResult"` // 使用自定义类型或 `string` 替代
	Creator       custom_field.UserType `gorm:"column:creator;size:45;not null" json:"creator" default:"current"`
	Modifier      custom_field.UserType `gorm:"column:modifier;size:45;not null" json:"modifier" default:"current"`
	CreateTime    field.Timestamp       `gorm:"<-:create;column:create_time;autoCreateTime" json:"createTime"`
	UpdateTime    field.Timestamp       `gorm:"->;column:update_time;autoUpdateTime" json:"updateTime"`
}

// TableName DQCTask's table name
func (*DqcTask) TableName() string {
	return TableNameDQCTask
}

func (*DqcTask) Database() *gorm.DB {
	return resource.GormClientDataPlat
}
