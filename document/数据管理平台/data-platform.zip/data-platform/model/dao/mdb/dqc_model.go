package mdb

import (
	"time"

	"gorm.io/gorm"
	"icode.baidu.com/baidu/ps-se-go/restful/field"
	custom_field "icode.baidu.com/baidu/search/data-platform/library/field"
	"icode.baidu.com/baidu/search/data-platform/library/resource"
)

const TableNameDataModel = "dqc_model"

type DqcModel struct {
	ID          int64                 `gorm:"column:id;primaryKey;autoIncrement" json:"id"`
	ConnectorID int                   `gorm:"column:connector_id" json:"connectorId"`
	Name        string                `gorm:"column:name" json:"name"`
	Type        string                `gorm:"column:type" json:"type"`
	Chname      string                `gorm:"column:chname" json:"chname"`
	Params      field.JSONObject      `gorm:"column:params;type:text" json:"params"`
	Description string                `gorm:"column:description" json:"description"`
	Columns     custom_field.JSONList `gorm:"column:columns;type:text" json:"columns"`
	Creator     custom_field.UserType `gorm:"column:creator" json:"creator" default:"current"`
	Modifier    custom_field.UserType `gorm:"column:modifier" json:"modifier" default:"current"`
	CreateTime  time.Time             `gorm:"<-:create;column:create_time;autoCreateTime" json:"create_time"`
	UpdateTime  time.Time             `gorm:"->;column:update_time;autoUpdateTime" json:"update_time"`
}

// TableName 设置表名
func (*DqcModel) TableName() string {
	return TableNameDataModel
}

func (*DqcModel) Database() *gorm.DB {
	return resource.GormClientDataPlat
}
