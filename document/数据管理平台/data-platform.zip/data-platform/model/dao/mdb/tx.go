package mdb

import (
	"context"
	"sync"

	"gorm.io/gorm"
)

func WithContext(ctx context.Context, db *gorm.DB) *gorm.DB {
	if tx, ok := ctx.Value(txContext{}).(*gorm.DB); ok {
		return tx
	}
	return db.WithContext(ctx)
}

var tx *transaction
var once sync.Once

type txFunc func(context.Context, *gorm.DB, func(context.Context) error) error

type transaction struct {
	handle txFunc
}

func (t *transaction) Execute(ctx context.Context, db *gorm.DB, f func(c context.Context) error) error {
	return t.handle(ctx, db, f)
}

func NewTransaction(f txFunc) *transaction {
	return &transaction{handle: f}
}

type txContext struct{}

func GetTransaction() *transaction {
	once.Do(func() {
		f := func(ctx context.Context, db *gorm.DB, f func(context.Context) error) error {
			return db.Transaction(func(tx *gorm.DB) error {
				c := context.WithValue(ctx, txContext{}, tx)
				return f(c)
			})
		}
		tx = NewTransaction(f)
	})
	return tx
}
