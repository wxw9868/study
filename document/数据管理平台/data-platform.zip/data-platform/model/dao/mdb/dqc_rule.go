package mdb

import (
	"time"

	"gorm.io/gorm"
	custom_field "icode.baidu.com/baidu/search/data-platform/library/field"

	"icode.baidu.com/baidu/search/data-platform/library/resource"
)

const TableNameDataRule = "dqc_rule"

type DqcRule struct {
	ID         int64                 `gorm:"column:id;primaryKey;autoIncrement" json:"id"`
	Type       string                `gorm:"column:type;size:45;not null" json:"type"`
	RuleType   string                `gorm:"column:rule_type;size:128;not null" json:"ruleType"`
	Name       string                `gorm:"column:name;size:256;not null" json:"name"`
	Params     custom_field.JSONList `gorm:"column:params;type:text;not null" json:"params"` // 使用 JSON 类型来存储参数
	Category   string                `gorm:"column:category;size:45;not null" json:"category"`
	Creator    custom_field.UserType `gorm:"column:creator;size:45;not null" json:"creator" default:"current"`
	Modifier   custom_field.UserType `gorm:"column:modifier;size:45;not null" json:"modifier" default:"current"`
	CreateTime time.Time             `gorm:"column:create_time;not null;autoCreateTime" json:"createTime"`
	UpdateTime time.Time             `gorm:"column:update_time;not null;autoUpdateTime" json:"updateTime"`
}

// TableName 设置表名
func (*DqcRule) TableName() string {
	return TableNameDataRule
}

// Database 返回数据库实例
func (*DqcRule) Database() *gorm.DB {
	return resource.GormClientDataPlat
}
