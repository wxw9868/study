/*
 * @Author: houming01 houming01@baidu.com
 * @Date: 2024-10-21 10:33:57
 * @LastEditors: houming01 houming01@baidu.com
 * @LastEditTime: 2024-10-21 16:36:37
 * @FilePath: /data-platform/model/dao/mdb/jupyter_task_params.go
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */

package mdb

import (
	"context"
	"errors"
	"time"

	"gorm.io/gorm"
	"icode.baidu.com/baidu/gdp/logit"
	custom_field "icode.baidu.com/baidu/search/data-platform/library/field"
	"icode.baidu.com/baidu/search/data-platform/library/resource"
)

const TableNameBusinessData = "business_data"

type BusinessData struct {
	ID                  int                   `gorm:"primaryKey;autoIncrement;comment:自增ID" json:"id"`
	BusinessDirection   string                `gorm:"column:business_direction;comment:业务方向，表明具体业务方向" json:"business_direction"`
	ApplicationScenario string                `gorm:"column:application_scenario;comment:应用场景，标识数据的具体应用场景" json:"application_scenario"`
	DataAddr            string                `gorm:"column:data_addr;not null;comment:数据地址，具体的afs文件地址" json:"data_addr"`
	UGI                 string                `gorm:"column:ugi;not null;comment:afs ugi" json:"ugi"`
	Version             int                   `gorm:"not null;default:1;comment:版本号，用于标识data_address是否发生改变" json:"version"`
	LocalAddr           string                `gorm:"column:local_addr;not null;unique;comment:全局唯一，数据下载到本地时的相对路径名称" json:"local_addr"`
	CreatedBy           custom_field.UserType `gorm:"column:created_by;not null;comment:创建人" json:"created_by" default:"current"`
	UpdatedBy           custom_field.UserType `gorm:"column:updated_by;not null;comment:最近修改人" json:"updated_by" default:"current"`
	CreatedAt           time.Time             `gorm:"column:created_at;type:timestamp;default:current_timestamp;comment:创建时间" json:"created_at"`
	UpdatedAt           time.Time             `gorm:"column:updated_at;type:timestamp;default:current_timestamp;comment:最后修改时间;autoUpdateTime" json:"updated_at"`
}

func NewBusinessData() *BusinessData {
	return &BusinessData{}
}

func (b *BusinessData) TableName() string {
	return TableNameBusinessData
}

func (b *BusinessData) Database() *gorm.DB {
	return resource.GormClientDataPlat
}

func (b *BusinessData) GetQuery(ctx context.Context) *gorm.DB {
	query := WithContext(ctx, b.Database()).Model(b)
	return query
}

func (b *BusinessData) FindOneRecord(ctx context.Context, cond map[string]any) ([]BusinessData, error) {
	var businessData []BusinessData
	query := b.GetQuery(ctx)
	result := query.Where(cond).Find(&businessData).Limit(1)
	if result.Error != nil && !errors.Is(result.Error, gorm.ErrRecordNotFound) {
		logit.AddNotice(ctx, logit.AutoField("FindRecord_err", result.Error), logit.AutoField("FindRecord_cond", cond))
		return businessData, result.Error
	}
	return businessData, nil
}
