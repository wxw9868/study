/*
 * @Author: yandong03 yandong03@baidu.com
 * @Date: 2024-08-27 15:04:37
 * @LastEditors: yandong03 yandong03@baidu.com
 * @LastEditTime: 2024-09-09 14:35:15
 * @FilePath: /data-platform/model/dao/mdb/science_task.go
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
package mdb

import (
	"gorm.io/gorm"
	"icode.baidu.com/baidu/ps-se-go/restful/field"

	custom_field "icode.baidu.com/baidu/search/data-platform/library/field"
	"icode.baidu.com/baidu/search/data-platform/library/resource"
)

const TableNameScienceTask = "science_task"

// Gorm 说明文档：
//   [This] V2: https://gorm.io/docs/models.html#Creating-Updating-Time-Unix-Milli-Nano-Seconds-Tracking
// 	        V1： https://v1.gorm.io/docs/models.html
// 更新数据时，只会兼容Gorm中的部分属性
//
// 结构体中定义的属性由两部分程序接管：
// 	1. column/primaryKey/default 由自由程序接管处理
//  2. <-:create/->/<- 由GORM程序接管处理(在执行GORM中方法的时会自动识别，无需程序关注)

type ScienceTask struct {
	ID           int64                 `gorm:"column:id;primaryKey;autoIncrement;comment:唯一标识" json:"id"`
	Name         string                `gorm:"column:name" json:"name"`
	TaskType     string                `gorm:"column:task_type" json:"taskType"`
	TaskParams   field.JSONObject      `gorm:"column:task_params" json:"taskParams"`
	Status       int                   `gorm:"column:status" json:"status"`
	TID          string                `gorm:"column:tid" json:"tid"`
	Result       field.JSONObject      `gorm:"column:result" json:"result"`
	ScheduleType int                   `gorm:"column:schedule_type" json:"scheduleType"`
	Creator      custom_field.UserType `gorm:"column:creator" json:"creator" default:"current"`
	CreateTime   field.Timestamp       `gorm:"<-:create;column:create_time" json:"createTime,omitempty"`
	UpdateTime   field.Timestamp       `gorm:"->;column:update_time" json:"updateTime,omitempty"`
	FinishTime   field.Timestamp       `gorm:"column:finish_time" json:"finishTime,omitempty"`
}

func (st *ScienceTask) TableName() string {
	return TableNameScienceTask
}

func (st *ScienceTask) Database() *gorm.DB {
	return resource.GormClientDataPlat
}
