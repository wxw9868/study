package mdb

import (
	"context"
	"time"

	"gorm.io/gorm"
	"icode.baidu.com/baidu/search/data-platform/library/resource"
)

const TableNameFunctionMeta = "function_meta"

type FunctionMeta struct {
	ID          int64     `gorm:"column:id;primaryKey;autoIncrement" json:"id"`
	FuncSetName string    `gorm:"column:func_set_name" json:"funcSetName"`             // 函数集名称
	FuncSetDesc string    `gorm:"column:func_set_desc" json:"funcSetDesc"`             // 函数集描述
	FuncName    string    `gorm:"column:func_name;unique" json:"funcName"`             // 函数名称
	FuncDesc    string    `gorm:"column:func_desc" json:"funcDesc"`                    // 函数描述
	Creator     string    `gorm:"column:creator" json:"creator"`                       // 创建人
	Modifier    string    `gorm:"column:modifier" json:"modifier"`                     // 最近修改人
	Example     string    `gorm:"column:example;type:text" json:"example"`             // 代码片段
	CreateTime  time.Time `gorm:"column:create_time;autoCreateTime" json:"createTime"` // 创建时间
	UpdateTime  time.Time `gorm:"column:update_time;autoUpdateTime" json:"updateTime"` // 更新时间
}

func (*FunctionMeta) TableName() string {
	return TableNameFunctionMeta
}

func (*FunctionMeta) Database() *gorm.DB {
	return resource.GormClientDataPlat
}

func (*FunctionMeta) GetFunctionSetData(ctx context.Context, funcSetName string) (*[]FunctionMeta, error) {
	var functionSetData []FunctionMeta

	query := WithContext(ctx, resource.GormClientDataPlat).
		Model(&FunctionMeta{}).
		Select("func_set_name, MIN(func_set_desc) AS func_set_desc").
		Group("func_set_name")

	if funcSetName != "" {
		query = query.Where("func_set_name LIKE ?", "%"+funcSetName+"%")
	}

	result := query.Scan(&functionSetData)

	if result.Error != nil {
		return nil, result.Error
	}

	return &functionSetData, nil
}

func (*FunctionMeta) GetFunctionList(ctx context.Context, funcSetName string, funcName string) (*[]FunctionMeta, error) {
	var functionData []FunctionMeta

	db := WithContext(ctx, resource.GormClientDataPlat).Where("func_set_name = ?", funcSetName)

	if funcName != "" {
		db = db.Where("func_name LIKE ?", "%"+funcName+"%")
	}

	result := db.Find(&functionData)
	if result.Error != nil {
		return nil, result.Error
	}
	return &functionData, nil
}

func (*FunctionMeta) GetFunctionDataByID(ctx context.Context, id int64) (*FunctionMeta, error) {
	var functionData FunctionMeta

	result := WithContext(ctx, resource.GormClientDataPlat).Where("id = ?", id).First(&functionData)

	if result.Error != nil {
		return nil, result.Error
	}

	return &functionData, nil
}
