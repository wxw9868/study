package mdb

import (
	"time"

	"gorm.io/gorm"

	"icode.baidu.com/baidu/search/data-platform/library/resource"
)

const TableNameSLATdsMonitor = "sla_tds_monitor"

// Gorm 说明文档：
//   [This] V2: https://gorm.io/docs/models.html#Creating-Updating-Time-Unix-Milli-Nano-Seconds-Tracking
// 	        V1： https://v1.gorm.io/docs/models.html
// 更新数据时，只会兼容Gorm中的部分属性
//
// 结构体中定义的属性由两部分程序接管：
// 	1. column/primaryKey/default 由自由程序接管处理
//  2. <-:create/->/<- 由GORM程序接管处理(在执行GORM中方法的时会自动识别，无需程序关注)

type SLATdsMonitor struct {
	ID                 int       `gorm:"column:id;primaryKey;autoIncrement" json:"id"`
	TaskID             int       `gorm:"column:task_id;not null" json:"task_id"`
	MonitorID          int       `gorm:"column:monitor_id;not null" json:"monitor_id"`
	TaskName           string    `gorm:"column:task_name;size:128;not null" json:"task_name"`
	MonitorName        string    `gorm:"column:monitor_name;size:128;not null" json:"monitor_name"`
	MonitorDescription string    `gorm:"column:monitor_description;size:128;not null" json:"monitor_description"`
	MonitorOperator    string    `gorm:"column:monitor_operator;size:128;not null'" json:"monitor_operator"`
	MonitorType        string    `gorm:"column:monitor_type;size:45;not null" json:"monitor_type"`
	TaskStatus         string    `gorm:"column:task_status;size:45" json:"task_status"`
	TaskURL            string    `gorm:"column:task_url;size:1024;not null" json:"task_url"`
	CreateTime         time.Time `gorm:"column:start_time" json:"createTime"`
	UpdateTime         time.Time `gorm:"column:update_time" json:"updateTime"`
	RunTime            string    `gorm:"column:runtime" json:"runtime"`
	RetryCount         int       `gorm:"column:retry_count;not null" json:"retry_count"`
}

// TableName DQCTask's table name
func (*SLATdsMonitor) TableName() string {
	return TableNameSLATdsMonitor
}

func (*SLATdsMonitor) Database() *gorm.DB {
	return resource.GormClientDataPlat
}
