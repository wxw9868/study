/*
 * @Author: yandong03 yandong03@baidu.com
 * @Date: 2024-09-09 11:41:50
 * @LastEditors: yandong03 yandong03@baidu.com
 * @LastEditTime: 2024-09-13 14:37:04
 * @FilePath: /data-platform/model/dao/mdb/science_task_run_history.go
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
package mdb

import (
	"gorm.io/gorm"
	"icode.baidu.com/baidu/ps-se-go/restful/field"
	"icode.baidu.com/baidu/search/data-platform/library/resource"
)

const TableNameScienceTaskRunHistory = "task_run_history"

type TaskRunHistory struct {
	ID         int64            `gorm:"column:id;primaryKey;autoIncrement;comment:唯一标识" json:"id"`
	TaskType   string           `gorm:"column:task_type" json:"taskType"`
	TaskID     int64            `gorm:"column:task_id;not null" json:"taskId"`
	JobID      string           `gorm:"column:job_id;size:64;not null" json:"jobId"`
	TaskParams field.JSONObject `gorm:"column:task_params" json:"taskParams"`
	TID        string           `gorm:"column:tid;size:64;not null" json:"tid"`
	RunType    string           `gorm:"column:run_type;size:45;not null" json:"runType"`
	Status     int              `gorm:"column:status;not null" json:"status"`
	Result     field.JSONObject `gorm:"column:result;type:mediumtext;not null" json:"result"`
	FinishTime field.Timestamp  `gorm:"column:finish_time;not null" json:"finishTime"`
	CreateTime field.Timestamp  `gorm:"<-:create;column:create_time" json:"createTime,omitempty"`
	UpdateTime field.Timestamp  `gorm:"->;column:update_time" json:"updateTime,omitempty"`
}

func (trh *TaskRunHistory) TableName() string {
	return TableNameScienceTaskRunHistory
}

func (trh *TaskRunHistory) Database() *gorm.DB {
	return resource.GormClientDataPlat
}
