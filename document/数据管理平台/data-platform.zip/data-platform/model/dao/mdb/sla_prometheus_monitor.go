package mdb

import (
	"gorm.io/gorm"

	"icode.baidu.com/baidu/search/data-platform/library/resource"
)

const TableNameSLAPrometheusMonitor = "sla_prometheus_monitor"

// Gorm 说明文档：
//   [This] V2: https://gorm.io/docs/models.html#Creating-Updating-Time-Unix-Milli-Nano-Seconds-Tracking
// 	        V1： https://v1.gorm.io/docs/models.html
// 更新数据时，只会兼容Gorm中的部分属性
//
// 结构体中定义的属性由两部分程序接管：
// 	1. column/primaryKey/default 由自由程序接管处理
//  2. <-:create/->/<- 由GORM程序接管处理(在执行GORM中方法的时会自动识别，无需程序关注)

type SLAPrometheusMonitor struct {
	ID               int64  `gorm:"column:id;primaryKey;autoIncrement" json:"id"`
	AccountID        string `gorm:"column:account_id;size:128;not null" json:"accountId"`
	AlarmTags        string `gorm:"column:alarm_tags;not null" json:"alarmTags"`
	AlarmValue       string `gorm:"column:alarmValue;size:128;not null" json:"alarmValue"`
	AlertingRuleID   string `gorm:"column:alertingRuleId;size:128;not null" json:"alertingRuleId"`
	AlertingRuleName string `gorm:"column:alertingRuleName;size:128;not null" json:"alertingRuleName"`
	EndTime          int64  `gorm:"column:end_time;not null" json:"endTime"`
	EventID          string `gorm:"column:event_id;size:128;not null" json:"eventId"`
	EventTags        string `gorm:"column:event_tags;not null" json:"eventTags"`
	Severity         string `gorm:"column:severity;size:128;not null" json:"severity"`
	StartTime        int64  `gorm:"column:start_time;not null" json:"startTime"`
	Status           string `gorm:"column:status;size:128;not null" json:"status"`
	Token            string `gorm:"column:token;size:128;not null" json:"token"`
}

// TableName DQCTask's table name
func (*SLAPrometheusMonitor) TableName() string {
	return TableNameSLAPrometheusMonitor
}

func (*SLAPrometheusMonitor) Database() *gorm.DB {
	return resource.GormClientDataPlat
}
