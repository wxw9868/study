package mdb

import (
	"context"

	"gorm.io/gorm"
	"icode.baidu.com/baidu/ps-se-go/restful/field"
	"icode.baidu.com/baidu/search/data-platform/library/resource"
)

const TableNameDqcConnectors = "dqc_connectors"

type DqcConnectors struct {
	ID            int64            `gorm:"column:id;primaryKey;autoIncrement" json:"id"`
	Name          string           `gorm:"column:name" json:"name"`
	Type          string           `gorm:"column:type" json:"type"`
	ConnectorInfo field.JSONObject `gorm:"column:connector_info" json:"connectorInfo"`
	Description   string           `gorm:"column:description" json:"description"`
	ExtraInfo     string           `gorm:"column:extra_info" json:"extra_info"`
	Creator       string           `gorm:"column:creator" json:"creator" default:"current"`
	CreateTime    field.Timestamp  `gorm:"<-:create;column:create_time;autoCreateTime;" json:"createTime"`
	UpdateTime    field.Timestamp  `gorm:"->;column:update_time;autoUpdateTime;" json:"updateTime"`
}

// TableName 方法返回表名
func (*DqcConnectors) TableName() string {
	return TableNameDqcConnectors
}

// Database 方法返回GORM数据库连接
func (*DqcConnectors) Database() *gorm.DB {
	return resource.GormClientDataPlat
}

// 示例方法：获取特定ID的DqcConnectors信息
func (dc *DqcConnectors) GetByID(ctx context.Context, id int64) (*DqcConnectors, error) {
	db := WithContext(ctx, dc.Database())
	var dqc DqcConnectors
	res := db.Where("id = ?", id).First(&dqc)
	if res.Error != nil {
		return nil, res.Error
	}
	return &dqc, nil
}

// 示例方法：列出所有DqcConnectors
func (dc *DqcConnectors) ListAll(ctx context.Context) ([]DqcConnectors, error) {
	var list []DqcConnectors
	db := WithContext(ctx, dc.Database())
	res := db.Find(&list)
	if res.Error != nil {
		return nil, res.Error
	}
	return list, nil
}
