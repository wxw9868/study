/* Copyright 2021 Baidu Inc. All Rights Reserved. */
/* demo.go - */
/*
DESCRIPTION
*/
package mdb

import (
	"context"

	"gorm.io/gorm"
	"icode.baidu.com/baidu/ps-se-go/restful/field"

	custom_field "icode.baidu.com/baidu/search/data-platform/library/field"
	"icode.baidu.com/baidu/search/data-platform/library/resource"
)

const TableNameDataMeta = "data_meta"

// Gorm 说明文档：
//   [This] V2: https://gorm.io/docs/models.html#Creating-Updating-Time-Unix-Milli-Nano-Seconds-Tracking
// 	        V1： https://v1.gorm.io/docs/models.html
// 更新数据时，只会兼容Gorm中的部分属性
//
// 结构体中定义的属性由两部分程序接管：
// 	1. column/primaryKey/default 由自由程序接管处理
//  2. <-:create/->/<- 由GORM程序接管处理(在执行GORM中方法的时会自动识别，无需程序关注)

type DataMeta struct {
	ID                   int64                 `gorm:"column:id;primaryKey;autoIncrement" json:"id"`
	Name                 string                `gorm:"column:name;unique" json:"name" validate:"required"`
	Chname               string                `gorm:"column:chname" json:"chname"`
	DataSchema           field.JSONObject      `gorm:"column:data_schema;type:text" json:"dataSchema"`
	TargetType           string                `gorm:"column:target_type;default:'afs'" json:"targetType"`
	TargetParams         field.JSONObject      `gorm:"column:target_params" json:"targetParams"`
	DType                int                   `gorm:"column:dtype" json:"dtype"`
	MultiTable           string                `gorm:"column:multi_table" json:"multiTable"`
	SType                int                   `gorm:"column:stype" json:"stype"`
	Adaptor              string                `gorm:"column:adaptor" json:"adaptor"`
	AdaptorParams        field.JSONObject      `gorm:"column:adaptor_params" json:"adaptorParams"`
	AdaptorTriggerParams field.JSONObject      `gorm:"column:adaptor_trigger_params" json:"adaptorTriggerParams"`
	AdaptorBlockParams   field.JSONObject      `gorm:"column:adaptor_block_params" json:"adaptorBlockParams"`
	TriggerType          string                `gorm:"column:trigger_type" json:"triggerType"`
	TriggerParams        field.JSONObject      `gorm:"column:trigger_params" json:"triggerParams"`
	AlarmConfig          field.JSONObject      `gorm:"column:alarm_config" json:"alarmConfig"`
	NoticeConfig         field.JSONObject      `gorm:"column:notice_config" json:"noticeConfig"`
	Version              int                   `gorm:"column:version" json:"version"`
	OnlineVersion        int                   `gorm:"column:online_version" json:"onlineVersion" default:"0"`
	Status               int                   `gorm:"column:status" json:"status"`
	Creator              custom_field.UserType `gorm:"column:creator" json:"creator" default:"current"`
	CreateTime           field.Timestamp       `gorm:"<-:create;column:create_time;autoCreateTime;" json:"createTime" default:"now"`
	UpdateTime           field.Timestamp       `gorm:"->;column:update_time;autoUpdateTime;autoUpdateTime" json:"updateTime" default:"now"`
}

// TableName Activity's table name
func (*DataMeta) TableName() string {
	return TableNameDataMeta
}

func (*DataMeta) Database() *gorm.DB {
	return resource.GormClientDataPlat
}

func (dm *DataMeta) GetSchema(ctx context.Context, id int64) (map[string]any, error) {
	db := WithContext(ctx, dm.Database())
	dest := DataMeta{}
	res := db.Where("id = ?", id).First(&dest)
	if res.Error != nil {
		return nil, res.Error
	}
	return dest.DataSchema, nil
}

func (dm *DataMeta) DeliveryList(ctx context.Context) ([]DataMeta, error) {
	var list []DataMeta
	db := WithContext(ctx, dm.Database())
	res := db.Where("version > 0").Where("online_version < version").Where("trigger_type", "schedule").Find(&list)
	if res.Error != nil {
		return list, res.Error
	}
	return list, nil
}

func (dm *DataMeta) OuterSourceList(ctx context.Context) ([]DataMeta, error) {
	var list []DataMeta
	db := WithContext(ctx, dm.Database())
	res := db.Where("stype = 2").Find(&list)
	if res.Error != nil {
		return list, res.Error
	}
	return list, nil
}
