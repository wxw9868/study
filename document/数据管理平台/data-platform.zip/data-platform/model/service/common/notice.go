/*
 * @Author: yandong03 yandong03@baidu.com
 * @Date: 2024-08-07 16:20:16
 * @LastEditors: yandong03 yandong03@baidu.com
 * @LastEditTime: 2024-08-12 11:49:07
 * @FilePath: /data-platform/model/service/common/notice.go
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
package common

import (
	"context"
	"encoding/json"
	"fmt"
	"strconv"

	"icode.baidu.com/baidu/gdp/logit"
	"icode.baidu.com/baidu/ps-se-go/restful/field"
	"icode.baidu.com/baidu/search/data-platform/library/util"
	"icode.baidu.com/baidu/search/data-platform/model/dao/mdb"
)

func SendRobotMessage(ctx context.Context, robotName string, message string, groupID []int64, username string) (resp string, err error) {
	mm := mdb.ManageMeta{}
	robotIns, err := mm.GetRobot(ctx, robotName)
	if err != nil {
		return
	}
	token, ok := robotIns.Params["token"].(string)
	if !ok {
		err = fmt.Errorf("robot token not found")
		return
	}

	robotMessage := util.RobotMessage{}
	robotMessage.AppendMessage(util.NewTextMessage(message))
	robotMessage.AppendMessage(util.NewAtMessage(username))
	robot := util.NewHibotGroup(token, groupID)
	resp, err = robot.SendGroupMsg(ctx, robotMessage)
	if err != nil {
		err = fmt.Errorf("send robot msg failed: %w", err)
		return
	}
	return
}

type noticeConfig struct {
	Enabled bool   `json:"enabled"`
	Robot   string `json:"robot"`
	GroupID string `json:"groupid"`
}

func SendNoticeMessage(ctx context.Context, config field.JSONObject, title string, body string, username string) (resp string, err error) {
	data, _ := config.MarshalJSON()
	var nc noticeConfig
	_ = json.Unmarshal(data, &nc)
	if !nc.Enabled {
		return
	}
	message := fmt.Sprintf("%s\n%s", title, body)
	groupID, _ := strconv.Atoi(nc.GroupID)
	return SendRobotMessage(ctx, nc.Robot, message, []int64{int64(groupID)}, username)
}

func SendNoticeMessagWithMetaID(ctx context.Context, logger logit.Logger, id int64, title string, body string) {
	meta := mdb.DataMeta{}
	if err := mdb.WithContext(ctx, meta.Database()).Where("id = ?", id).First(&meta).Error; err != nil {
		logger.Warning(ctx, "get meta failed before send notice", logit.Error("err", err))
		return
	}
	body = fmt.Sprintf("维表【%s]\n%s", meta.Name, body)
	noticeResp, err := SendNoticeMessage(ctx, meta.NoticeConfig, title, body, string(meta.Creator))
	if err != nil {
		logger.Warning(ctx, "send notice failed", logit.Error("err", err))
		return
	}
	logger.Notice(ctx, "send notice success", logit.String("notice_resp", noticeResp))
}

func SendNoticeMessageWithLoggerOnly(ctx context.Context, logger logit.Logger, config field.JSONObject, title string, body string, username string) {
	noticeResp, err := SendNoticeMessage(ctx, config, title, body, username)
	if err != nil {
		logger.Warning(ctx, "send notice failed", logit.Error("err", err))
		return
	}
	logger.Notice(ctx, "send notice success", logit.String("notice_resp", noticeResp))
}
