/*
 * @Author: v_caoyu05 v_caoyu05@baidu.com
 * @Date: 2024-07-31 16:12:21
 * @LastEditors: v_caoyu05 v_caoyu05@baidu.com
 * @LastEditTime: 2024-09-03 12:27:44
 * @FilePath: /data-platform/cmd/data-sync/ku.go
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
package sync

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"strconv"

	"icode.baidu.com/baidu/search/data-platform/library/util"
)

type OperationAdaptor struct{}

type CronTypeData struct {
	Status int `json:"status"`
	Data   []struct {
		ID          int    `json:"id"`
		DisplayName string `json:"displayName"`
		Status      int    `json:"status"`
	} `json:"data"`
}

type CronTypeEditData struct {
	Status int `json:"status"`
	Data   struct {
		Content struct {
			TrickConfig struct {
				CustomType string `json:"customType"`
			} `json:"trickConfig"`
		} `json:"content"`
	} `json:"data"`
}

type CronTypeActData struct {
	Status int `json:"status"`
	Data   struct {
		Schema struct {
			TaskSchema []struct {
				CustomTask     string `json:"customTask"`
				CustomTaskName string `json:"customTaskName"`
			} `json:"taskSchema"`
		} `json:"schema"`
	} `json:"data"`
}

// Sync Sync 同步数据，获取指定的任务信息并转换为符合要求的格式返回
// ctx context.Context 上下文对象，可用于传递超时或者取消请求等参数
// config map[string]any 配置参数，包含activityTypeOp和activityIdOp两个参数，分别表示任务类型和任务ID
// schema map[string]any 字段映射关系，key为源字段名称，value为目标字段名称
// 返回值 []map[string]string 转换后的数据列表，每一行包含id、display_name、custom_task、custom_taskName四个字段
// map[string]any 汇总信息，包含totalLine字段，表示转换后的数据总行数
// error 错误信息，如果没有错误则为nil
func (ct *OperationAdaptor) Sync(ctx context.Context, config map[string]any, schema map[string]any) ([]map[string]string, map[string]any, error) {
	var (
		d    CronTypeData
		body []byte
		err  error
	)

	// 任务id
	tid := "0"
	if _, ok := config["activityTypeOp"]; !ok {
		return nil, nil, errors.New("missing activityTypeOp parameter")
	}

	if config["activityTypeOp"] == "cron_type" {
		if _, ok := config["activityIdOp"]; !ok {
			return nil, nil, errors.New("missing activityTypeOp parameter")
		}
		tid = config["activityIdOp"].(string)
	} else {
		return nil, nil, errors.New("task not found")
	}

	ret := make([]map[string]string, 0)
	fieldMap := util.SchemaToFieldMap(schema)
	totalLine := 0

	body, err = ct.getData("http://sepro.baidu-int.com/api/hdyy/open/tasks?act=25cny_fission&g_token=u_8UA91A19XYMNQ&page=1&size=999")

	if err != nil {
		return nil, nil, err
	}
	json.Unmarshal(body, &d)

	if d.Status == 0 && len(d.Data) > 0 {
		var td CronTypeActData
		body, err = ct.getData("http://sepro.baidu-int.com/api/hdyy/open/tasks/act/" + tid + "?g_token=u_8UA91A19XYMNQ")
		if err != nil {
			return nil, nil, err
		}
		json.Unmarshal(body, &td)

		if td.Status == 0 && len(td.Data.Schema.TaskSchema) > 0 {
			var url string
			for i := 0; i < len(d.Data); i++ {
				if d.Data[i].Status == 2 {
					continue
				}

				var ed CronTypeEditData
				url = fmt.Sprintf("%s%d%s", "http://sepro.baidu-int.com/api/hdyy/open/tasks/",
					d.Data[i].ID,
					"?act=25cny_fission&g_token=u_8UA91A19XYMNQ")
				body, err = ct.getData(url)
				if err != nil {
					return nil, nil, err
				}
				json.Unmarshal(body, &ed)
				if ed.Status == 0 {
					for j := 0; j < len(td.Data.Schema.TaskSchema); j++ {
						if ed.Data.Content.TrickConfig.CustomType == td.Data.Schema.TaskSchema[j].CustomTask {
							totalLine++
							te := map[string]any{
								"id":              d.Data[i].ID,
								"display_name":    d.Data[i].DisplayName,
								"custom_task":     td.Data.Schema.TaskSchema[j].CustomTask,
								"custom_taskName": td.Data.Schema.TaskSchema[j].CustomTaskName,
							}
							t := ct.transField(te, fieldMap)
							ret = append(ret, t)
							break
						}
					}
				} else {
					return nil, nil, errors.New("not found")
				}
			}
		} else {
			return nil, nil, errors.New("not found")
		}
	} else {
		return nil, nil, errors.New("not found")
	}
	summary := map[string]any{
		"totalLine": totalLine,
	}

	return ret, summary, nil
}

// getData 获取数据，参数为URL，返回值为字节切片和错误信息
func (ct *OperationAdaptor) getData(url string) ([]byte, error) {
	req, err := http.NewRequest("GET", url, nil)
	if err != nil {
		return []byte{}, fmt.Errorf("failed to create request: %w", err)
	}

	res, err := http.DefaultClient.Do(req)
	if err != nil {
		return []byte{}, fmt.Errorf("failed to create request: %w", err)
	}
	defer res.Body.Close()

	body, err := io.ReadAll(res.Body)
	if err != nil {
		return []byte{}, fmt.Errorf("failed to create request: %w", err)
	}

	return body, nil
}

// transField 功能：将传入的字段映射转换为新的字段映射，并返回结果。
// 参数：
//   - data map[string]any：需要转换的字段映射，键为原始字段名，值为对应的值。
//   - fieldMap map[string]string：原始字段映射与目标字段映射之间的关系，键为原始字段名，值为目标字段名。如果原始字段名在fieldMap中不存在，则会保留原样。
//
// 返回值：
//   - map[string]string：转换后的字段映射，键为目标字段名，值为对应的值。
func (ct *OperationAdaptor) transField(data map[string]any, fieldMap map[string]string) map[string]string {
	ret := make(map[string]string)
	for k, v := range data {
		var transValue string
		switch v := v.(type) {
		case string:
			transValue = v
		case int:
			transValue = strconv.Itoa(v)
		default:
			bs, _ := json.Marshal(v)
			transValue = string(bs)
		}
		if val, ok := fieldMap[k]; ok {
			ret[val] = transValue
		} else {
			ret[k] = transValue
		}
	}
	return ret
}
