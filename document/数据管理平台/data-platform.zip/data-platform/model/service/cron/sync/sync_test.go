/*
 * @Author: yandong03 yandong03@baidu.com
 * @Date: 2024-08-20 15:47:13
 * @LastEditors: yandong03 yandong03@baidu.com
 * @LastEditTime: 2024-09-03 12:38:45
 * @FilePath: /data-platform/model/service/cron/sync/sync_test.go
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
package sync

import (
	"context"
	"testing"

	"icode.baidu.com/baidu/gdp/logit"
)

func TestSyncKu(t *testing.T) {

	schema := map[string]any{
		"order": []string{
			"time",
			"query",
			"remark",
			"main_Q",
			"supplier",
			"resource_type",
			"url",
		},
		"properties": map[string]any{
			"main_Q": map[string]any{
				"title": "主Q",
				"type":  "string",
			},
			"query": map[string]any{
				"title": "query",
				"type":  "string",
			},
			"remark": map[string]any{
				"title": "备注",
				"type":  "string",
			},
			"resource_type": map[string]any{
				"title": "资源类型",
				"type":  "string",
			},
			"supplier": map[string]any{
				"title": "供应商",
				"type":  "string",
			},
			"time": map[string]any{
				"title": "时间",
				"type":  "string",
			},
			"url": map[string]any{
				"title": "链接",
				"type":  "string",
			},
		},
	}
	ctx := context.Background()
	logger, _ := logit.NewLogger(ctx)
	sync := SyncCron{ctx: ctx, logger: logger}
	_ = sync.doSync(ctx, 15, "ku", map[string]any{
		"url":   "https://ku.baidu-int.com/knowledge/HFVrC7hq1Q/uXaL-WkWdt/6uhtfeuSi1/UOCtmdbN87F_5R?tb=dstYbnNxwpdaxmS8hh_viw9VSckrmNWr&type=dst",
		"token": "uskj82XDb99RbEPrMaQS3nf",
	}, schema, nil)
}
