/*
 * @Author: yandong03 yandong03@baidu.com
 * @Date: 2024-07-31 16:12:21
 * @LastEditors: yandong03 yandong03@baidu.com
 * @LastEditTime: 2024-09-03 12:27:44
 * @FilePath: /data-platform/cmd/data-sync/ku.go
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
package sync

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strconv"
	"strings"

	"icode.baidu.com/baidu/search/data-platform/library/util"
)

type KuAdaptor struct{}

type kuConfig struct {
	kuURL string
	token string
}

func (kc *kuConfig) String() string {
	return fmt.Sprintf("kuURL:%s, token:%s", kc.kuURL, kc.token)
}

type kuResponse struct {
	Success bool   `json:"success"`
	Code    int    `json:"code"`
	Message string `json:"message"`
	Data    struct {
		Total    int `json:"total"`
		PageNum  int `json:"pageNum"`
		PageSize int `json:"pageSize"`
		Records  []struct {
			RecordID string         `json:"recordId"`
			Fields   map[string]any `json:"fields"`
		} `json:"records"`
	} `json:"data"`
}

func (ka *KuAdaptor) Sync(ctx context.Context, config map[string]any, schema map[string]any) ([]map[string]string, map[string]any, error) {

	kuConfig, err := ka.getURL(config)
	if err != nil {
		return nil, nil, fmt.Errorf("failed to parse url:(%w)", err)
	}
	content, summary, err := ka.getData(ctx, kuConfig, schema)
	if err != nil {
		return nil, nil, fmt.Errorf("failed to get data:(%w)", err)
	}

	return content, summary, nil
}

func (ka *KuAdaptor) getData(ctx context.Context, config *kuConfig, schema map[string]any) ([]map[string]string, map[string]any, error) {
	url := config.kuURL
	token := config.token
	fieldMap := util.SchemaToFieldMap(schema)

	ret := make([]map[string]string, 0)
	totalLine := 0

	for pagenum := 1; pagenum <= 200; pagenum++ {
		uri := fmt.Sprintf("%s%d", url, pagenum)
		headers := map[string][]string{
			"Authorization": {"Bearer " + token},
			"Content-Type":  {"application/json"},
		}

		req, err := http.NewRequest("GET", uri, nil)
		if err != nil {
			return nil, nil, fmt.Errorf("failed to create request: %w", err)
		}
		req.Header = headers

		client := &http.Client{}
		resp, err := client.Do(req)
		if err != nil {
			return nil, nil, fmt.Errorf("failed to send request: %w", err)
		}
		defer resp.Body.Close()

		body, err := io.ReadAll(resp.Body)
		if err != nil {
			return nil, nil, fmt.Errorf("failed to read response body: %w", err)
		}

		var data kuResponse
		err = json.Unmarshal(body, &data)
		if err != nil {
			return nil, nil, fmt.Errorf("failed to unmarshal JSON: %w", err)
		}
		if !data.Success {
			return nil, nil, fmt.Errorf("error: code=%w", err)
		}

		for _, record := range data.Data.Records {
			totalLine += 1
			transRecord := ka.transField(record.Fields, fieldMap)
			ret = append(ret, transRecord)
		}
		if pagenum*100 >= data.Data.Total {
			break
		}
	}
	summary := map[string]any{
		"totalLine": totalLine,
	}
	return ret, summary, nil
}

func (ka *KuAdaptor) transField(data map[string]any, fieldMap map[string]string) map[string]string {
	ret := make(map[string]string)
	for k, v := range data {
		var transValue string
		switch v := v.(type) {
		case string:
			transValue = v
		case int:
			transValue = strconv.Itoa(v)
		default:
			bs, _ := json.Marshal(v)
			transValue = string(bs)
		}
		if val, ok := fieldMap[k]; ok {
			ret[val] = transValue
		} else {
			ret[k] = transValue
		}
	}
	return ret
}

func (ka *KuAdaptor) getURL(config map[string]interface{}) (*kuConfig, error) {
	if _, ok := config["url"]; !ok {
		return nil, fmt.Errorf("missing url parameter")
	}
	urlStr := config["url"].(string)

	if _, ok := config["token"]; !ok {
		return nil, fmt.Errorf("missing token parameter")
	}
	token := config["token"].(string)

	// 解析URL
	parsedURL, err := url.Parse(urlStr)
	if err != nil {
		return nil, err
	}
	// 解析查询字符串
	query := parsedURL.Query()
	// 获取tb参数的值
	tb := query.Get("tb")
	if tb == "" {
		return nil, fmt.Errorf("tb parameter not found")
	}

	// 使用下划线分割tb参数的值
	parts := strings.Split(tb, "_")
	if len(parts) < 2 {
		return nil, fmt.Errorf("invalid tb value")
	}
	datasheetID := parts[0]
	viewID := parts[1]

	url := fmt.Sprintf("http://ku.baidu-int.com/fusion/v1/datasheets/%s/records?viewId=%s&fieldKey=name&pageNum=", datasheetID, viewID)

	return &kuConfig{
		kuURL: url,
		token: token,
	}, nil
}
