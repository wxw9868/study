package dataset

import (
	"context"
	"encoding/json"
	"fmt"
	"strings"
	"time"

	"icode.baidu.com/baidu/gdp/logit"
	"icode.baidu.com/baidu/search/data-platform/library/afs"
	"icode.baidu.com/baidu/search/data-platform/model/dao/mdb"
)

type DatasetUpdateCron struct {
	logger logit.Logger
	ctx    context.Context
}

func NewDatasetUpdateCron(ctx context.Context, logger logit.Logger) *DatasetUpdateCron {
	return &DatasetUpdateCron{
		logger: logger,
		ctx:    ctx,
	}
}

func (duc *DatasetUpdateCron) Run() error {
	ctx := context.Background()
	return duc.doTask(ctx)
}

func (duc *DatasetUpdateCron) Logger() logit.Logger {
	return duc.logger
}
func (duc *DatasetUpdateCron) ExecuteDuration() time.Duration {
	return 5 * time.Minute
}

func (duc *DatasetUpdateCron) doTask(ctx context.Context) error {
	var datasets *[]mdb.DatasetMeta
	datasetIns := mdb.DatasetMeta{}
	datasets, err := datasetIns.GetAllData(ctx)
	if err != nil {
		return fmt.Errorf("failed to query datasets: %w", err)
	}

	for _, dataset := range *datasets {
		if dataset.TargetType != "afs" {
			continue
		}

		ugi, ugiOk := dataset.TargetParams["ugi"].(string)
		path, pathOk := dataset.TargetParams["path"].(string)
		cluster, clusterOk := dataset.TargetParams["cluster"].(string)
		if !ugiOk || !pathOk || ugi == "" || path == "" || !clusterOk || cluster == "" {
			duc.logger.Trace(ctx, "Invalid target params for dataset:", logit.String("name", dataset.Name))
			continue
		}
		if !strings.HasPrefix(path, "/") {
			path = "/" + path
		}
		remotePath := cluster + path
		rawData, err := afs.ReadFile(ugi, remotePath)
		if err != nil {
			continue
		}

		// 转换文件内容为 PreviewData 所需的格式
		previewData, err := duc.generatePreviewData(rawData)
		if err != nil {
			continue
		}

		// 更新 PreviewData 字段
		dataset.PreviewData = previewData
		_, err = datasetIns.UpdateData(ctx, dataset)
		if err != nil {
			duc.logger.Error(ctx, "update preview data failed", logit.Error("error", err))
		}
	}

	return nil
}

// generatePreviewData 解析原始数据并生成 JSON 格式的 PreviewData
func (duc *DatasetUpdateCron) generatePreviewData(rawData []byte) (string, error) {
	var records [][]string

	lines := string(rawData)
	for _, line := range strings.Split(lines, "\n") {
		if line == "" {
			continue
		}
		fields := strings.Split(line, "\t")
		records = append(records, fields)
	}

	previewJSON, err := json.Marshal(records)
	if err != nil {
		return "", fmt.Errorf("failed to marshal preview data: %w", err)
	}

	return string(previewJSON), nil
}
