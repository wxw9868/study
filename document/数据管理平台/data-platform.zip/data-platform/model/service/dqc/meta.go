/*
 * @Author: yandong03 yandong03@baidu.com
 * @Date: 2024-08-19 17:48:52
 * @LastEditors: yandong03 yandong03@baidu.com
 * @LastEditTime: 2024-08-21 15:47:25
 * @FilePath: /data-platform/model/service/dqc/meta.go
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
package dqc

import (
	"encoding/json"
	"fmt"
	"strings"

	"github.com/expr-lang/expr"
)

type RuleValue struct {
	Checked       bool  `json:"checked"`
	NeedBlock     bool  `json:"needBlock"`
	Value         int   `json:"value"`
	IntervalValue []any `json:"intervalValue"`
}

type Rule struct {
	NullCheck RuleValue `json:"nullcheck"`
	Range     RuleValue `json:"range"`
	Unique    RuleValue `json:"unique"`
	Distinct  RuleValue `json:"distinct"`
}
type Column struct {
	Name      string `json:"name"`
	Type      string `json:"type"`
	Column    string `json:"column"`
	Required  bool   `json:"required"`
	Rules     Rule   `json:"rules"`
	Composite bool   `json:"composite"`
	Formula   string `json:"formula"`
}

var needValueRule = map[string]bool{}

var needIntervalRule = map[string]bool{
	"range": true,
}

func toString(v any) string {
	if vv, ok := v.(string); ok {
		return vv
	}
	data, _ := json.Marshal(v)
	return string(data)
}

func SchemaStandard(schema any) (map[string]any, error) {
	data, _ := json.Marshal(schema)
	columnList := make([]Column, 0)
	err := json.Unmarshal(data, &columnList)
	if err != nil {
		return nil, err
	}
	columns := make([]map[string]any, 0)
	required := make([]string, 0)
	for _, v := range columnList {
		rule := seriliazeRule(&v.Rules)
		if v.Required {
			required = append(required, v.Name)
		}
		columnValue := map[string]any{
			"name":   v.Name,
			"column": v.Column,
			"type":   v.Type,
			"rule":   rule,
		}
		if v.Composite {
			columnValue["formula"] = v.Formula
			columnValue["composite"] = true
		}
		columns = append(columns, columnValue)
	}

	return map[string]any{
		"columns":  columns,
		"distinct": required,
	}, nil
}

func serializeOne(name string, rule *RuleValue) string {
	if !rule.Checked {
		return ""
	}
	var ret []string
	if _, ok := needValueRule[name]; ok {
		ret = append(ret, fmt.Sprintf("%d", rule.Value))
	}
	if _, ok := needIntervalRule[name]; ok && len(rule.IntervalValue) == 2 {
		ret = append(ret, fmt.Sprintf("%s,%s", toString(rule.IntervalValue[0]), toString(rule.IntervalValue[1])))
	}
	if rule.NeedBlock {
		ret = append(ret, "1")
	} else {
		ret = append(ret, "0")
	}
	return strings.Join(ret, ":")
}

func appendValue(ret *[]string, name string, value string) {
	if len(value) <= 0 {
		return
	}
	*ret = append(*ret, fmt.Sprintf("%s:%s", name, value))
}

func seriliazeRule(rules *Rule) string {
	ret := make([]string, 0)
	appendValue(&ret, "nullcheck", serializeOne("nullcheck", &rules.NullCheck))
	appendValue(&ret, "range", serializeOne("range", &rules.Range))
	appendValue(&ret, "distinct", serializeOne("distinct", &rules.Distinct))
	appendValue(&ret, "unique", serializeOne("unique", &rules.Unique))

	return strings.Join(ret, ";")
}

func getDefaultValue(dataType string) any {
	dataType = strings.ToLower(dataType)
	switch dataType {
	case "int", "bigint":
		return 1
	case "decimal", "float":
		return 1.0
	default:
		return ""
	}
}

func CheckFormula(formula string, vals map[string]string) error {
	env := make(map[string]any)
	for k, v := range vals {
		env[k] = getDefaultValue(v)
	}
	_, err := expr.Compile(formula, expr.Env(env))

	return err
}
