package dimension

import (
	"context"

	"icode.baidu.com/baidu/search/data-platform/library/resource"
	"icode.baidu.com/baidu/search/data-platform/model/dao/mdb"
)

func GetAlarmMeta(ctx context.Context) ([]mdb.DataMeta, error) {
	var list []mdb.DataMeta
	db := mdb.WithContext(ctx, resource.GormClientDataPlat)
	res := db.Where("status = 0").Find(&list)
	if res.Error != nil {
		return list, res.Error
	}
	var ret []mdb.DataMeta
	for _, meta := range list {
		alarmConfig := meta.AlarmConfig
		if _, ok := alarmConfig["enabled"]; ok {
			if val, ok := alarmConfig["enabled"].(bool); ok && val {
				ret = append(ret, meta)
			}
		}
	}
	return ret, nil
}
