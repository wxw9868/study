/*
 * @Author: yandong03 yandong03@baidu.com
 * @Date: 2024-08-01 14:49:40
 * @LastEditors: yandong03 yandong03@baidu.com
 * @LastEditTime: 2024-08-09 18:16:29
 * @FilePath: /data-platform/model/service/dimension/data.go
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
package dimension

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"time"

	"icode.baidu.com/baidu/ps-se-go/restful/field"
	custom_field "icode.baidu.com/baidu/search/data-platform/library/field"
	"icode.baidu.com/baidu/search/data-platform/library/resource"
	"icode.baidu.com/baidu/search/data-platform/library/util"
	"icode.baidu.com/baidu/search/data-platform/model/dao/mdb"
)

func UpdateOnlineVersion(ctx context.Context, id int64, preOnlineVersion int, onlineVersion int) error {
	newHistory := mdb.DataHistory{}
	err := mdb.GetTransaction().Execute(ctx, newHistory.Database(), func(txCtx context.Context) error {
		res := newHistory.Database().Model(&mdb.DataMeta{}).Where("id = ? and online_version = ?", id, preOnlineVersion).Update("online_version", onlineVersion)
		if res.RowsAffected == 0 {
			return errors.New("no row updated")
		}
		if res.Error != nil {
			return res.Error
		}
		summaryMap := map[string]any{
			"id":            id,
			"preVersion":    preOnlineVersion,
			"targetVersion": onlineVersion,
		}
		summary, _ := json.Marshal(summaryMap)
		ins := mdb.EventLog{
			EventType:  resource.UpdateOnlineVersion,
			Content:    string(summary),
			DID:        id,
			Creator:    custom_field.UserType("ejob"),
			DebugLevel: resource.LevelNotice,
			CreateTime: field.Timestamp(time.Now()),
			UpdateTime: field.Timestamp(time.Now()),
		}
		if err := mdb.WithContext(txCtx, ins.Database()).Create(&ins).Error; err != nil {
			return err
		}
		return nil
	})
	return err
}

func UpdateData(ctx context.Context, did int64, content any, summary map[string]any, source string, commentInfo string, creator string) (int, error) {
	newHistory := &mdb.DataHistory{}
	maxVersion, err := newHistory.MaxVersion(ctx, did)
	if err != nil {
		return 0, fmt.Errorf("get max version failed: %w", err)
	}

	preSign := ""
	if maxVersion > 0 {
		ins, err := newHistory.GetTargetVersionData(ctx, did, maxVersion)
		if err != nil {
			return 0, fmt.Errorf("get data history failed: %w", err)
		}
		preSign = ins.DataSign
	}
	newSign := util.SignData(content)
	if preSign == newSign {
		return 0, errors.New("data not changed")
	}
	targetVersion := maxVersion + 1

	err = mdb.GetTransaction().Execute(ctx, newHistory.Database(), func(txCtx context.Context) error {
		content, _ := json.Marshal(content)
		summary["source"] = source
		summary["did"] = did
		summary["targetVersion"] = targetVersion
		summary["preVersion"] = maxVersion
		summary["preSign"] = preSign
		summary["newSign"] = newSign
		summary, _ := json.Marshal(summary)
		history := mdb.DataHistory{
			DID:         int64(did),
			Version:     targetVersion,
			DataSign:    newSign,
			Content:     field.JSON(content),
			Creator:     custom_field.UserType(creator),
			CommentInfo: commentInfo,
		}

		result := mdb.WithContext(txCtx, newHistory.Database()).Create(&history)
		if result.Error != nil {
			return result.Error
		}
		result = mdb.WithContext(txCtx, newHistory.Database()).Model(&mdb.DataMeta{}).Where("id = ?", did).Updates(
			map[string]any{
				"version": targetVersion,
			})

		if result.Error != nil {
			return result.Error
		}
		eventType := resource.EditContentData
		if creator == "system" {
			eventType = resource.SyncData
		}
		ins := mdb.EventLog{
			EventType:  eventType,
			Content:    string(summary),
			DID:        did,
			Creator:    custom_field.UserType(creator),
			DebugLevel: resource.LevelNotice,
			CreateTime: field.Timestamp(time.Now()),
			UpdateTime: field.Timestamp(time.Now()),
		}

		if err := mdb.WithContext(txCtx, ins.Database()).Create(&ins).Error; err != nil {
			return err
		}
		return nil
	})
	return targetVersion, err
}
