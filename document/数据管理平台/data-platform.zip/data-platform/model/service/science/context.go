/*
 * @Author: yandong03 yandong03@baidu.com
 * @Date: 2024-08-28 17:27:08
 * @LastEditors: yandong03 yandong03@baidu.com
 * @LastEditTime: 2024-09-03 12:39:20
 * @FilePath: /data-platform/model/service/science/context.go
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
package science

import (
	"context"
	"encoding/json"
	"time"

	"icode.baidu.com/baidu/search/data-platform/library/resource"
)

type TaskContext struct {
	tid string
}

func NewTaskContext(tid string) *TaskContext {
	return &TaskContext{
		tid: tid,
	}
}

func (c *TaskContext) SetContext(ctx context.Context, scope string, key string, value any) error {
	var stringifyValue string
	switch value := value.(type) {
	case string:
		stringifyValue = value
	default:
		bs, _ := json.Marshal(value)
		stringifyValue = string(bs)
	}
	redisKey := c.tid + "_" + scope
	ret := resource.RedisClient.HSet(ctx, redisKey, key, stringifyValue)
	resource.RedisClient.Expire(ctx, redisKey, 86400*time.Second)
	return ret.Err()
}

func (c *TaskContext) GetContext(ctx context.Context, scope string) (map[string]string, error) {
	redisKey := c.tid + "_" + scope
	return resource.RedisClient.HGetAll(ctx, redisKey).Result()
}

func (c *TaskContext) GetTid() string {
	return c.tid
}
