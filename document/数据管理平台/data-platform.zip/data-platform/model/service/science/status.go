/*
 * @Author: yandong03 yandong03@baidu.com
 * @Date: 2024-09-12 20:47:21
 * @LastEditors: yandong03 yandong03@baidu.com
 * @LastEditTime: 2024-09-14 10:02:50
 * @FilePath: /data-platform/model/service/science/status.go
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
package science

import (
	"errors"

	"icode.baidu.com/baidu/search/data-platform/library/afs"
)

func SetSuccess(taskType string, params map[string]any, jobID string) (string, error) {
	switch taskType {
	case "abtest":
		return abtestSetSuccess(params, jobID)
	}
	return "", errors.New("no such task type")
}

func abtestSetSuccess(params map[string]any, jobID string) (string, error) {
	if len(jobID) <= 0 {
		return "", errors.New("no job id found")
	}
	baseAfsPath, ok := params["expUserPath"].(string)
	if !ok {
		return "", errors.New("no base path found")
	}
	ugi, ok := params["ugi"].(string)
	if !ok {
		return "", errors.New("no ugi found")
	}
	doneFilePath := baseAfsPath + "/" + jobID + "/.done"

	return doneFilePath, afs.Touchz(ugi, doneFilePath)
}
