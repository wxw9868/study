/*
 * @Author: yandong03 yandong03@baidu.com
 * @Date: 2024-08-29 10:04:17
 * @LastEditors: yandong03 yandong03@baidu.com
 * @LastEditTime: 2024-09-27 11:39:29
 * @FilePath: /data-platform/model/service/science/task.go
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
package science

import (
	"context"
	"errors"
	"fmt"

	"gorm.io/gorm"
	"gorm.io/gorm/clause"
	"icode.baidu.com/baidu/search/data-platform/model/dao/mdb"
)

func GetTask(ctx context.Context, taskType string, tid string, isBacktrace bool, taskID int64, jobID string) (*mdb.ScienceTask, error) {
	assignedTask := mdb.ScienceTask{}
	assignedRet := assignedTask.Database().Model(&mdb.ScienceTask{}).Where("task_type = ? and tid = ? and schedule_type= 0", taskType, tid).First(&assignedTask)
	if assignedRet.Error == nil {
		return &assignedTask, nil
	}
	assignHistory := mdb.TaskRunHistory{}
	ret := assignedTask.Database().Model(&mdb.TaskRunHistory{}).Where("tid = ?", tid).First(&assignHistory)
	if ret.Error == nil {
		assignedTask.Database().Model(&mdb.ScienceTask{}).Find(&assignedTask, assignHistory.TaskID)
		return &assignedTask, nil
	}

	if !isBacktrace {
		return getTask(ctx, taskType, tid, jobID)
	}
	return getBacktraceTask(ctx, taskType, tid, taskID, jobID)
}

type TaskContent struct {
	TaskID     int64 `json:"taskId"`
	InstanceID any   `json:"instanceId"`
	TaskParams any   `json:"taskParams"`
}

func GetTaskContent(ctx context.Context, tid string) (any, error) {
	assignedTask := mdb.ScienceTask{}
	assignedRet := assignedTask.Database().Model(&mdb.ScienceTask{}).Where("tid = ? and schedule_type= 0", tid).First(&assignedTask)
	if assignedRet.Error == nil {
		return &TaskContent{
			TaskID:     assignedTask.ID,
			TaskParams: assignedTask.TaskParams,
		}, nil
	}
	assignHistory := mdb.TaskRunHistory{}
	ret := assignedTask.Database().Model(&mdb.TaskRunHistory{}).Where("tid = ?", tid).First(&assignHistory)
	if ret.Error == nil {
		return &TaskContent{
			TaskID:     assignHistory.TaskID,
			InstanceID: fmt.Sprintf("r%d", assignHistory.ID),
			TaskParams: assignHistory.TaskParams,
		}, nil
	}
	return nil, errors.New("tid not found")
}

func getTask(ctx context.Context, taskType string, tid string, jobID string) (*mdb.ScienceTask, error) {
	// 首先获取单次任务
	dao := mdb.ScienceTask{}
	err := mdb.GetTransaction().Execute(ctx, dao.Database(), func(txCtx context.Context) error {
		res := dao.Database().Clauses(clause.Locking{Strength: "UPDATE"}).Model(&mdb.ScienceTask{})
		res = res.Where("task_type = ? and schedule_type = 0 and status = 0", taskType).First(&dao)
		if res.Error != nil {
			return res.Error
		}
		resSet := dao.Database().Model(&mdb.ScienceTask{}).Where("id = ?", dao.ID).Updates(map[string]any{
			"status": 1,
			"tid":    tid,
		})
		if resSet.Error != nil {
			return resSet.Error
		}
		return nil
	})
	if err == nil {
		return &dao, err
	}
	if err != gorm.ErrRecordNotFound {
		return &dao, err
	}

	// 获取例行任务 OR 回溯任务
	var validTask *mdb.ScienceTask
	err = mdb.GetTransaction().Execute(ctx, dao.Database(), func(txCtx context.Context) error {
		res := dao.Database().Model(&mdb.ScienceTask{})
		scheduleTaskList := []mdb.ScienceTask{}
		res = res.Where("task_type = ? and schedule_type = 1 and status = 0", taskType).Find(&scheduleTaskList)
		if res.Error != nil {
			return res.Error
		}
		findValid := false
		var runTaskId int64 = 0

		for _, task := range scheduleTaskList {
			historyIns := mdb.TaskRunHistory{}
			resSet := dao.Database().Clauses(clause.Locking{Strength: "UPDATE"}).Model(&mdb.TaskRunHistory{})
			resSet = resSet.Where("task_id = ? and job_id = ?", task.ID, jobID).First(&historyIns)
			if resSet.Error != nil {
				if resSet.Error == gorm.ErrRecordNotFound {
					findValid = true
					runTaskId = task.ID
					validTask = &task
					break
				} else {
					return resSet.Error
				}
			}
		}
		if findValid {
			history := mdb.TaskRunHistory{
				TaskID:     runTaskId,
				JobID:      jobID,
				TID:        tid,
				TaskType:   validTask.TaskType,
				TaskParams: validTask.TaskParams,
				RunType:    "例行",
				Status:     1,
				Result:     nil,
			}
			createRet := dao.Database().Create(&history)
			if createRet.Error != nil {
				return createRet.Error
			}
			return nil
		}
		return errors.New("no task found")
	})
	if err == nil {
		return validTask, err
	}
	return &dao, err
}

func getBacktraceTask(ctx context.Context, taskType string, tid string, taskID int64, jobID string) (*mdb.ScienceTask, error) {
	var assignedRet mdb.ScienceTask
	dao := mdb.ScienceTask{}
	err := mdb.GetTransaction().Execute(ctx, dao.Database(), func(txCtx context.Context) error {
		res := dao.Database().Clauses(clause.Locking{Strength: "UPDATE"}).Model(&mdb.ScienceTask{})
		res = res.Where("task_type = ? and schedule_type = 1 and id = ?", taskType, taskID).First(&assignedRet)
		if res.Error != nil {
			return res.Error
		}
		history := mdb.TaskRunHistory{
			TaskID:     taskID,
			JobID:      jobID,
			TID:        tid,
			RunType:    "回溯",
			TaskType:   assignedRet.TaskType,
			TaskParams: assignedRet.TaskParams,
			Status:     1,
		}

		resSet := dao.Database().Model(&mdb.TaskRunHistory{}).Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "task_id"}, {Name: "job_id"}},
			DoUpdates: clause.AssignmentColumns([]string{"status", "tid", "run_type", "task_params", "task_type"}),
		}).Create(&history)
		if resSet.Error != nil {
			return resSet.Error
		}
		return nil
	})
	if err == nil {
		return &assignedRet, nil
	}
	return nil, err
}
