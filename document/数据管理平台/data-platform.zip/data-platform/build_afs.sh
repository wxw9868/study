#! /bin/sh
###
 # @Author: yandong03 yandong03@baidu.com
 # @Date: 2024-09-12 20:04:33
 # @LastEditors: yandong03 yandong03@baidu.com
 # @LastEditTime: 2024-09-12 20:07:40
 # @FilePath: /data-platform/build_afs.sh
 # @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
### 
#
# build_afs.sh
# Copyright (C) 2024 yandong <yandong03@baidu.com>
#
# Distributed under terms of the MIT license.
#
export APP_BASE_PATH=$(cd `dirname $0`; pwd)

export APP_TMP_PATH=${APP_BASE_PATH}/tmp_afs

mkdir -p ${APP_TMP_PATH}

cd ${APP_TMP_PATH}

wget -O output.tar.gz --no-check-certificate --header "IREPO-TOKEN:37162e9e-f01d-417b-9dbd-6aa1b032d7bd" "https://irepo.baidu-int.com/rest/prod/v3/baidu/inf/afs-api/releases/1.10.2.1/files"
tar -zxf output.tar.gz

cp -r ${APP_TMP_PATH}/output/bin/afsshell ${APP_BASE_PATH}/bin/

cd -
rm -rf ${APP_TMP_PATH}
