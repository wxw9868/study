package function

import (
	"context"
	"errors"

	"gorm.io/gorm"
	"icode.baidu.com/baidu/gdp/ghttp"
	"icode.baidu.com/baidu/ps-se-go/restful"
	"icode.baidu.com/baidu/ps-se-go/restful/field"
	"icode.baidu.com/baidu/ps-se-go/restful/mixins"
	"icode.baidu.com/baidu/ps-se-go/restful/model"
	"icode.baidu.com/baidu/ps-se-go/restful/response"
	"icode.baidu.com/baidu/search/data-platform/library/util"
	"icode.baidu.com/baidu/search/data-platform/model/dao/mdb"
)

type Meta struct {
	*restful.Resource
	*mixins.GetMethod
	*mixins.ListMethod
	*mixins.PostMethod
	*mixins.PatchMethod
	*mixins.PutMethod
	*mixins.DeleteMethod
}

type functionMetaSearchParams struct {
	ID          int64           `gorm:"column:id;primaryKey;autoIncrement" json:"id"`
	FuncSetName string          `gorm:"column:func_set_name" json:"funcSetName"`
	Start       field.Timestamp `gorm:"column:create_time;" json:"start" operate:">="`
	End         field.Timestamp `gorm:"column:create_time;" json:"end" operate:"<"`
}

type functionDataParams struct {
	ID          int64  `json:"id"`
	FuncSetName string `json:"funcSetName"`
	FuncName    string `json:"funcName"`
}

func NewFunctionMeta() *Meta {
	ins := &Meta{
		Resource:  restful.NewResource(&mdb.FunctionMeta{}),
		GetMethod: &mixins.GetMethod{},
		ListMethod: &mixins.ListMethod{
			Offset:       0,
			Limit:        10,
			OrderBy:      []string{"id desc"},
			SearchParams: &functionMetaSearchParams{},
			SearchFields: []string{"func_set_name"},
		},
		PostMethod:   &mixins.PostMethod{},
		PatchMethod:  &mixins.PatchMethod{},
		PutMethod:    &mixins.PutMethod{},
		DeleteMethod: &mixins.DeleteMethod{},
	}
	ins.RegisterMethod(restful.ListMethod, restful.HTTPMethodGet, "function_set_data", util.WithCloselyLogger(ins.GetFunctionSetData))
	ins.RegisterMethod(restful.ListMethod, restful.HTTPMethodGet, "function_data", util.WithCloselyLogger(ins.GetFunctionData))

	return ins
}

func (d *Meta) GetFunctionSetData(ctx context.Context, req ghttp.Request) ghttp.Response {
	resource := restful.ResourceFromContext(ctx)
	params := restful.GetQuery(req)
	latestParams := model.NewModel(&functionDataParams{})
	serializer := resource.GetSerializer(latestParams)

	if err := serializer.ParseFromQuery(ctx, params); err != nil {
		return response.NewError(400, err)
	}
	if err := serializer.Validate(ctx); err != nil {
		return err
	}
	jsonData := serializer.JsonData()

	dao := mdb.FunctionMeta{}
	data, err := dao.GetFunctionSetData(ctx, jsonData["funcSetName"].(string))

	if err != nil && errors.Is(err, gorm.ErrRecordNotFound) {
		return &response.Response{
			Status: 0,
			Data:   data,
			Msg:    "ok",
		}
	}
	if err != nil {
		return response.NewError(500, err)
	}
	return &response.Response{
		Status: 0,
		Data:   data,
		Msg:    "ok",
	}
}

func (d *Meta) GetFunctionData(ctx context.Context, req ghttp.Request) ghttp.Response {
	resource := restful.ResourceFromContext(ctx)
	params := restful.GetQuery(req)
	latestParams := model.NewModel(&functionDataParams{})
	serializer := resource.GetSerializer(latestParams)
	if err := serializer.ParseFromQuery(ctx, params); err != nil {
		return response.NewError(400, err)
	}
	if err := serializer.Validate(ctx); err != nil {
		return err
	}
	jsonData := serializer.JsonData()
	dao := mdb.FunctionMeta{}
	var data interface{}
	var err error
	if jsonData["id"] != nil {
		data, err = dao.GetFunctionDataByID(ctx, jsonData["id"].(int64))
	} else {
		data, err = dao.GetFunctionList(ctx, jsonData["funcSetName"].(string), jsonData["funcName"].(string))
	}

	if err != nil && errors.Is(err, gorm.ErrRecordNotFound) {
		return &response.Response{
			Status: 0,
			Data:   data,
			Msg:    "ok",
		}
	}
	if err != nil {
		return response.NewError(500, err)
	}
	return &response.Response{
		Status: 0,
		Data:   data,
		Msg:    "ok",
	}
}
