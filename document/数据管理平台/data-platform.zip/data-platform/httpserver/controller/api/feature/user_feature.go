/*
 * @Author: yandong03 yandong03@baidu.com
 * @Date: 2024-11-07 14:37:30
 * @LastEditors: yandong03 yandong03@baidu.com
 * @LastEditTime: 2024-11-07 14:51:37
 * @FilePath: /data-platform/httpserver/controller/api/feature/user_feature.go
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
package feature

import (
	"icode.baidu.com/baidu/ps-se-go/restful"
	"icode.baidu.com/baidu/ps-se-go/restful/field"
	"icode.baidu.com/baidu/ps-se-go/restful/mixins"

	"icode.baidu.com/baidu/search/data-platform/model/dao/mdb"
)

type UserFeature struct {
	*restful.Resource
	*mixins.GetMethod
	*mixins.ListMethod
	*mixins.PostMethod
	*mixins.PatchMethod
	*mixins.PutMethod
	*mixins.DeleteMethod
}

type featureSearchParams struct {
	Creator string          `gorm:"column:creator" json:"creator"`
	Name    string          `gorm:"column:table_name" json:"name"`
	ID      string          `gorm:"id" json:"id"`
	Start   field.Timestamp `gorm:"column:create_time;" json:"start" operate:">="`
	End     field.Timestamp `gorm:"column:create_time;" json:"end" operate:"<"`
}

func NewUserFeature() *UserFeature {
	ins := &UserFeature{
		Resource:  restful.NewResource(&mdb.UserFeature{}),
		GetMethod: &mixins.GetMethod{},
		ListMethod: &mixins.ListMethod{
			Offset:       0,
			Limit:        10,
			OrderBy:      []string{"id desc"},
			SearchParams: &featureSearchParams{},
			SearchFields: []string{"creator", "table_name"},
		},
		PostMethod:   &mixins.PostMethod{},
		PatchMethod:  &mixins.PatchMethod{},
		PutMethod:    &mixins.PutMethod{},
		DeleteMethod: &mixins.DeleteMethod{},
	}
	return ins
}
