package dqc

import (
	"icode.baidu.com/baidu/ps-se-go/restful"
	"icode.baidu.com/baidu/ps-se-go/restful/field"
	"icode.baidu.com/baidu/ps-se-go/restful/mixins"

	"icode.baidu.com/baidu/search/data-platform/model/dao/mdb"
)

type Connectors struct {
	*restful.Resource
	*mixins.GetMethod
	*mixins.ListMethod
	*mixins.PostMethod
	*mixins.PatchMethod
	*mixins.PutMethod
	*mixins.DeleteMethod
}

type connectorsSearchParams struct {
	ID      string          `gorm:"column:id" json:"id"`
	Name    string          `gorm:"column:name" json:"name"`
	Creator string          `gorm:"column:creator" json:"creator"`
	Start   field.Timestamp `gorm:"column:create_time;" json:"start" operate:">="`
	End     field.Timestamp `gorm:"column:create_time;" json:"end" operate:"<"`
}

func NewDqcConnectors() *Connectors {
	ins := &Connectors{
		Resource:  restful.NewResource(&mdb.DqcConnectors{}),
		GetMethod: &mixins.GetMethod{},
		ListMethod: &mixins.ListMethod{
			Offset:       0,
			Limit:        10,
			OrderBy:      []string{"id desc"},
			SearchParams: &connectorsSearchParams{},
			SearchFields: []string{"name", "description"},
		},
		PostMethod:   &mixins.PostMethod{},
		PatchMethod:  &mixins.PatchMethod{},
		PutMethod:    &mixins.PutMethod{},
		DeleteMethod: &mixins.DeleteMethod{},
	}
	return ins
}
