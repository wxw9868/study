package dqc

import (
	"context"
	"encoding/json"
	"errors"
	"strconv"
	"strings"

	"icode.baidu.com/baidu/gdp/ghttp"
	"icode.baidu.com/baidu/ps-se-go/restful"
	"icode.baidu.com/baidu/ps-se-go/restful/field"
	"icode.baidu.com/baidu/ps-se-go/restful/mixins"
	"icode.baidu.com/baidu/ps-se-go/restful/response"

	"icode.baidu.com/baidu/search/data-platform/library/delivery"
	"icode.baidu.com/baidu/search/data-platform/library/util"
	"icode.baidu.com/baidu/search/data-platform/model/dao/mdb"
)

type Task struct {
	*restful.Resource
	*mixins.GetMethod
	*mixins.ListMethod
	*mixins.PostMethod
	*mixins.PatchMethod
	*mixins.PutMethod
	*mixins.DeleteMethod
}

type taskSearchParams struct {
	ID        string          `gorm:"column:id" json:"id"`
	Title     string          `gorm:"column:title" json:"title"`
	JobID     string          `gorm:"column:job_id" json:"jobId"`
	FatherID  string          `gorm:"column:father_id" json:"fatherID"`
	Creator   string          `gorm:"column:creator" json:"creator"`
	Start     field.Timestamp `gorm:"column:create_time;" json:"start" operate:">="`
	End       field.Timestamp `gorm:"column:create_time;" json:"end" operate:"<"`
	Status    int             `gorm:"column:status;" json:"status"`
	DqcStatus int             `gorm:"column:dqc_status;" json:"dqcStatus"`
}

func NewDqcTask() *Task {
	ins := &Task{
		Resource:  restful.NewResource(&mdb.DqcTask{}),
		GetMethod: &mixins.GetMethod{},
		ListMethod: &mixins.ListMethod{
			Offset:       0,
			Limit:        10,
			OrderBy:      []string{"id desc"},
			SearchParams: &taskSearchParams{},
			SearchFields: []string{"title", "creator"},
		},
		PostMethod:   &mixins.PostMethod{},
		PatchMethod:  &mixins.PatchMethod{},
		PutMethod:    &mixins.PutMethod{},
		DeleteMethod: &mixins.DeleteMethod{},
	}
	ins.RegisterMethod(restful.ListMethod, restful.HTTPMethodPost, "submit/:id", util.WithCloselyLogger(ins.SubmitEjobTask))
	ins.RegisterMethod(restful.ListMethod, restful.HTTPMethodPost, "sync/progress/:id", util.WithCloselyLogger(ins.SyncTaskProgress))
	ins.RegisterMethod(restful.ListMethod, restful.HTTPMethodGet, "sync/status/:id", util.WithCloselyLogger(ins.SyncTaskStatus))
	ins.RegisterMethod(restful.ListMethod, restful.HTTPMethodPost, "sync/dqc_status/:id", util.WithCloselyLogger(ins.SyncDqcStatus))
	ins.RegisterMethod(restful.ListMethod, restful.HTTPMethodGet, "task_with_children", util.WithCloselyLogger(ins.GetTaskWithChildren))
	ins.RegisterMethod(restful.ListMethod, restful.HTTPMethodPost, "tds/submit/:id/:day", util.WithCloselyLogger(ins.TdsSubmitTask))
	ins.RegisterMethod(restful.ListMethod, restful.HTTPMethodGet, "tds/select/:id", util.WithCloselyLogger(ins.TdsSelectTask))
	ins.RegisterMethod(restful.ListMethod, restful.HTTPMethodGet, "tds/status/:id", util.WithCloselyLogger(ins.TdsStatusTask))
	return ins
}

func (t *Task) SyncDqcStatus(ctx context.Context, req ghttp.Request) ghttp.Response {
	id := req.Param(":id")
	dqcStatus := req.QueryDefault("dqc_status", "")
	resource := restful.ResourceFromContext(ctx)
	validStatus := map[string]bool{"0": true, "1": true, "2": true}
	if _, ok := validStatus[dqcStatus]; !ok {
		return response.NewError(400, errors.New("invalid dqc status"))
	}

	res := resource.GetDB().Model(&mdb.DqcTask{}).Where("id = ?", id).UpdateColumn("dqc_status", dqcStatus)
	if res.Error != nil {
		return response.NewError(500, res.Error)
	}
	return &response.Response{
		Status: 0,
		Msg:    "ok",
	}
}

func (t *Task) SubmitEjobTask(ctx context.Context, req ghttp.Request) ghttp.Response {
	id := req.Param(":id")

	resource := restful.ResourceFromContext(ctx)
	res := resource.GetDB().Model(&mdb.DqcTask{}).Where("id = ?", id).UpdateColumn("dqc_status", 0).UpdateColumn("status", 0)

	if res.Error != nil {
		return response.NewError(500, res.Error)
	}

	err := delivery.DeliverDqc(ctx, id)
	if err != nil {
		return response.NewError(500, err)
	}

	return &response.Response{
		Status: 0,
		Msg:    "ok",
	}
}

type SyncProgresParams struct {
	MdResult string `json:"mdResult"`
	Progress string `json:"progress"`
}

func (t *Task) SyncTaskProgress(ctx context.Context, req ghttp.Request) ghttp.Response {
	id := req.Param(":id")
	resource := restful.ResourceFromContext(ctx)
	progress := &SyncProgresParams{}

	err := json.NewDecoder(req.Body()).Decode(progress)
	if err != nil {
		return response.NewError(400, err)
	}
	res := resource.GetDB().Model(&mdb.DqcTask{}).Where("id = ?", id).Updates(progress)

	if res.Error != nil {
		return response.NewError(500, res.Error)
	}
	return &response.Response{
		Status: 0,
		Msg:    "ok",
	}
}

func (t *Task) SyncTaskStatus(ctx context.Context, req ghttp.Request) ghttp.Response {
	id := req.Param(":id")

	transitionMap := map[string]string{
		"run":     "1",
		"success": "2",
		"fail":    "3",
		"kill":    "3",
		"pending": "0",
	}

	status := transitionMap[req.QueryDefault("transition", "")]

	resource := restful.ResourceFromContext(ctx)
	jsonData := map[string]any{
		"status": status,
	}
	res := resource.GetDB().Model(&mdb.DqcTask{}).Where("id = ?", id).Updates(jsonData)

	if res.Error != nil {
		return response.NewError(500, res.Error)
	}
	return &response.Response{
		Status: 0,
		Msg:    "ok",
	}
}

func (t *Task) GetTaskWithChildren(ctx context.Context, req ghttp.Request) ghttp.Response {
	ids := req.QueryDefault("id", "0")
	var results []struct {
		FatherID string
		Count    int
	}
	targetIds := strings.Split(ids, ",")

	resource := restful.ResourceFromContext(ctx)
	resource.GetDB().Model(&mdb.DqcTask{}).Select("father_id, count(1) as count").Where("father_id in ?", targetIds).Group("father_id").Find(&results)

	return &response.Response{
		Status: 0,
		Msg:    "ok",
		Data:   results,
	}
}

// tds任务调用接口复制并执行指定任务
func (t *Task) TdsSubmitTask(ctx context.Context, req ghttp.Request) ghttp.Response {
	id := req.Param(":id")
	day := req.Param(":day")
	var data mdb.DqcTask

	resource := restful.ResourceFromContext(ctx)
	// 查询现有数据并复制
	res := resource.GetDB().Where("id = ?", id).Find(&data)
	if res.Error != nil {
		return response.NewError(500, res.Error)
	}
	// 数据不存在
	if data.ID == 0 {
		// 返回默认值
		return &response.Response{
			Status: 0,
			Data:   data.ID,
		}
	}
	data.Title = data.Title + "_" + day
	data.Params["${DATE}"] = day

	// 检查同天新数据是否已存在
	var newData mdb.DqcTask
	res = resource.GetDB().Where("title = ? and father_id = ?", data.Title, data.ID).Find(&newData)
	if res.Error != nil {
		return response.NewError(500, res.Error)
	}

	// 数据不存在
	if newData.ID == 0 {
		data.FatherID = data.ID
		// 写入新数据
		res = resource.GetDB().Omit("id").Create(&data)
		if res.Error != nil {
			return response.NewError(500, res.Error)
		}
		res = resource.GetDB().Where("title = ? and father_id = ?", data.Title, data.ID).Find(&newData)
		if res.Error != nil {
			return response.NewError(500, res.Error)
		}
	}

	// 执行新数据
	res = resource.GetDB().Model(&mdb.DqcTask{}).Where("id = ?", newData.ID).UpdateColumn("dqc_status", 0).UpdateColumn("status", 0)
	if res.Error != nil {
		return response.NewError(500, res.Error)
	}
	strNewID := strconv.Itoa(newData.ID)
	err := delivery.DeliverDqc(ctx, strNewID)
	if err != nil {
		return response.NewError(500, err)
	}
	return &response.Response{
		Status: 0,
		Data:   newData.ID,
	}
}

// tds任务调用接口查询指定id任务
func (t *Task) TdsSelectTask(ctx context.Context, req ghttp.Request) ghttp.Response {
	id := req.Param(":id")
	var data mdb.DqcTask

	resource := restful.ResourceFromContext(ctx)
	// 查询数据
	res := resource.GetDB().Where("id = ?", id).Find(&data)
	if res.Error != nil {
		return response.NewError(500, res.Error)
	}

	return &response.Response{
		Status: 0,
		Data:   data,
	}
}

// tds任务调用接口查询指定id任务的状态
func (t *Task) TdsStatusTask(ctx context.Context, req ghttp.Request) ghttp.Response {
	id := req.Param(":id")
	var data mdb.DqcTask

	resource := restful.ResourceFromContext(ctx)
	// 查询数据
	res := resource.GetDB().Where("id = ?", id).Find(&data)
	if res.Error != nil {
		return response.NewError(500, res.Error)
	}
	returnData := map[string]any{
		"status":     data.Status,
		"dqc_status": data.DqcStatus,
	}
	return &response.Response{
		Status: 0,
		Data:   returnData,
	}
}
