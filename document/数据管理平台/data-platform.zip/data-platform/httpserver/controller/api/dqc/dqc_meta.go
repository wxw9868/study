/*
 * @Author: yandong03 yandong03@baidu.com
 * @Date: 2024-08-14 19:54:46
 * @LastEditors: yandong03 yandong03@baidu.com
 * @LastEditTime: 2024-08-20 15:30:48
 * @FilePath: /data-platform/httpserver/controller/api/dqc/dqc_meta.go
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
package dqc

import (
	"context"
	"fmt"

	"icode.baidu.com/baidu/gdp/ghttp"
	"icode.baidu.com/baidu/ps-se-go/restful"
	"icode.baidu.com/baidu/ps-se-go/restful/field"
	"icode.baidu.com/baidu/ps-se-go/restful/mixins"
	"icode.baidu.com/baidu/ps-se-go/restful/model"
	"icode.baidu.com/baidu/ps-se-go/restful/response"

	"icode.baidu.com/baidu/search/data-platform/library/util"
	"icode.baidu.com/baidu/search/data-platform/model/dao/mdb"
	"icode.baidu.com/baidu/search/data-platform/model/service/dqc"
)

type Meta struct {
	*restful.Resource
	*mixins.GetMethod
	*mixins.ListMethod
	*mixins.PostMethod
	*mixins.PatchMethod
	*mixins.PutMethod
	*mixins.DeleteMethod
}

type metaSearchParams struct {
	ID      string          `gorm:"column:id" json:"id"`
	Name    string          `gorm:"column:name" json:"name"`
	Creator string          `gorm:"column:creator" json:"creator"`
	Start   field.Timestamp `gorm:"column:create_time;" json:"start" operate:">="`
	End     field.Timestamp `gorm:"column:create_time;" json:"end" operate:"<"`
}

func NewDqcMeta() *Meta {
	ins := &Meta{
		Resource:  restful.NewResource(&mdb.DqcMeta{}),
		GetMethod: &mixins.GetMethod{},
		ListMethod: &mixins.ListMethod{
			Offset:       0,
			Limit:        10,
			OrderBy:      []string{"id desc"},
			SearchParams: &metaSearchParams{},
			SearchFields: []string{"name", "chname"},
		},
		PostMethod:   &mixins.PostMethod{},
		PatchMethod:  &mixins.PatchMethod{},
		PutMethod:    &mixins.PutMethod{},
		DeleteMethod: &mixins.DeleteMethod{},
	}
	ins.RegisterMethod(restful.ListMethod, restful.HTTPMethodPost, "parse_sql", util.WithCloselyLogger(ins.ParseSql))
	ins.RegisterMethod(restful.ListMethod, restful.HTTPMethodGet, "get_schema", util.WithCloselyLogger(ins.GetSchema))
	ins.RegisterMethod(restful.ListMethod, restful.HTTPMethodPost, "check_formula", util.WithCloselyLogger(ins.CheckFormula))
	return ins
}

type parseSqlParams struct {
	Sql string `json:"sql"`
}

func (dm *Meta) ParseSql(ctx context.Context, req ghttp.Request) ghttp.Response {
	resource := restful.ResourceFromContext(ctx)
	textParams := model.NewModel(&parseSqlParams{})
	serializer := resource.GetSerializer(textParams)
	if err := serializer.ParseFromBody(ctx, req); err != nil {
		return response.NewError(400, err)
	}
	if err := serializer.Validate(ctx); err != nil {
		return response.NewError(400, err)
	}
	jsonData := serializer.JsonData()
	sql := jsonData["sql"].(string)

	res, err := util.ExtractColumnFromCreateSQL(sql)
	if err != nil {
		return response.NewError(400, err)
	}
	data := map[string]any{
		"column": res,
	}
	return &response.Response{
		Status: 0,
		Data:   data,
		Msg:    "ok",
	}
}

type getSchemaParams struct {
	ID int `json:"id"`
}

func (dm *Meta) GetSchema(ctx context.Context, req ghttp.Request) ghttp.Response {
	resource := restful.ResourceFromContext(ctx)
	getSchemaParams := model.NewModel(&getSchemaParams{})
	params := restful.GetQuery(req)
	serializer := resource.GetSerializer(getSchemaParams)
	if err := serializer.ParseFromQuery(ctx, params); err != nil {
		return response.NewError(400, err)
	}
	if err := serializer.Validate(ctx); err != nil {
		return response.NewError(400, err)
	}
	jsonData := serializer.JsonData()
	schemaID := jsonData["id"].(int)
	var meta mdb.DqcMeta
	res := resource.GetDB().Model(&mdb.DqcMeta{}).Where("id = ?", schemaID).First(&meta)
	if res.Error != nil {
		return response.NewError(500, res.Error)
	}
	schema := meta.Schema
	schemaList, ok := schema["schemaList"]
	if !ok {
		return response.NewError(500, fmt.Errorf("schemaList not found"))
	}
	retSchema, err := dqc.SchemaStandard(schemaList)
	if err != nil {
		return response.NewError(500, err)
	}

	noticeConfig := meta.NoticeConfig
	if val, ok := noticeConfig["enabled"].(bool); ok && val {
		mm := mdb.ManageMeta{}
		robotName := noticeConfig["robot"].(string)
		robotIns, err := mm.GetRobot(ctx, robotName)
		if err == nil {
			token, _ := robotIns.Params["token"].(string)
			retSchema["robot"] = map[string]any{
				"token":   token,
				"groupid": noticeConfig["groupid"],
			}
		}
	}
	return &response.Response{
		Status: 0,
		Data:   retSchema,
		Msg:    "ok",
	}
}

type checkFormula struct {
	Formula string            `json:"formula"`
	Vals    map[string]string `json:"vals"`
}

func (dm *Meta) CheckFormula(ctx context.Context, req ghttp.Request) ghttp.Response {
	resource := restful.ResourceFromContext(ctx)
	checkFormulaParams := model.NewModel(&checkFormula{})
	serializer := resource.GetSerializer(checkFormulaParams)
	if err := serializer.ParseFromBody(ctx, req); err != nil {
		return response.NewError(400, err)
	}
	if err := serializer.Validate(ctx); err != nil {
		return response.NewError(400, err)
	}
	checkFormulaData := serializer.StructData().(*checkFormula)

	err := dqc.CheckFormula(checkFormulaData.Formula, checkFormulaData.Vals)
	if err != nil {
		return &response.Response{
			Status: 0,
			Data:   false,
			Msg:    err.Error(),
		}
	}
	return &response.Response{
		Status: 0,
		Data:   true,
		Msg:    "ok",
	}
}
