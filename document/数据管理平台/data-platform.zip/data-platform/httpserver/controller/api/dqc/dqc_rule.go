package dqc

import (
	"icode.baidu.com/baidu/ps-se-go/restful"
	"icode.baidu.com/baidu/ps-se-go/restful/field"
	"icode.baidu.com/baidu/ps-se-go/restful/mixins"

	"icode.baidu.com/baidu/search/data-platform/model/dao/mdb"
)

type Rule struct {
	*restful.Resource
	*mixins.GetMethod
	*mixins.ListMethod
	*mixins.PostMethod
	*mixins.PatchMethod
	*mixins.PutMethod
	*mixins.DeleteMethod
}

type ruleSearchParams struct {
	ID      string          `gorm:"column:id" json:"id"`
	Name    string          `gorm:"column:name" json:"name"`
	Creator string          `gorm:"column:creator" json:"creator"`
	Start   field.Timestamp `gorm:"column:create_time;" json:"start" operate:">="`
	End     field.Timestamp `gorm:"column:create_time;" json:"end" operate:"<"`
	Type    string          `gorm:"column:type" json:"type"`
}

func NewDqcRule() *Rule {
	// 创建一个新的 Model 实例
	ins := &Rule{
		Resource:  restful.NewResource(&mdb.DqcRule{}),
		GetMethod: &mixins.GetMethod{},
		ListMethod: &mixins.ListMethod{
			Offset:       0,
			Limit:        10,
			OrderBy:      []string{"id desc"},
			SearchParams: &ruleSearchParams{},
			SearchFields: []string{"name"},
		},
		PostMethod:   &mixins.PostMethod{},
		PatchMethod:  &mixins.PatchMethod{},
		PutMethod:    &mixins.PutMethod{},
		DeleteMethod: &mixins.DeleteMethod{},
	}
	return ins
}
