/*
 * @Author: yandong03 yandong03@baidu.com
 * @Date: 2024-08-27 15:11:34
 * @LastEditors: houming01 houming01@baidu.com
 * @LastEditTime: 2024-10-11 15:12:25
 * @FilePath: /data-platform/httpserver/controller/api/science/task.go
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
package science

import (
	"context"
	"encoding/json"
	"errors"
	"time"

	"icode.baidu.com/baidu/gdp/ghttp"
	"icode.baidu.com/baidu/ps-se-go/restful"
	"icode.baidu.com/baidu/ps-se-go/restful/field"
	"icode.baidu.com/baidu/ps-se-go/restful/mixins"
	"icode.baidu.com/baidu/ps-se-go/restful/model"
	"icode.baidu.com/baidu/ps-se-go/restful/response"

	"icode.baidu.com/baidu/search/data-platform/library/util"
	"icode.baidu.com/baidu/search/data-platform/model/dao/mdb"
	"icode.baidu.com/baidu/search/data-platform/model/service/science"
)

type Task struct {
	*restful.Resource
	*mixins.GetMethod
	*mixins.ListMethod
	*mixins.PostMethod
	*mixins.PatchMethod
	*mixins.PutMethod
	*mixins.DeleteMethod
}

type taskSearchParams struct {
	Creator  string          `gorm:"column:creator" json:"creator"`
	Name     string          `gorm:"column:name" json:"name"`
	TID      string          `gorm:"column:tid" json:"tid"`
	ID       string          `gorm:"id" json:"id"`
	TaskType string          `gorm:"column:task_type" json:"taskType"`
	Start    field.Timestamp `gorm:"column:create_time;" json:"start" operate:">="`
	End      field.Timestamp `gorm:"column:create_time;" json:"end" operate:"<"`
}

func NewScienceTask() *Task {
	ins := &Task{
		Resource:  restful.NewResource(&mdb.ScienceTask{}),
		GetMethod: &mixins.GetMethod{},
		ListMethod: &mixins.ListMethod{
			Offset:       0,
			Limit:        10,
			OrderBy:      []string{"id desc"},
			SearchParams: &taskSearchParams{},
			SearchFields: []string{"creator", "name", "tid"},
		},
		PostMethod:   &mixins.PostMethod{},
		PatchMethod:  &mixins.PatchMethod{},
		PutMethod:    &mixins.PutMethod{},
		DeleteMethod: &mixins.DeleteMethod{},
	}
	ins.RegisterMethod(restful.ListMethod, restful.HTTPMethodPost, "set_context", util.WithCloselyLogger(ins.SetContext))
	ins.RegisterMethod(restful.ListMethod, restful.HTTPMethodGet, "get_context", util.WithCloselyLogger(ins.GetContext))
	ins.RegisterMethod(restful.ListMethod, restful.HTTPMethodGet, "callback", util.WithCloselyLogger(ins.Callback))
	ins.RegisterMethod(restful.ListMethod, restful.HTTPMethodGet, "get_task", util.WithCloselyLogger(ins.GetTask))
	ins.RegisterMethod(restful.ListMethod, restful.HTTPMethodPost, "set_result", util.WithCloselyLogger(ins.SetResult))
	ins.RegisterMethod(restful.ListMethod, restful.HTTPMethodGet, "get_task_content", util.WithCloselyLogger(ins.GetTaskContent))
	ins.RegisterMethod(restful.ListMethod, restful.HTTPMethodGet, "set_success", util.WithCloselyLogger(ins.SetSuccess))
	ins.RegisterMethod(restful.ListMethod, restful.HTTPMethodGet, "get_abtest_result", util.WithCloselyLogger(ins.GetAbtestResult))
	return ins
}

type setContextParams struct {
	ID    string `json:"id" validate:"required"`
	Scope string `json:"scope" validate:"required"`
	Key   string `json:"key" validate:"required"`
	Value any    `json:"value" validate:"required"`
}

func (st *Task) SetContext(ctx context.Context, req ghttp.Request) ghttp.Response {
	resource := restful.ResourceFromContext(ctx)
	params := model.NewModel(&setContextParams{})
	serializer := resource.GetSerializer(params)
	if err := serializer.ParseFromBody(ctx, req); err != nil {
		return response.NewError(400, err)
	}
	if err := serializer.Validate(ctx); err != nil {
		return response.NewError(400, err)
	}
	paramsWithType := serializer.StructData().(*setContextParams)

	context := science.NewTaskContext(paramsWithType.ID)
	err := context.SetContext(ctx, paramsWithType.Scope, paramsWithType.Key, paramsWithType.Value)
	if err != nil {
		return response.NewError(400, err)
	}
	return &response.Response{
		Status: 0,
		Msg:    "ok",
	}
}

type getContextParams struct {
	ID    string `json:"id" validate:"required"`
	Scope string `json:"scope" validate:"required"`
}

func (st *Task) GetContext(ctx context.Context, req ghttp.Request) ghttp.Response {
	resource := restful.ResourceFromContext(ctx)
	params := model.NewModel(&getContextParams{})
	serializer := resource.GetSerializer(params)
	if err := serializer.ParseFromQuery(ctx, restful.GetQuery(req)); err != nil {
		return response.NewError(400, err)
	}
	if err := serializer.Validate(ctx); err != nil {
		return response.NewError(400, err)
	}
	paramsWithType := serializer.StructData().(*getContextParams)

	context := science.NewTaskContext(paramsWithType.ID)
	values, err := context.GetContext(ctx, paramsWithType.Scope)
	if err != nil {
		return response.NewError(400, err)
	}
	return &response.Response{
		Status: 0,
		Msg:    "ok",
		Data:   values,
	}
}

type callbackParams struct {
	TID    string `json:"tid" validate:"required"`
	Status int    `json:"status" validate:"required"`
}

func (st *Task) Callback(ctx context.Context, req ghttp.Request) ghttp.Response {
	resource := restful.ResourceFromContext(ctx)
	params := model.NewModel(&callbackParams{})
	serializer := resource.GetSerializer(params)
	if err := serializer.ParseFromQuery(ctx, restful.GetQuery(req)); err != nil {
		return response.NewError(400, err)
	}
	if err := serializer.Validate(ctx); err != nil {
		return response.NewError(400, err)
	}
	paramsWithType := serializer.StructData().(*callbackParams)
	updates := map[string]any{
		"status": paramsWithType.Status,
	}
	if paramsWithType.Status == 2 {
		updates["finish_time"] = time.Now()
	}
	ret := resource.GetDB().Model(&mdb.ScienceTask{}).Where("tid = ?", paramsWithType.TID).Updates(updates)
	if ret.Error != nil {
		return response.NewError(400, ret.Error)
	}
	ret = resource.GetDB().Model(&mdb.TaskRunHistory{}).Where("tid = ?", paramsWithType.TID).Updates(updates)
	if ret.Error != nil {
		return response.NewError(400, ret.Error)
	}
	return &response.Response{
		Status: 0,
		Msg:    "ok",
	}
}

type getTaskParams struct {
	TID         string `json:"tid" validate:"required"`
	TaskType    string `json:"task_type" validate:"required"`
	IsBacktrace bool   `json:"is_backtrace"` // 是否回溯
	JobID       string `json:"job_id"`       //唯一标识
	TaskID      int64  `json:"task_id"`      // 需要回溯的任务ID
}

func (st *Task) GetTask(ctx context.Context, req ghttp.Request) ghttp.Response {
	resource := restful.ResourceFromContext(ctx)
	params := model.NewModel(&getTaskParams{})
	serializer := resource.GetSerializer(params)
	if err := serializer.ParseFromQuery(ctx, restful.GetQuery(req)); err != nil {
		return response.NewError(400, err)
	}
	if err := serializer.Validate(ctx); err != nil {
		return response.NewError(400, err)
	}
	paramsWithType := serializer.StructData().(*getTaskParams)

	task, err := science.GetTask(ctx, paramsWithType.TaskType, paramsWithType.TID,
		paramsWithType.IsBacktrace, paramsWithType.TaskID, paramsWithType.JobID)
	if err != nil {
		return response.NewError(400, err)
	}
	return &response.Response{
		Status: 0,
		Msg:    "ok",
		Data: map[string]any{
			"id":      task.ID,
			"content": task.TaskParams,
		},
	}
}

type setResultParams struct {
	TID    string         `json:"tid" validate:"required"`
	Result map[string]any `json:"result" validate:"required"`
}

func (st *Task) SetResult(ctx context.Context, req ghttp.Request) ghttp.Response {
	resource := restful.ResourceFromContext(ctx)
	params := model.NewModel(&setResultParams{})
	serializer := resource.GetSerializer(params)
	if err := serializer.ParseFromBody(ctx, req); err != nil {
		return response.NewError(400, err)
	}
	if err := serializer.Validate(ctx); err != nil {
		return response.NewError(400, err)
	}
	paramsWithType := serializer.StructData().(*setResultParams)

	resultBytes, _ := json.Marshal(paramsWithType.Result)

	ret := resource.GetDB().Model(&mdb.ScienceTask{}).Where("tid = ?", paramsWithType.TID).Update("result", string(resultBytes))
	if ret.Error != nil {
		return response.NewError(400, ret.Error)
	}
	ret = resource.GetDB().Model(&mdb.TaskRunHistory{}).Where("tid = ?", paramsWithType.TID).Update("result", string(resultBytes))
	if ret.Error != nil {
		return response.NewError(400, ret.Error)
	}
	return &response.Response{
		Status: 0,
		Msg:    "ok",
	}
}

type getTaskContentParams struct {
	TID string `json:"tid" validate:"required"`
}

func (st *Task) GetTaskContent(ctx context.Context, req ghttp.Request) ghttp.Response {
	resource := restful.ResourceFromContext(ctx)
	params := model.NewModel(&getTaskContentParams{})
	serializer := resource.GetSerializer(params)

	if err := serializer.ParseFromQuery(ctx, restful.GetQuery(req)); err != nil {
		return response.NewError(400, err)
	}
	if err := serializer.Validate(ctx); err != nil {
		return response.NewError(400, err)
	}
	paramsWithType := serializer.StructData().(*getTaskContentParams)
	taskContent, err := science.GetTaskContent(ctx, paramsWithType.TID)
	if err == nil {
		return &response.Response{
			Status: 0,
			Msg:    "ok",
			Data:   taskContent,
		}
	}
	return response.NewError(400, err)
}

type setSuccessParams struct {
	ID    string `json:"id" validate:"required"`
	JobID string `json:"jobId"`
}

func (st *Task) SetSuccess(ctx context.Context, req ghttp.Request) ghttp.Response {
	resource := restful.ResourceFromContext(ctx)
	params := model.NewModel(&setSuccessParams{})
	serializer := resource.GetSerializer(params)

	if err := serializer.ParseFromQuery(ctx, restful.GetQuery(req)); err != nil {
		return response.NewError(400, err)
	}
	if err := serializer.Validate(ctx); err != nil {
		return response.NewError(400, err)
	}
	paramsWithType := serializer.StructData().(*setSuccessParams)
	var dao mdb.TaskRunHistory
	ret := resource.GetDB().Model(&mdb.TaskRunHistory{}).Where("id = ?", paramsWithType.ID).First(&dao)
	if ret.Error != nil {
		return response.NewError(400, ret.Error)
	}
	setMsg, err := science.SetSuccess(dao.TaskType, dao.TaskParams, paramsWithType.JobID)
	if err != nil {
		return response.NewError(400, err)
	}
	resource.GetDB().Model(&mdb.TaskRunHistory{}).Where("id = ?", paramsWithType.ID).Update("status", 2)
	return &response.Response{
		Status: 0,
		Msg:    "ok",
		Data:   setMsg,
	}

}

type getTaskResultParams struct {
	TaskID string `json:"taskId" validate:"required"`
}

func (st *Task) GetAbtestResult(ctx context.Context, req ghttp.Request) ghttp.Response {
	resource := restful.ResourceFromContext(ctx)
	params := model.NewModel(&getTaskResultParams{})
	serializer := resource.GetSerializer(params)

	if err := serializer.ParseFromQuery(ctx, restful.GetQuery(req)); err != nil {
		return response.NewError(400, err)
	}
	if err := serializer.Validate(ctx); err != nil {
		return response.NewError(400, err)
	}

	paramsWithType := serializer.StructData().(*getTaskResultParams)
	var dao []*mdb.TaskRunHistory
	ret := resource.GetDB().Model(&mdb.TaskRunHistory{}).Where("task_id = ?", paramsWithType.TaskID).Where("result != '{}'").Find(&dao)
	if ret.Error != nil {
		return response.NewError(400, ret.Error)
	}
	if len(dao) == 0 {
		return response.NewError(400, errors.New("no result found"))
	}
	retData := make(map[string]any)

	for _, v := range dao {
		if _, ok := v.Result["fields"]; !ok {
			continue
		} else {
			retData["fields"] = v.Result["fields"]
		}

		if _, ok := v.Result["values"]; !ok {
			continue
		} else {
			if _, exists := retData["values"]; !exists {
				retData["values"] = []any{}
			}
			retData["values"] = append(retData["values"].([]any), v.Result["values"])
		}
	}
	return &response.Response{
		Status: 0,
		Msg:    "ok",
		Data:   retData,
	}
}
