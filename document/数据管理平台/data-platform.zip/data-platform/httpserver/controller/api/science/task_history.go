/*
 * @Author: yandong03 yandong03@baidu.com
 * @Date: 2024-09-09 11:43:44
 * @LastEditors: yandong03 yandong03@baidu.com
 * @LastEditTime: 2024-09-13 17:37:27
 * @FilePath: /data-platform/httpserver/controller/api/science/task_history.go
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */

package science

import (
	"icode.baidu.com/baidu/ps-se-go/restful"
	"icode.baidu.com/baidu/ps-se-go/restful/field"
	"icode.baidu.com/baidu/ps-se-go/restful/mixins"
	"icode.baidu.com/baidu/search/data-platform/model/dao/mdb"
)

type TaskHistory struct {
	*restful.Resource
	*mixins.GetMethod
	*mixins.ListMethod
	*mixins.PostMethod
	*mixins.PatchMethod
	*mixins.PutMethod
	*mixins.DeleteMethod
}

type taskHistorySearchParams struct {
	ID     string          `gorm:"id" json:"id"`
	TaskID int64           `gorm:"column:task_id;" json:"taskId"`
	Start  field.Timestamp `gorm:"column:create_time;" json:"start" operate:">="`
	End    field.Timestamp `gorm:"column:create_time;" json:"end" operate:"<"`
}

func NewScienceTaskHistory() *TaskHistory {
	ins := &TaskHistory{
		Resource:  restful.NewResource(&mdb.TaskRunHistory{}),
		GetMethod: &mixins.GetMethod{},
		ListMethod: &mixins.ListMethod{
			Offset:       0,
			Limit:        10,
			OrderBy:      []string{"id desc"},
			SearchParams: &taskHistorySearchParams{},
			SearchFields: []string{"tid"},
		},
		PostMethod:   &mixins.PostMethod{},
		PatchMethod:  &mixins.PatchMethod{},
		PutMethod:    &mixins.PutMethod{},
		DeleteMethod: &mixins.DeleteMethod{},
	}
	return ins
}
