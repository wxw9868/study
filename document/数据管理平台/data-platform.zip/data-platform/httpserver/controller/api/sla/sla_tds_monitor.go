package sla

import (
	"context"
	"encoding/json"
	"fmt"
	"io"

	"icode.baidu.com/baidu/gdp/ghttp"
	"icode.baidu.com/baidu/ps-se-go/restful"
	"icode.baidu.com/baidu/ps-se-go/restful/mixins"
	"icode.baidu.com/baidu/ps-se-go/restful/response"

	"icode.baidu.com/baidu/search/data-platform/library/util"
	"icode.baidu.com/baidu/search/data-platform/model/dao/mdb"
)

type Tds struct {
	*restful.Resource
	*mixins.GetMethod
	*mixins.ListMethod
	*mixins.PostMethod
	*mixins.PatchMethod
	*mixins.PutMethod
	*mixins.DeleteMethod
}

type TdsSearchParams struct {
}

type Response struct {
	ErrCode int    `json:"errcode"`
	ErrMsg  string `json:"errmsg"`
	Data    Data   `json:"data"`
}

type Data struct {
	Fail map[string]any `json:"fail"`
}

type PrometheusRequest struct {
	AccountID        string              `json:"accountId"`
	AlarmTags        []map[string]string `json:"alarmTags"`
	AlarmValue       string              `json:"alarmValue"`
	AlertingRuleID   string              `json:"alertingRuleId"`
	AlertingRuleName string              `json:"alertingRuleName"`
	EndTime          int64               `json:"endTime"`
	EventID          string              `json:"eventId"`
	EventTags        []map[string]string `json:"eventTags"`
	Severity         string              `json:"severity"`
	StartTime        int64               `json:"startTime"`
	Status           string              `json:"status"`
	Token            string              `json:"token"`
}

func NewTds() *Tds {
	ins := &Tds{
		Resource:  restful.NewResource(&mdb.DataMeta{}),
		GetMethod: &mixins.GetMethod{},
		ListMethod: &mixins.ListMethod{
			Offset:       0,
			Limit:        10,
			OrderBy:      []string{"id desc"},
			SearchParams: &TdsSearchParams{},
			SearchFields: []string{},
		},
		PostMethod:   &mixins.PostMethod{},
		PatchMethod:  &mixins.PatchMethod{},
		PutMethod:    &mixins.PutMethod{},
		DeleteMethod: &mixins.DeleteMethod{},
	}

	ins.RegisterMethod(restful.ListMethod, restful.HTTPMethodPost, "tds/monitor", util.WithCloselyLogger(ins.TdsMonitorTask))
	ins.RegisterMethod(restful.ListMethod, restful.HTTPMethodPost, "prometheus/monitor", util.WithCloselyLogger(ins.PrometheusMonitorTask))
	return ins
}

// tds任务调用接口将报警信息content入表、报警群报警
func (t *Tds) TdsMonitorTask(ctx context.Context, req ghttp.Request) ghttp.Response {
	var returnResponse Response

	reader := req.Body()
	readerBytes, err := io.ReadAll(reader)
	if err != nil {
		return ghttp.NewTextResponse(500, []byte(err.Error()))
	}

	// 将body数据接收到结构体
	var msg util.TooLTT
	if err := json.Unmarshal(readerBytes, &msg); err != nil {
		return response.NewError(500, err)
	}
	// 解析数据结构体
	newData, err := util.TdsData(&msg)
	if err != nil {
		return response.NewError(500, err)
	}

	resource := restful.ResourceFromContext(ctx)
	// 存储数据，contetent入表
	res := resource.GetDB().Create(&newData)
	if res.Error != nil {
		return response.NewError(500, res.Error)
	}
	// 接收查query参数token
	token := req.QueryDefault("access_token", "")
	if token == "" {
		err = fmt.Errorf("token为空，请求不规范: %v", token)
		return &response.Response{
			Status: 0,
			Data:   err,
		}
	}

	robot := util.NewHibotGroup(token, msg.Message.Header.Toid)
	robotMessage := util.RobotMessage{}
	robotMessage.AppendMessage(util.NewTextMessage(msg.Message.Body[0]["content"].(string)))
	robotMessage.AppendMessage(util.NewLinkMessage(msg.Message.Body[1]["href"].(string)))
	robotMessage.AppendMessage(util.NewTextMessage(msg.Message.Body[2]["content"].(string)))

	resp, err := robot.SendGroupMsg(ctx, robotMessage)

	if err != nil {
		err = fmt.Errorf("send robot msg failed: %w", err)
		return &response.Response{
			Status: 0,
			Data:   err,
		}
	}
	// 将JSON字符串解码到Response实例中
	err = json.Unmarshal([]byte(resp), &returnResponse)
	if err != nil {
		return &response.Response{
			Status: 0,
			Data:   err,
		}
	}
	return &response.Response{
		Status: 0,
		Data:   returnResponse,
	}
}

// prometheus回调接口接收报警信息
func (t *Tds) PrometheusMonitorTask(ctx context.Context, req ghttp.Request) ghttp.Response {
	var prometheusRequest PrometheusRequest

	reader := req.Body()
	readerBytes, err := io.ReadAll(reader)
	if err != nil {
		return ghttp.NewTextResponse(500, []byte(err.Error()))
	}
	if err := json.Unmarshal(readerBytes, &prometheusRequest); err != nil {
		return response.NewError(500, err)
	}

	var newData mdb.SLAPrometheusMonitor
	newData.AccountID = prometheusRequest.AccountID

	alarmTags, err := util.JSONToString(prometheusRequest.AlarmTags)
	if err != nil {
		return response.NewError(500, err)
	}
	newData.AlarmTags = alarmTags

	newData.AlarmValue = prometheusRequest.AlarmValue
	newData.AlertingRuleID = prometheusRequest.AlertingRuleID
	newData.AlertingRuleName = prometheusRequest.AlertingRuleName
	newData.EndTime = prometheusRequest.EndTime
	newData.EventID = prometheusRequest.EventID

	eventTags, err := util.JSONToString(prometheusRequest.EventTags)
	if err != nil {
		return response.NewError(500, err)
	}
	newData.EventTags = eventTags

	newData.Severity = prometheusRequest.Severity
	newData.StartTime = prometheusRequest.StartTime
	newData.Status = prometheusRequest.Status
	newData.Token = prometheusRequest.Token

	resource := restful.ResourceFromContext(ctx)
	// 存储数据，contetent入表
	res := resource.GetDB().Create(&newData)
	if res.Error != nil {
		return response.NewError(500, res.Error)
	}

	return &response.Response{
		Status: 0,
		Data:   0,
	}
}
