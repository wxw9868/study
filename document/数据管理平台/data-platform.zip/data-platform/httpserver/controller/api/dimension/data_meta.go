/*
 * @Author: yandong03 yandong03@baidu.com
 * @Date: 2024-07-25 15:47:20
 * @LastEditors: yandong03 yandong03@baidu.com
 * @LastEditTime: 2024-08-15 11:06:09
 * @FilePath: /data-platform/httpserver/controller/api/dimension/data_meta.go
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
package dimension

import (
	"context"
	"encoding/json"
	"fmt"

	"icode.baidu.com/baidu/gdp/ghttp"
	"icode.baidu.com/baidu/ps-se-go/restful"
	"icode.baidu.com/baidu/ps-se-go/restful/field"
	"icode.baidu.com/baidu/ps-se-go/restful/mixins"
	"icode.baidu.com/baidu/ps-se-go/restful/model"
	"icode.baidu.com/baidu/ps-se-go/restful/response"
	"icode.baidu.com/baidu/search/data-platform/library/delivery"
	custom_field "icode.baidu.com/baidu/search/data-platform/library/field"
	"icode.baidu.com/baidu/search/data-platform/library/util"

	lresource "icode.baidu.com/baidu/search/data-platform/library/resource"

	"icode.baidu.com/baidu/search/data-platform/model/dao/mdb"
	"icode.baidu.com/baidu/search/data-platform/model/service/common"
	"icode.baidu.com/baidu/search/data-platform/model/service/dimension"
)

type DataMeta struct {
	*restful.Resource
	*mixins.GetMethod
	*mixins.ListMethod
	*mixins.PostMethod
	*mixins.PatchMethod
	*mixins.PutMethod
	*mixins.DeleteMethod
}

type metaSearchParams struct {
	ID      string          `gorm:"column:id" json:"id"`
	Name    string          `gorm:"column:name" json:"name"`
	Creator string          `gorm:"column:creator" json:"creator"`
	Start   field.Timestamp `gorm:"column:create_time;" json:"start" operate:">="`
	End     field.Timestamp `gorm:"column:create_time;" json:"end" operate:"<"`
}

func NewDataMeta() *DataMeta {
	ins := &DataMeta{
		Resource:  restful.NewResource(&mdb.DataMeta{}),
		GetMethod: &mixins.GetMethod{},
		ListMethod: &mixins.ListMethod{
			Offset:       0,
			Limit:        10,
			OrderBy:      []string{"id desc"},
			SearchParams: &metaSearchParams{},
			SearchFields: []string{"name", "chname"},
		},
		PostMethod:   &mixins.PostMethod{},
		PatchMethod:  &mixins.PatchMethod{},
		PutMethod:    &mixins.PutMethod{},
		DeleteMethod: &mixins.DeleteMethod{},
	}
	ins.RegisterMethod(restful.ListMethod, restful.HTTPMethodGet, "deliver_data", util.WithCloselyLogger(ins.Delivery))
	ins.RegisterMethod(restful.ListMethod, restful.HTTPMethodGet, "delivery_cb", util.WithCloselyLogger(ins.UpdateOnlineVersion))
	ins.RegisterMethod(restful.ListMethod, restful.HTTPMethodPost, "parse_text", util.WithCloselyLogger(ins.ParseTextBySchema))
	return ins
}

func (dm *DataMeta) PostAfter(ctx context.Context, req ghttp.Request, id any, validData any) error {
	dao := mdb.EventLog{}
	content, _ := json.Marshal(validData)
	userName := util.GetCurrentUserName(ctx)
	did := id.(int64)
	return dao.AddNotice(ctx, lresource.EventCreateMeta, did, string(content), custom_field.UserType(userName))
}

func (dm *DataMeta) PatchAfter(ctx context.Context, req ghttp.Request, validData any) error {
	dao := mdb.EventLog{}
	// 临时hack一下restful库bug，库修复后删掉
	// dm.Resource.Model.ModelInterface = &mdb.DataMeta{}
	content, _ := json.Marshal(validData)
	userName := util.GetCurrentUserName(ctx)
	did := validData.(map[string]any)["id"].(int64)
	return dao.AddNotice(ctx, lresource.EventEditMeta, did, string(content), custom_field.UserType(userName))
}

type manualDeliverParams struct {
	ID      int64 `json:"id"`
	Version int   `json:"version"`
}

func (dm *DataMeta) Delivery(ctx context.Context, req ghttp.Request) ghttp.Response {
	resource := restful.ResourceFromContext(ctx)
	params := restful.GetQuery(req)
	deliverParams := model.NewModel(&manualDeliverParams{})
	serializer := resource.GetSerializer(deliverParams)
	userName := util.GetCurrentUserName(ctx)
	if err := serializer.ParseFromQuery(ctx, params); err != nil {
		return response.NewError(400, err)
	}
	if err := serializer.Validate(ctx); err != nil {
		return response.NewError(400, err)
	}
	jsonData := serializer.JsonData()
	id := jsonData["id"]
	version := jsonData["version"].(int)

	meta := mdb.DataMeta{}
	res := resource.GetDB().Model(&mdb.DataMeta{}).Where("id = ?", id).First(&meta)
	if res.Error != nil {
		return response.NewError(500, res.Error)
	}
	summary := map[string]any{
		"wantVersion": version,
	}
	err := delivery.Deliver(ctx, &meta, summary, lresource.ManualDeliveryData, userName, version)
	if err != nil {
		return response.NewError(500, err)
	}
	return &response.Response{
		Status: 0,
		Data:   nil,
		Msg:    "ok",
	}
}

type callbackVersionParams struct {
	ID               int64  `json:"id"`
	PreOnlineVersion int    `json:"pre_online_version"`
	Version          int    `json:"version"`
	Transition       string `json:"transition"`
}

func (dm *DataMeta) UpdateOnlineVersion(ctx context.Context, req ghttp.Request) ghttp.Response {
	resource := restful.ResourceFromContext(ctx)
	params := restful.GetQuery(req)
	callbackParams := model.NewModel(&callbackVersionParams{})
	serializer := resource.GetSerializer(callbackParams)
	if err := serializer.ParseFromQuery(ctx, params); err != nil {
		return response.NewError(400, err)
	}
	if err := serializer.Validate(ctx); err != nil {
		return response.NewError(400, err)
	}
	jsonData := serializer.JsonData()
	if jsonData["transition"] != "success" {
		return &response.Response{
			Status: 0,
			Data:   "transition ignored",
			Msg:    "ok",
		}
	}
	id := jsonData["id"].(int64)
	preOnlineVersion := jsonData["pre_online_version"].(int)
	onlineVersion := jsonData["version"].(int)

	err := dimension.UpdateOnlineVersion(ctx, id, preOnlineVersion, onlineVersion)
	// res := resource.GetDB().Model(&mdb.DataMeta{}).Where("id = ? and online_version = ?", id, preOnlineVersion).Update("online_version", onlineVersion)
	if err != nil {
		return response.NewError(500, err)
	}
	resp := &response.Response{
		Status: 0,
		Data:   nil,
		Msg:    "ok",
	}
	message := fmt.Sprintf("数据配送成功\n在线版本%d -> %d", preOnlineVersion, onlineVersion)
	common.SendNoticeMessagWithMetaID(ctx, lresource.LoggerService, id, "数据配送成功提醒", message)
	return resp
}

type parseTextParams struct {
	ID   string `json:"id"`
	Text string `json:"text"`
}

func (dm *DataMeta) ParseTextBySchema(ctx context.Context, req ghttp.Request) ghttp.Response {
	resource := restful.ResourceFromContext(ctx)
	textParams := model.NewModel(&parseTextParams{})
	serializer := resource.GetSerializer(textParams)
	if err := serializer.ParseFromBody(ctx, req); err != nil {
		return response.NewError(400, err)
	}
	if err := serializer.Validate(ctx); err != nil {
		return response.NewError(400, err)
	}
	jsonData := serializer.JsonData()
	content := jsonData["text"].(string)
	meta := mdb.DataMeta{}
	res := resource.GetDB().Model(&mdb.DataMeta{}).Where("id = ?", jsonData["id"]).First(&meta)
	if res.Error != nil {
		return response.NewError(500, res.Error)
	}
	data, err := util.ParseTextBySchema(ctx, content, meta.DataSchema)
	if err != nil {
		return response.NewError(500, err)
	}
	return &response.Response{
		Status: 0,
		Data:   data,
		Msg:    "ok",
	}
}
