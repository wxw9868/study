/*
 * @Author: yandong03 yandong03@baidu.com
 * @Date: 2024-07-22 21:44:45
 * @LastEditors: yandong03 yandong03@baidu.com
 * @LastEditTime: 2024-08-14 13:58:24
 * @FilePath: /data-platform/httpserver/controller/api/dimension/data_history.go
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AEbd
 */
package dimension

import (
	"context"
	"errors"

	"gorm.io/gorm"
	"icode.baidu.com/baidu/gdp/ghttp"
	"icode.baidu.com/baidu/ps-se-go/restful"
	"icode.baidu.com/baidu/ps-se-go/restful/field"
	"icode.baidu.com/baidu/ps-se-go/restful/mixins"
	"icode.baidu.com/baidu/ps-se-go/restful/model"
	"icode.baidu.com/baidu/ps-se-go/restful/response"

	"icode.baidu.com/baidu/search/data-platform/library/util"
	"icode.baidu.com/baidu/search/data-platform/model/dao/mdb"
	"icode.baidu.com/baidu/search/data-platform/model/service/dimension"
)

type DataHistory struct {
	*restful.Resource
	*mixins.GetMethod
	*mixins.ListMethod
	*mixins.PostMethod
	*mixins.PatchMethod
	*mixins.PutMethod
	*mixins.DeleteMethod
}

type searchParams struct {
	Version int             `gorm:"column:version" json:"version"`
	Did     int64           `gorm:"column:did" json:"did"`
	Creator string          `gorm:"column:creator" json:"creator"`
	Start   field.Timestamp `gorm:"column:create_time;" json:"start" operate:">="`
	End     field.Timestamp `gorm:"column:create_time;" json:"end" operate:"<"`
}

func NewDataHistory() *DataHistory {
	ins := &DataHistory{
		Resource:  restful.NewResource(&mdb.DataHistory{}),
		GetMethod: &mixins.GetMethod{},
		ListMethod: &mixins.ListMethod{
			Offset:       0,
			Limit:        10,
			OrderBy:      []string{"id desc"},
			SearchParams: &searchParams{},
		},
		PostMethod:   &mixins.PostMethod{},
		PatchMethod:  &mixins.PatchMethod{},
		PutMethod:    &mixins.PutMethod{},
		DeleteMethod: &mixins.DeleteMethod{},
	}
	ins.RegisterMethod(restful.ListMethod, restful.HTTPMethodPost, "publish_data", util.WithCloselyLogger(ins.PublishData))
	ins.RegisterMethod(restful.ListMethod, restful.HTTPMethodGet, "latest_data", util.WithCloselyLogger(ins.GetLatestData))
	ins.RegisterMethod(restful.ListMethod, restful.HTTPMethodGet, "version_data", util.WithCloselyLogger(ins.GetDataWithVersion))
	ins.RegisterMethod(restful.ListMethod, restful.HTTPMethodGet, "nearest_data", util.WithCloselyLogger(ins.GetNearestDataWithVersion))
	return ins
}

func (d *DataHistory) PublishData(ctx context.Context, req ghttp.Request) ghttp.Response {
	resource := restful.ResourceFromContext(ctx)
	publishSerializer := resource.GetSerializer(resource.GetModel())
	userName := util.GetCurrentUserName(ctx)

	if err := publishSerializer.ParseFromBody(ctx, req); err != nil {
		return response.NewError(400, err)
	}
	if err := publishSerializer.Validate(ctx); err != nil {
		return response.NewError(400, err)
	}
	publishData := publishSerializer.JsonData()
	did := publishData["did"].(int64)
	content := publishData["content"]

	summary := map[string]any{
		"did": did,
	}

	commentInfo := publishData["commentInfo"].(string)
	source := "人工编辑"

	targetVersion, err := dimension.UpdateData(ctx, did, content, summary, source, commentInfo, userName)

	if err != nil {
		return response.NewError(500, err)
	}

	return &response.Response{
		Status: 0,
		Data: map[string]any{
			"version": targetVersion,
		},
		Msg: "ok",
	}
}

type latestParams struct {
	Did int64 `json:"did" validate:"required"`
}

func (d *DataHistory) GetLatestData(ctx context.Context, req ghttp.Request) ghttp.Response {
	resource := restful.ResourceFromContext(ctx)
	params := restful.GetQuery(req)
	latestParams := model.NewModel(&latestParams{})
	serializer := resource.GetSerializer(latestParams)

	if err := serializer.ParseFromQuery(ctx, params); err != nil {
		return response.NewError(400, err)
	}
	if err := serializer.Validate(ctx); err != nil {
		return err
	}
	jsonData := serializer.JsonData()
	dao := mdb.DataHistory{}
	data, err := dao.MaxVersionData(ctx, jsonData["did"].(int64))

	if err != nil && errors.Is(err, gorm.ErrRecordNotFound) {
		return &response.Response{
			Status: 0,
			Data:   data,
			Msg:    "ok",
		}
	}
	if err != nil {
		return response.NewError(500, err)
	}
	return &response.Response{
		Status: 0,
		Data:   data,
		Msg:    "ok",
	}
}

type didWithVersionParams struct {
	Did        int64 `json:"did" validate:"required"`
	Version    int   `json:"version" validate:"required"`
	WithSchema bool  `json:"with_schema"`
}

// 获取最近版本的数据
func (d *DataHistory) GetDataWithVersion(ctx context.Context, req ghttp.Request) ghttp.Response {
	resource := restful.ResourceFromContext(ctx)
	params := restful.GetQuery(req)
	didWithVersionParams := model.NewModel(&didWithVersionParams{})
	serializer := resource.GetSerializer(didWithVersionParams)

	if err := serializer.ParseFromQuery(ctx, params); err != nil {
		return response.NewError(400, err)
	}
	if err := serializer.Validate(ctx); err != nil {
		return response.NewError(400, err)
	}
	jsonData := serializer.JsonData()
	dao := mdb.DataHistory{}
	data, err := dao.GetTargetVersionData(ctx, jsonData["did"].(int64), jsonData["version"].(int))

	if err != nil {
		return response.NewError(500, err)
	}

	var respData any

	var withSchema bool
	if _, ok := jsonData["with_schema"]; ok {
		if val, ok := jsonData["with_schema"].(bool); ok {
			withSchema = val
		}
	}

	if withSchema {
		metaDao := mdb.DataMeta{}
		schema, schemaErr := metaDao.GetSchema(ctx, jsonData["did"].(int64))

		if schemaErr != nil {
			return response.NewError(500, schemaErr)
		}
		respData = map[string]any{
			"data":   data,
			"schema": schema,
		}
	} else {
		respData = data
	}

	return &response.Response{
		Status: 0,
		Data:   respData,
		Msg:    "ok",
	}
}

// 获取距离特定版本最近的版本数据
func (d *DataHistory) GetNearestDataWithVersion(ctx context.Context, req ghttp.Request) ghttp.Response {
	resource := restful.ResourceFromContext(ctx)
	params := restful.GetQuery(req)
	didWithVersionParams := model.NewModel(&didWithVersionParams{})
	serializer := resource.GetSerializer(didWithVersionParams)

	if err := serializer.ParseFromQuery(ctx, params); err != nil {
		return response.NewError(400, err)
	}
	if err := serializer.Validate(ctx); err != nil {
		return response.NewError(400, err)
	}
	jsonData := serializer.JsonData()
	dao := mdb.DataHistory{}
	data, err := dao.GetNearestDataByVersion(ctx, jsonData["did"].(int64), jsonData["version"].(int))
	if err != nil {
		return response.NewError(500, err)
	}
	return &response.Response{
		Status: 0,
		Data:   data,
		Msg:    "ok",
	}
}
