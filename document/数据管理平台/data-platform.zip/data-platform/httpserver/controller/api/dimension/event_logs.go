/*
 * @Author: yandong03 yandong03@baidu.com
 * @Date: 2024-07-23 20:42:46
 * @LastEditors: yandong03 yandong03@baidu.com
 * @LastEditTime: 2024-08-01 16:26:25
 * @FilePath: /data-platform/httpserver/controller/api/dimension/event_logs.go
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
package dimension

import (
	"icode.baidu.com/baidu/ps-se-go/restful"
	"icode.baidu.com/baidu/ps-se-go/restful/field"
	"icode.baidu.com/baidu/ps-se-go/restful/mixins"

	"icode.baidu.com/baidu/search/data-platform/model/dao/mdb"
)

type EventLogs struct {
	*restful.Resource
	*mixins.GetMethod
	*mixins.ListMethod
	*mixins.PostMethod
	*mixins.PatchMethod
	*mixins.PutMethod
	*mixins.DeleteMethod
}

type eventLogSearchParams struct {
	Did        int64           `gorm:"column:did" json:"did"`
	EventType  string          `gorm:"column:event_type" json:"eventType"`
	Creator    string          `gorm:"column:creator" json:"creator"`
	DebugLevel int             `gorm:"column:debug_level" json:"debugLevel"`
	Start      field.Timestamp `gorm:"column:create_time;" json:"start" operate:">="`
	End        field.Timestamp `gorm:"column:create_time;" json:"end" operate:"<"`
}

func NewEventLogs() *EventLogs {
	ins := &EventLogs{
		Resource:  restful.NewResource(&mdb.EventLog{}),
		GetMethod: &mixins.GetMethod{},
		ListMethod: &mixins.ListMethod{
			Offset:       0,
			Limit:        10,
			OrderBy:      []string{"id desc"},
			SearchParams: &eventLogSearchParams{},
		},
		PostMethod:   &mixins.PostMethod{},
		PatchMethod:  &mixins.PatchMethod{},
		PutMethod:    &mixins.PutMethod{},
		DeleteMethod: &mixins.DeleteMethod{},
	}
	return ins
}
