/*
* @Author: yandong03 yandong03@baidu.com
* @Date: 2024-07-30 14:39:47
* @LastEditors: houming01 houming01@baidu.com
* @LastEditTime: 2025-04-01 17:40:10
 */
package user

import (
	"context"
	"net/http"

	"icode.baidu.com/baidu/gdp/ghttp"
	"icode.baidu.com/baidu/gdp/logit"
	"icode.baidu.com/baidu/gdp/uuap"
	"icode.baidu.com/baidu/ps-se-go/restful/response"
)

func CurrentUser(ctx context.Context, _ ghttp.Request) ghttp.Response {
	u := uuap.SSOUserFromCtx(ctx)
	valid := false
	isLogin := false
	username := ""
	name := ""
	if u != nil {
		isLogin = true
		valid = true
		name = u.Name
		username = u.UserName
	}
	data := map[string]any{
		"userName": username,
		"name":     name,
		"isLogin":  isLogin,
		"valid":    valid,
	}
	logit.AddNotice(ctx, logit.Reflect("user", data))
	return &response.Response{
		Status: 0,
		Data:   data,
	}
}

func Login(ctx context.Context, req ghttp.Request) ghttp.Response {
	_ = uuap.SSOUserFromCtx(ctx)
	resp := ghttp.NewHTMLResponse(302, nil)
	resp.Headers = make(http.Header)
	resp.Headers.Add("Location", req.QueryDefault("url", "/"))
	return resp
}
