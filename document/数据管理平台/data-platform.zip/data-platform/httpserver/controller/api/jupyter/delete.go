/*
 * @Author: houming01 houming01@baidu.com
 * @Date: 2024-10-18 17:27:54
 * @LastEditors: houming01 houming01@baidu.com
 * @LastEditTime: 2024-10-21 16:14:43
 * @FilePath: /data-platform/httpserver/controller/api/jupyter/delete.go
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
package jupyter

import (
	"context"
	"encoding/json"
	"io"

	"github.com/baidubce/bce-sdk-go/services/bos"
	"icode.baidu.com/baidu/gdp/ghttp"
)

type DelReq struct {
	UserName string `json:"username"`
	Path     string `json:"path"`
}

func Delete(ctx context.Context, req ghttp.Request) ghttp.Response {
	var delReq DelReq
	reader := req.Body()
	bytes, err := io.ReadAll(reader)
	if err != nil {
		return ghttp.NewTextResponse(500, []byte(err.Error()))
	}
	if err := json.Unmarshal(bytes, &delReq); err != nil {
		return ghttp.NewTextResponse(500, []byte("json parse error"))
	}
	bosClient, _ := bos.NewClient(ak, sk, endpoint)
	bosClient.Config.CnameEnabled = true
	delReq.Path = "/jupyter/" + delReq.UserName + "/" + delReq.Path
	err = bosClient.DeleteObject(bucket, delReq.Path)
	return ghttp.NewTextResponse(200, []byte("ok"))
}
