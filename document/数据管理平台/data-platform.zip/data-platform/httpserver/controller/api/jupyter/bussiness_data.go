/*
 * @Author: houming01 houming01@baidu.com
 * @Date: 2024-10-21 16:51:55
 * @LastEditors: houming01 houming01@baidu.com
 * @LastEditTime: 2024-10-29 15:00:51
 * @FilePath: /data-platform/httpserver/controller/api/jupyter/bussiness_data.go
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
package jupyter

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"

	"icode.baidu.com/baidu/gdp/ghttp"
	"icode.baidu.com/baidu/ps-se-go/restful"
	"icode.baidu.com/baidu/ps-se-go/restful/mixins"
	"icode.baidu.com/baidu/ps-se-go/restful/response"
	"icode.baidu.com/baidu/search/data-platform/model/dao/mdb"
)

type TaskParams struct {
	*restful.Resource
	*mixins.GetMethod
	*mixins.ListMethod
	*mixins.PostMethod
	*mixins.PatchMethod
	*mixins.PutMethod
	*mixins.DeleteMethod
}

func NewJupyterTaskParams() *TaskParams {
	ins := &TaskParams{
		Resource:  restful.NewResource(&mdb.BusinessData{}),
		GetMethod: &mixins.GetMethod{},
		ListMethod: &mixins.ListMethod{
			Offset:  0,
			Limit:   10,
			OrderBy: []string{"id desc"},
		},
		PostMethod:   &mixins.PostMethod{},
		PatchMethod:  &mixins.PatchMethod{},
		PutMethod:    &mixins.PutMethod{},
		DeleteMethod: &mixins.DeleteMethod{},
	}
	return ins
}

func (t *TaskParams) PatchBefore(ctx context.Context, req ghttp.Request) error {
	rb := restful.RequestBodyFromContext(ctx)
	if rb == nil {
		return response.NewError(400, errors.New("BeforePost RequestBodyFromContext failed!"))
	}
	body := rb.Get()
	var params map[string]any

	err := json.Unmarshal(body, &params)
	if err != nil {
		return response.NewError(400, fmt.Errorf("BeforePost json Unmarshal failed! msg: %w", err))
	}
	if ID, ok := params["id"]; !ok {
		return response.NewError(400, errors.New("id not found"))
	} else {
		businessData := mdb.NewBusinessData()
		results, err := businessData.FindOneRecord(ctx, map[string]any{"id": ID})
		if err != nil || len(results) == 0 {
			return response.NewError(400, errors.New("id not found"))
		}
		params["version"] = results[0].Version + 1
	}

	pByte, err := json.Marshal(params)
	if err != nil {
		return err
	}
	rb.Set(pByte)
	return nil
}
