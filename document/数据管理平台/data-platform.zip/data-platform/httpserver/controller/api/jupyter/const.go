/*
 * @Author: houming01 houming01@baidu.com
 * @Date: 2024-10-21 16:09:30
 * @LastEditors: houming01 houming01@baidu.com
 * @LastEditTime: 2024-10-21 16:10:46
 * @FilePath: /data-platform/httpserver/controller/api/jupyter/const.go
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
package jupyter

const (
	ak       = "8351401cd3494e5a802bc2ca3ec5c3d8"
	sk       = "63e57447b47441c19e4784872b745b44"
	endpoint = "https://jupyter-store.bj.bcebos.com"
	bucket   = "jupyter-store"
)
