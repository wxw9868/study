/*
 * @Author: houming01 houming01@baidu.com
 * @Date: 2024-10-18 17:27:58
 * @LastEditors: houming01 houming01@baidu.com
 * @LastEditTime: 2024-10-22 16:25:00
 * @FilePath: /data-platform/httpserver/controller/api/jupyter/save.go
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
package jupyter

import (
	"context"
	"encoding/json"
	"fmt"
	"io"

	"github.com/baidubce/bce-sdk-go/services/bos"
	"icode.baidu.com/baidu/gdp/ghttp"
)

type SaveReq struct {
	Content  any    `json:"content"`
	Path     string `json:"path"`
	Username string `json:"username"`
}

func Save(ctx context.Context, req ghttp.Request) ghttp.Response {
	var saveReq SaveReq
	var result string
	reader := req.Body()
	bytes, err := io.ReadAll(reader)
	if err != nil {
		return ghttp.NewTextResponse(500, []byte(err.Error()))
	}
	if err := json.Unmarshal(bytes, &saveReq); err != nil {
		fmt.Println(err.Error())
		return ghttp.NewTextResponse(500, []byte("json parse error"))
	}
	bosClient, _ := bos.NewClient(ak, sk, endpoint)
	saveReq.Path = "jupyter/" + saveReq.Username + "/" + saveReq.Path
	err = bosClient.DeleteObject(bucket, saveReq.Path)

	switch v := saveReq.Content.(type) {
	case map[string]any:
		jsonStr, _ := json.Marshal(v)
		result = string(jsonStr)
	case string:
		result = v
	}
	_, err = bosClient.PutObjectFromBytes(bucket, saveReq.Path, []byte(result), nil)

	return ghttp.NewTextResponse(200, []byte("ok"))
}
