package alarm

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"strconv"
	"strings"

	"icode.baidu.com/baidu/gdp/ghttp"
	"icode.baidu.com/baidu/gdp/logit"
	"icode.baidu.com/baidu/search/data-platform/library/util"
)

// 更多参数请参考 https://github.com/go-playground/validator
type TDAAlarmContent struct {
	ChartName string `json:"chart_name"`
	AlterTime string `json:"alter_time"`
	AlterData []struct {
		Ruler string                   `json:"ruler"`
		Data  []map[string]interface{} `json:"data"`
	} `json:"alter_data"`
	DashboardTitle string `json:"dashboard_title"`
	DashboardURL   string `json:"dashboard_url"`
}

type Response struct {
	Code    int    `json:"code"`
	Message string `json:"message"`
}

func TdaExecute(ctx context.Context, req ghttp.Request) ghttp.Response {
	var resp Response
	alarmContent := TDAAlarmContent{}

	pbody, _ := io.ReadAll(req.Body())
	logit.AddNotice(ctx, logit.String("body", string(pbody)))

	err := json.Unmarshal(pbody, &alarmContent)
	if err != nil {
		resp.Code = 1
		resp.Message = "无法解析数据"
		logit.AddNotice(ctx, logit.String("parseError", err.Error()))
		return ghttp.NewJSONResponse(http.StatusOK, resp)
	}

	groupID := req.QueryDefault("group_id", "0")
	groupIDInt, err := strconv.Atoi(groupID)
	if err != nil {
		resp.Code = 2
		resp.Message = "群号非法"
	}
	logit.AddNotice(ctx, logit.String("group_id", groupID))

	accessToken := req.QueryDefault("access_token", "")
	atUsers := req.QueryDefault("at_users", "")
	needContent := req.QueryDefault("need_content", "1")
	logit.AddNotice(ctx, logit.String("at_users", atUsers))
	logit.AddNotice(ctx, logit.String("access_token", accessToken))

	robot := util.NewHibotGroup(accessToken, []int64{int64(groupIDInt)})

	if needContent == "1" {
		robotMessage := util.RobotMessage{}
		markDownMessage := generateMarkdownFromTDAAlarm(alarmContent)
		logit.AddNotice(ctx, logit.String("markDownMessage", markDownMessage))
		robotMessage.AppendMessage(util.NewMdMessage(markDownMessage))

		sendRet, err := robot.SendGroupMsg(ctx, robotMessage)
		if err != nil {
			resp.Code = 3
			resp.Message = err.Error()
			logit.AddNotice(ctx, logit.String("firstSendError", err.Error()))
			logit.AddNotice(ctx, logit.String("firstSendErrorRet", sendRet))
			return ghttp.NewJSONResponse(http.StatusOK, resp)
		}
	}

	if len(atUsers) > 0 {
		atRobotMessage := util.RobotMessage{}
		userIds := strings.Split(atUsers, ",")
		atRobotMessage.AppendMessage(util.NewAtMessage(userIds...))
		sendRet, err := robot.SendGroupMsg(ctx, atRobotMessage)
		if err != nil {
			logit.AddNotice(ctx, logit.String("secondSendError", err.Error()))
		}
		logit.AddNotice(ctx, logit.String("secondSendErrorRet", sendRet))
	}
	resp.Code = 0
	resp.Message = "预警信息推送成功!"
	return ghttp.NewJSONResponse(http.StatusOK, resp)
}

func generateTableHeader(headers []string) string {
	var builder strings.Builder
	// 构建表头
	builder.WriteString("| ")
	builder.WriteString(strings.Join(headers, " | "))
	builder.WriteString(" |\n")
	return builder.String()
}

func generateMarkdownTableFromMap(record map[string]interface{}, headers []string) string {
	if len(record) == 0 {
		return ""
	}
	var builder strings.Builder

	// 构建分隔符
	builder.WriteString("| ")
	for range record {
		builder.WriteString(":--: | ")
	}
	builder.WriteString("\n")

	// 构建表格内容
	builder.WriteString("| ")
	values := make([]string, 0, len(record))
	for _, key := range headers {
		values = append(values, util.ToString(record[key]))
	}
	builder.WriteString(strings.Join(values, " | "))
	builder.WriteString(" |\n")

	return builder.String()
}

func generateMarkdownFromTDAAlarm(alarmContent TDAAlarmContent) string {
	var builder strings.Builder

	builder.WriteString(fmt.Sprintf("<font color=\"red\">您所订阅的【%s】数据触发报警规则:</font>\n", alarmContent.DashboardTitle))
	builder.WriteString(fmt.Sprintf("> **报表-图表名称**: %s\n", alarmContent.ChartName))
	builder.WriteString(fmt.Sprintf("> **数据报警时间**: %s\n", alarmContent.AlterTime))

	for _, alterItem := range alarmContent.AlterData {
		builder.WriteString(fmt.Sprintf("> **预警规则**: %s\n\n", alterItem.Ruler))
		builder.WriteString("**触发报警的数据记录为：** \n")

		if len(alterItem.Data) > 0 {
			headers := make([]string, 0, len(alterItem.Data[0]))
			for key := range alterItem.Data[0] {
				headers = append(headers, key)
			}
			builder.WriteString(generateTableHeader(headers))
			// 遍历数据记录
			for _, record := range alterItem.Data {
				builder.WriteString(generateMarkdownTableFromMap(record, headers))
				builder.WriteString("\n")
			}
		}
	}
	builder.WriteString("提示: 最多显示前10条记录，更多数据请进入报表查看\n")
	builder.WriteString(fmt.Sprintf("报表地址: [%s](%s)\n\n", alarmContent.DashboardURL, alarmContent.DashboardURL))

	return builder.String()
}
