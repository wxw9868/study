package alarm

import (
	"encoding/json"
	"fmt"
	"testing"
)

func TestMarkDownMessage(t *testing.T) {
	exampleAlarmContent := TDAAlarmContent{
		ChartName: "答题活动PV-小时级",
		AlterTime: "2025-04-16 13:48:00",
		AlterData: []struct {
			Ruler string              `json:"ruler"`
			Data  []map[string]string `json:"data"`
		}{
			{
				Ruler: "规则1:反作弊占比 的 值 >= 0.09",
				Data: []map[string]string{
					{
						"小时级时间分区":    "5",
						"反作弊占比":      "0.0922",
						"滤后搜索pv-周同比": "0.1209",
						"滤后搜索pv-环比":  "0.0866",
						"滤前搜索pv":     "569815",
					},
				},
			},
		},
		DashboardTitle: "答题活动PV-实时数据",
		DashboardURL:   "http://tda.baidu-int.com/bi/superset/group/search_pr/dashboard/25310/?isCard=false",
	}

	s, _ := json.Marshal(exampleAlarmContent)
	fmt.Println(string(s))
	fmt.Println(generateMarkdownFromTDAAlarm(exampleAlarmContent))
}
