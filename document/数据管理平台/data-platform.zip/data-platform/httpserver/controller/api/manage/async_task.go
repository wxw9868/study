package manage

import (
	"context"
	"encoding/json"
	"fmt"

	"icode.baidu.com/baidu/gdp/ghttp"
	"icode.baidu.com/baidu/ps-se-go/restful"
	"icode.baidu.com/baidu/ps-se-go/restful/field"
	"icode.baidu.com/baidu/ps-se-go/restful/mixins"
	"icode.baidu.com/baidu/ps-se-go/restful/model"
	"icode.baidu.com/baidu/ps-se-go/restful/response"

	"icode.baidu.com/baidu/search/data-platform/library/delivery"
	"icode.baidu.com/baidu/search/data-platform/library/util"
	"icode.baidu.com/baidu/search/data-platform/model/dao/mdb"
)

type AsyncTask struct {
	*restful.Resource
	*mixins.GetMethod
	*mixins.ListMethod
	*mixins.PostMethod
	*mixins.PatchMethod
	*mixins.PutMethod
	*mixins.DeleteMethod
}

type asyncTaskSearchParams struct {
	Creator  string          `gorm:"column:creator" json:"creator"`
	Name     string          `gorm:"column:name" json:"name"`
	TaskType string          `gorm:"column:task_type" json:"taskType"`
	Start    field.Timestamp `gorm:"column:create_time;" json:"start" operate:">="`
	End      field.Timestamp `gorm:"column:create_time;" json:"end" operate:"<"`
}

func NewAsyncTask() *AsyncTask {
	ins := &AsyncTask{
		Resource:  restful.NewResource(&mdb.AsyncTask{}),
		GetMethod: &mixins.GetMethod{},
		ListMethod: &mixins.ListMethod{
			Offset:       0,
			Limit:        10,
			OrderBy:      []string{"id desc"},
			SearchParams: &asyncTaskSearchParams{},
			SearchFields: []string{"creator", "name"},
		},
		PostMethod:   &mixins.PostMethod{},
		PatchMethod:  &mixins.PatchMethod{},
		PutMethod:    &mixins.PutMethod{},
		DeleteMethod: &mixins.DeleteMethod{},
	}
	ins.RegisterMethod(restful.ListMethod, restful.HTTPMethodPost, "set_result", util.WithCloselyLogger(ins.SetResult))
	ins.RegisterMethod(restful.ListMethod, restful.HTTPMethodGet, "delivery_cb", util.WithCloselyLogger(ins.Callback))
	return ins
}

type setResultParams struct {
	ID     int64          `json:"id" validate:"required"`
	Result map[string]any `json:"result" validate:"required"`
}

func (d *AsyncTask) SetResult(ctx context.Context, req ghttp.Request) ghttp.Response {
	resource := restful.ResourceFromContext(ctx)
	params := model.NewModel(&setResultParams{})
	serializer := resource.GetSerializer(params)
	if err := serializer.ParseFromBody(ctx, req); err != nil {
		return response.NewError(400, err)
	}
	if err := serializer.Validate(ctx); err != nil {
		return response.NewError(400, err)
	}
	paramsWithType := serializer.StructData().(*setResultParams)

	resultBytes, _ := json.Marshal(paramsWithType.Result)
	ret := resource.GetDB().Model(&mdb.AsyncTask{}).Where("id = ?", paramsWithType.ID).Update("task_result", string(resultBytes))
	if ret.Error != nil {
		return response.NewError(400, ret.Error)
	}
	return &response.Response{
		Status: 0,
		Msg:    "ok",
	}
}

type callbackVersionParams struct {
	ID         int64  `json:"id"`
	Transition string `json:"transition"`
}

func (d *AsyncTask) Callback(ctx context.Context, req ghttp.Request) ghttp.Response {
	resource := restful.ResourceFromContext(ctx)
	params := restful.GetQuery(req)
	callbackParams := model.NewModel(&callbackVersionParams{})
	serializer := resource.GetSerializer(callbackParams)
	if err := serializer.ParseFromQuery(ctx, params); err != nil {
		return response.NewError(400, err)
	}
	if err := serializer.Validate(ctx); err != nil {
		return response.NewError(400, err)
	}
	paramsWithType := serializer.StructData().(*callbackVersionParams)

	status := 0
	if paramsWithType.Transition == "success" {
		status = 2
	} else if paramsWithType.Transition == "fail" || paramsWithType.Transition == "kill" {
		status = 3
	} else if paramsWithType.Transition == "run" {
		status = 1
	} else {
		return &response.Response{
			Status: 0,
			Data:   "transition ignored",
			Msg:    "ok",
		}
	}

	ret := resource.GetDB().Model(&mdb.AsyncTask{}).Where("id = ?", paramsWithType.ID).Update("status", status)
	if ret.Error != nil {
		return response.NewError(500, ret.Error)
	}
	resp := &response.Response{
		Status: 0,
		Data:   nil,
		Msg:    "ok",
	}
	return resp
}

func (d *AsyncTask) PostAfter(ctx context.Context, req ghttp.Request, id any, validData any) error {
	resource := restful.ResourceFromContext(ctx)
	dao := mdb.AsyncTask{}
	resource.GetDB().Model(&mdb.AsyncTask{}).Where("id = ?", id).First(&dao)
	task := buildTaskContent(&dao)
	task.SetCommand("cd sdata_async_task && sh run_savepoint.sh")
	if err := task.Send(ctx); err != nil {
		return err
	}
	return nil
}

func buildTaskContent(asyncTask *mdb.AsyncTask) *delivery.Ejob {
	// hostname := "http://yandong03-2020.bcc-bdbl.baidu.com:8556"
	content := map[string]any{
		"params":    asyncTask.TaskParams,
		"task_type": asyncTask.TaskType,
		"id":        asyncTask.ID,
	}
	hostname := "http://sdata.baidu-int.com"
	callbackURL := fmt.Sprintf("%s/api/manage/async_task/delivery_cb", hostname)
	// callbackURL := "http://yandong03-2020.bcc-bdbl.baidu.com:8556/api/manage/async_task/delivery_cb"
	callbackParams := map[string]any{
		"id": asyncTask.ID,
	}
	jobName := "sdata_async_task_" + asyncTask.TaskType
	jobID := fmt.Sprintf("%d", asyncTask.ID)

	return &delivery.Ejob{
		JobName:        jobName,
		JobID:          jobID,
		UserParams:     content,
		CallbackURL:    callbackURL,
		CallbackParams: callbackParams,
	}
}
