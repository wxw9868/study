set -x
###
 # @Author: yandong03 yandong03@baidu.com
 # @Date: 2024-08-05 11:32:45
 # @LastEditors: yandong03 yandong03@baidu.com
 # @LastEditTime: 2024-08-05 11:46:08
 # @FilePath: /data-platform/build_fe.sh
 # @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
### 
set -u
set -e

export APP_BASE_PATH=$(cd `dirname $0`; pwd)
export APP_TMP_PATH=${APP_BASE_PATH}/tmp
export NODE_RUNTIME_PATH=${APP_BASE_PATH}/node_runtime
mkdir -p ${APP_TMP_PATH}
mkdir -p ${NODE_RUNTIME_PATH}
wget -O ${APP_TMP_PATH}/output.tar.gz --no-check-certificate --header "IREPO-TOKEN:af49ad95-0321-43f3-b889-22acb9e2fd1f" "https://irepo.baidu-int.com/rest/prod/v3/baidu/third-party/nodejs/releases/20.10.0.1/files"
tar -zxvf ${APP_TMP_PATH}/output.tar.gz -C ${APP_TMP_PATH}
tar -zxvf ${APP_TMP_PATH}/output/build/nodejs.tar.gz -C ${NODE_RUNTIME_PATH}
export PATH=${NODE_RUNTIME_PATH}/bin:$PATH

cd fe
echo "which node: $(which node)"
echo "node: $(node -v)"
echo "which npm: $(which npm)"
echo "npm: v$(npm -v)"
npm install --registry http://registry.npm.baidu-int.com/
echo "npm install done!"
npm run build
echo "npm build done!"
rm -rf node_modules
echo "rm node_modules"
cd -
