# Hestia
热重启子模块配置所在目录。  
当前目前配置为 测试环境 使用。

详见 http://wiki.baidu.com/pages/viewpage.action?pageId=1370968292

当前应用 Server 所监听的端口详情配置在 [./conf/hestia.toml](./conf/hestia.toml) 文件

若使用热重启功能，需要将 baidu/gdp/hestia 部署在当前目录
