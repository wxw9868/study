curl http://yangxiaotong-dev.bcc-bdbl.baidu.com:8080/api/demo/demo -X POST -d '{"name": "test3"}'
curl http://yangxiaotong-dev.bcc-bdbl.baidu.com:8080/api/demo/demo/1 -X DELETE

curl http://yangxiaotong-dev.bcc-bdbl.baidu.com:8080/api/demo/demo/2 -X PATCH -d '{"content":{"a":1}}'

curl http://yangxiaotong-dev.bcc-bdbl.baidu.com:8080/api/demo/demo/3 -X PUT -d '{"content":{"a":1},"name":"PATCH"}'

curl http://yangxiaotong-dev.bcc-bdbl.baidu.com:8080/api/demo/demo -X POST -d '{}'


curl http://yangxiaotong-dev.bcc-bdbl.baidu.com:8080/api/demo/demo/3 -X PATCH -d '{"status":1}'