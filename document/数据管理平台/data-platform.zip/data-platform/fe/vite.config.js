import {fileURLToPath, URL} from 'node:url';
import {resolve} from 'path';
import {defineConfig} from 'vite';
import vue from '@vitejs/plugin-vue';
import vueDevTools from 'vite-plugin-vue-devtools';

// https://vitejs.dev/config/
export default defineConfig({
    plugins: [
        vue(),
        vueDevTools(),
    ],
    resolve: {
        alias: {
            '@': fileURLToPath(new URL('./src', import.meta.url))
        },
        extensions: ['.vue', '.js', '.ts', '.jsx', '.tsx', '.json']
    },
    server: {
        proxy: {
            '/api': {
                target: 'http://yandong03-2020.bcc-bdbl.baidu.com:8080',
                changeOrigin: true
            },
        },
    },
    build: {
        outDir: resolve(__dirname, 'dist'),
        cssCodeSplit: true,
        sourcemap: 'inline',
        rollupOptions: {
            input: {
                main: resolve(__dirname, 'index.html'),
                workbench: resolve(__dirname, 'workbench.html')
            }
        },
    }
});
