<template>
    <div>
        <iframe src="http://10.95.17.148:8233/"></iframe>
    </div>
</template>

<script>
export default {
    setup() {


        return {};
    }
};
</script>

<style lang="scss" scoped>

</style>