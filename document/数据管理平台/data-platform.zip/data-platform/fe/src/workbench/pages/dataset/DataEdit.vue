<template>
    <div>
        <el-container>
            <sidebar :items="sidebarItems" />
            <el-main
                class="sidebar-main"
                style="padding: 0;"
            >
                <el-row>
                    <breadcrumb :data="breadcrumbItems" />
                </el-row>
                <el-row v-loading="loading">
                    <div class="box-row">
                        <el-form
                            ref="jobForm"
                            :model="jobForm"
                            label-width="150"
                            style="width: 100%;"
                            :rules="rules"
                        >
                            <el-form-item
                                label="数据集名"
                                prop="name"
                                style="width: 100%;"
                            >
                                <el-input
                                    v-model="jobForm.name"
                                    :disabled="edit"
                                />
                            </el-form-item>
                            <el-form-item
                                label="数据集中文名"
                                prop="chname"
                            >
                                <el-input v-model="jobForm.chname" />
                            </el-form-item>
                            <el-form-item
                                label="数据分类"
                                prop="dataSource"
                            >
                                <el-input v-model="jobForm.dataSource" />
                            </el-form-item>
                            <el-form-item
                                label="数据集描述"
                                prop="description"
                            >
                                <el-input v-model="jobForm.description" />
                            </el-form-item>
                            <el-form-item
                                label="接口人"
                                prop="contactPerson"
                            >
                                <el-input v-model="jobForm.contactPerson" />
                            </el-form-item>
                            <el-form-item
                                label="数据Schema"
                                prop="dataSchema"
                                style="width: 800px;"
                            >
                                <data-scheme
                                    v-model="jobForm.dataSchema"
                                    class="data-scheme"
                                />
                            </el-form-item>
                            <el-form-item
                                label="是否包含表头"
                                prop="hasHeader"
                            >
                                <el-radio-group v-model="jobForm.hasHeader">
                                    <el-radio :label="1">
                                        是
                                    </el-radio>
                                    <el-radio :label="2">
                                        否
                                    </el-radio>
                                </el-radio-group>
                            </el-form-item>
                            <el-divider />
                            <el-form-item
                                label="数据存储类型"
                                prop="targetType"
                            >
                                <el-segmented
                                    v-model="jobForm.targetType"
                                    :options="targetTypeList"
                                >
                                    <template #default="{ item }">
                                        <div class="flex flex-col items-center gap-2 p-2">
                                            <div>{{ item.name }}</div>
                                        </div>
                                    </template>
                                </el-segmented>
                            </el-form-item>


                            <el-form-item
                                label="配置参数"
                                prop="targetParams"
                            >
                                <component
                                    :is="getTargetParamsComponent"
                                    v-model="jobForm.targetParams"
                                    parent-name="targetParams"
                                />
                            </el-form-item>
                            <el-divider />
                            <el-form-item>
                                <el-button
                                    type="primary"
                                    size="large"
                                    @click="submitForm"
                                >
                                    提交
                                </el-button>
                                <el-button
                                    v-if="edit"
                                    size="large"
                                    type="danger"
                                    @click="deleteJob"
                                >
                                    删除
                                </el-button>
                                <el-button
                                    size="large"
                                    @click="cancelForm"
                                >
                                    取消
                                </el-button>
                            </el-form-item>
                        </el-form>
                    </div>
                </el-row>
            </el-main>
        </el-container>
    </div>
</template>

<script>
import * as datasetApi from '../../../apis/dataset';
import Breadcrumb from '../../../pages/partial/Breadcrumb';
import Sidebar from '../../../pages/partial/SideBar';
import config from './config';
import _ from 'lodash';
import AfsParams from '../../../pages/dimension/components/AfsParams';
import ActivityAdaptorParams from '../../../pages/dimension/components/ActivityAdaptorParams';
import KuAdaptorParams from '../../../pages/dimension/components/KuAdaptorParams';
import TriggerScheduleParams from '../../../pages/dimension/components/TriggerScheduleParams';
import DataScheme from '../../../pages/dimension/components/DataScheme';
import AlarmParams from '../../../pages/dimension/components/AlarmParams';
import NoticeParams from '../../../pages/dimension/components/NoticeParams';
import AdaptorBlockParams from '../../../pages/dimension/components/AdaptorBlockParams';
import {ElMessage} from 'element-plus';

const emptyForm = {
    name: '',
    chname: '',
    dataSource: '',
    description: '',
    contactPerson: '',
    dataSchema: {},
    targetType: '',
    targetParams: {},
    dtype: 1,
    stype: 1,
    adaptor: '',
    adaptorParams: {},
    adaptorTriggerParams: {},
    triggerParams: {},
    alarmConfig: {},
    status: 0,
    hasHeader: 1,
};

export default {
    components: {
        Breadcrumb,
        Sidebar,
        AfsParams,
        ActivityAdaptorParams,
        KuAdaptorParams,
        TriggerScheduleParams,
        DataScheme,
        AlarmParams,
        NoticeParams,
        AdaptorBlockParams
    },
    beforeRouteEnter(to, from, next) {
        next(vm => {
            vm.init();
        });
    },
    data: function () {
        let meta = this.getMeta(this.$route);
        let sidebar = _.cloneDeep(config.sidebar);
        return {
            loading: false,
            timeoutSign: null,
            jobForm: _.cloneDeep(emptyForm),
            rules: {
                name: [{
                    required: true,
                    message: '请输入数据集名称'
                }, {
                    validator: this.nameValid,
                    trigger: 'blur'
                }],
                chname: [{
                    required: true,
                    message: '请输入中文名称'
                }],
                dataSource: [{
                    required: false,
                    message: '请输入数据分类'
                }],
                description: [{
                    required: false,
                    message: '请输入数据集描述'
                }],
                contactPerson: [{
                    required: false,
                    message: '请输入接口人'
                }],
                stype: [{
                    required: true,
                    message: '请选择源数据类型'
                }],
                targetType: {
                    required: true,
                    message: '请选择数据存储类型'
                },
                dtype: {
                    required: true,
                    message: '请选择数据类型'
                },
                targetParams: {
                    required: true,
                    message: '请填写配置参数'
                },
                dataSchema: [{
                    required: true,
                    message: '请输入数据schema'
                }, {
                    validator: this.jsonSchemaValid,
                    trigger: 'blur'
                }]
            },
            sidebarItems: sidebar,
            breadcrumbItems: meta.breadcrumb,
            edit: meta.edit,
            targetTypeList: config.targetTypeList,
            targetComponentMap: config.targetComponentMap,
            dataTypeList: config.dataTypeList,
            sourceTypeList: config.sourceTypeList,
            adaptorTypeList: config.adaptorTypeList,
            adaptorParamsMap: config.adaptorParamsMap,
            triggerTypeList: config.triggerTypeList,
        };
    },
    computed: {
        getTargetParamsComponent() {
            return this.targetComponentMap[this.jobForm.targetType];
        },
    },

    methods: {
        init() {
            this.loadData();
        },
        delayLoad() {
            if (this.timeoutSign != null) {
                clearTimeout(this.timeoutSign);
            }
            this.timeoutSign = setTimeout(() => {
                this.timeoutSign = null;
                this.loadTemplate();
            }, 300);
        },
        loadData() {
            if (this.$route.query.name) {
                this.loading = true;
                datasetApi.meta.get({
                    name: this.$route.query.name
                }).then(data => {
                    if (data.data.length === 0) {
                        ElMessage.error('任务不存在');
                        return;
                    }
                    this.jobForm = data.data[0];
                    this.jobForm.createTime = undefined;
                    this.jobForm.updateTime = undefined;
                    this.loading = false;
                });
            } else {
                return;
            }
        },

        getMeta(route) {
            let breadcrumb = _.cloneDeep(config.breadcrumb);
            let edit = !!route.query.name;
            return {
                breadcrumb,
                edit
            };
        },
        submitForm() {
            this.$refs.jobForm.validate(valid => {
                if (valid) {
                    if (this.jobForm.id != null) {
                        this.jobForm.version = undefined;
                        datasetApi.meta.patch(this.jobForm.id, this.jobForm).then(res => {
                            if (res.status === 0) {
                                this.$router.push('/workbench/dataset/list').catch(() => {});
                            }
                        });
                    } else {
                        datasetApi.meta.post(this.jobForm).then(res => {
                            if (res.status === 0) {
                                this.$router.push('/workbench/dataset/list').catch(() => {});
                            }
                        });
                    }
                } else {
                    ElMessage.error('表单验证失败');
                }
            });
        },
        cancelForm() {
            this.$router.push('/workbench/dataset/list').catch(() => {});
        },
        nameValid(rule, value, callback) {
            if (!/^[a-zA-Z0-9_.]*$/.test(value)) {
                callback(new Error('请输入合法字符：[a-zA-Z0-9_.]'));
                return;
            }
            callback();
        },
        jsonSchemaValid(rule, value, callback) {
            if (!value.properties || typeof value.properties !== 'object') {
                callback(new Error('schema非法'));
                return;
            }
            let valid = true;
            let msg = '';
            Object.keys(value.properties).forEach(propertyName => {
                const property = value.properties[propertyName];
                if (!property.title) {
                    msg = `属性"${propertyName}"没有 "title"属性，这个词会作为字段名，请设置`;
                    valid = false;
                }
            });
            if (value.order && value.order.length !== Object.keys(value.properties).length) {
                callback(new Error('order长度必须等于properties的长度'));
                return;
            }
            if (!valid) {
                callback(new Error(msg));
                return;
            }
            callback();
        },
        deleteJob() {
            let name = this.$route.query.name;
            this.$confirm(`确认删除${name}么？`, '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'error'
            }).then(() => {
                datasetApi.meta.delete({
                    pdb: this.$route.query.pdb,
                    name: name
                }).then(res => {
                    if (res.status === 0) {
                        this.$router.push('/workbench/dataset/list').catch(() => {});
                    }
                });
            });
        },
    }
};
</script>

<style scoped>
.el-alert {
  padding: 0;
}

.data-scheme {
  width: 100%;
  height: 300px;
  overflow-y: scroll;
}
</style>
