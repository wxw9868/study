export default {
    sidebar: [{
        name: '数据列表',
        index: '/workbench/dataset/list',
        icon: 'el-icon-s-cooperation'
    }],
    breadcrumb: [{
        path: '/workbench/dataset/list',
        title: '数据集'
    }],
    targetTypeList: [
        {
            name: 'AFS',
            value: 'afs',
        }
    ],
    targetComponentMap: {
        afs: 'AfsParams'
    }
};