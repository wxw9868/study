<template>
    <div>
        <el-container style="height: 100vh;">
            <!-- 左侧侧边栏 -->
            <el-aside
                class="resize-aside"
                :style="{ width: asideWidth + 'px', padding: '15px 10px' }"
                @mousedown="startResize"
            >
                <!-- 检索框 -->
                <el-form
                    :model="filterForm"
                    inline
                    style="margin-bottom: 10px;"
                >
                    <el-form-item>
                        <el-input
                            v-model="filterForm.word"
                            placeholder="输入函数名称进行模糊查询"
                            style="width: 100%;"
                            @input="delayLoad"
                        />
                    </el-form-item>
                </el-form>
                <!-- 函数列表 -->
                <el-scrollbar style="height: calc(100vh - 120px);">
                    <el-menu
                        :default-active="activeFunctionId"
                        class="function-list-menu"
                        @select="handleRowClick"
                    >
                        <el-menu-item
                            :key="item.id"
                            v-for="(item, index) in tableData"
                            :index="item.id.toString()"
                            :title="item.funcDesc"
                            :class="{ 'menu-item-alt': index % 2 === 0 }"
                        >
                            <span class="menu-item-text">{{ item.funcName }}</span>
                        </el-menu-item>
                    </el-menu>
                </el-scrollbar>
                <el-pagination
                    v-model:current-page="page"
                    v-model:page-size="size"
                    :total="total"
                    layout="prev, pager, next"
                    background
                    style="margin-top: 10px;"
                    @current-change="loadData"
                    @size-change="loadData"
                />
            </el-aside>
            <!-- 右侧展示区域 -->
            <el-main style="padding: 20px;">
                <div v-if="metaInfo">
                    <div class="meta-info">
                        <div class="meta-header">
                            <h2>{{ metaInfo.funcName }}</h2>
                            <h3>函数描述：{{ metaInfo.description }}</h3>
                        </div>
                        <el-row
                            class="meta-footer"
                            gutter="{20}"
                        >
                            <el-col :span="8">
                                <span>最近修改时间：{{ metaInfo.lastModifiedTime }}</span>
                            </el-col>
                            <el-col :span="8">
                                <span>最近修改人：{{ metaInfo.lastModifiedBy }}</span>
                            </el-col>
                            <el-col :span="8">
                                <span>创建人：{{ metaInfo.createdBy }}</span>
                            </el-col>
                        </el-row>
                    </div>
                    <el-tabs
                        v-model="activeTab"
                        type="border-card"
                    >
                        <el-tab-pane
                            label="示例代码"
                            name="exampleCode"
                        >
                            <div class="example-code">
                                <pre>{{ exampleCode }}</pre>
                            </div>
                        </el-tab-pane>
                    </el-tabs>
                </div>
            </el-main>
        </el-container>
    </div>
</template>

<script>
import * as functionApi from '@/apis/function';
import {dayjs} from 'element-plus';

export default {
    data() {
        return {
            loading: true,
            tableData: [],
            filterForm: {
                word: '',
            },
            page: 1,
            size: 10,
            total: 0,
            metaInfo: null,
            exampleCode: '',
            activeTab: 'exampleCode',
            timeoutSign: null,
            activeFunctionId: null,
            asideWidth: 300,
            resizing: false,
        };
    },
    mounted() {
        this.loadData();
        document.addEventListener('mousemove', this.resize);
        document.addEventListener('mouseup', this.stopResize);
    },
    beforeUnmount() {
        document.removeEventListener('mousemove', this.resize);
        document.removeEventListener('mouseup', this.stopResize);
    },
    methods: {
        loadData() {
            this.loading = true;
            const query = {
                funcSetName: this.$route.query.funcSetName,
                funcName: this.filterForm.word,
                page: this.page,
                size: this.size,
            };

            functionApi.meta.functionData(query).then((res) => {
                if (res.status === 0) {
                    this.tableData = res.data;
                    this.total = res.total;
                    if (res.data.length > 0 && !this.activeFunctionId) {
                        // 默认展示第一个函数信息
                        this.handleRowClick(res.data[0].id.toString());
                    }
                }
                this.loading = false;
            });
        },
        delayLoad() {
            if (this.timeoutSign != null) {
                clearTimeout(this.timeoutSign);
            }
            this.timeoutSign = setTimeout(() => {
                this.timeoutSign = null;
                this.page = 1;
                this.loadData();
            }, 300);
        },
        handleRowClick(id) {
            const selectedFunction = this.tableData.find(
                (item) => item.id.toString() === id
            );
            if (selectedFunction) {
                const query = {id: selectedFunction.id};
                functionApi.meta.functionData(query).then((res) => {
                    if (res.status === 0) {
                        const data = res.data;
                        this.metaInfo = {
                            funcName: data.funcName,
                            description: data.funcDesc,
                            lastModifiedTime: dayjs(data.updateTime).format('YYYY-MM-DD HH:mm:ss'),
                            lastModifiedBy: data.modifier,
                            createdBy: data.creator,
                        };
                        this.exampleCode = data.example || '暂无示例代码';
                        this.activeFunctionId = id;
                    }
                });
            }
        },
        startResize(event) {
            this.resizing = true;
            this.startX = event.clientX;
            this.startWidth = this.asideWidth;
        },
        resize(event) {
            if (this.resizing) {
                const delta = event.clientX - this.startX;
                this.asideWidth = Math.min(
                    Math.max(this.startWidth + delta, 200),
                    500
                );
            }
        },
        stopResize() {
            this.resizing = false;
        },
    },
};
</script>

<style scoped>
.meta-info {
  margin-bottom: 20px;
  padding: 20px;
  border: 1px solid #ddd;
  border-radius: 8px;
  background-color: #f9f9f9;
}

.meta-header {
  margin-bottom: 10px;
}

.example-code {
  background: #f5f5f5;
  padding: 10px;
  border-radius: 4px;
}

.meta-footer {
  display: flex;
  justify-content: space-between;
  margin-top: 10px;
}

.meta-footer span {
  display: block;
  font-size: 14px;
  color: #666;
}

.function-list-menu {
  background-color: transparent;
  border: none;
}

.el-menu-item {
  padding-left: 10px !important;
}

.el-menu-item.menu-item-alt {
  background-color: #f9f9f9;
}

.el-menu-item:hover {
  background-color: #e6f7ff;
  cursor: pointer;
}

.resize-aside {
  position: relative;
  border-right: 1px solid #e4e7ed;
  overflow: hidden;
}

.resize-aside::after {
  content: '';
  position: absolute;
  right: 0;
  width: 5px;
  height: 100%;
  cursor: ew-resize;
}
</style>
