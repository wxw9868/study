<template>
    <div>
        <div class="meta-info">
            <div class="meta-header">
                <h2 class="meta-description">
                    {{ metaInfo.description }}
                </h2>
                <h3 class="meta-contact">
                    接口人：{{ metaInfo.contactPerson }}
                </h3>
            </div>
            <div class="meta-footer">
                <span>最近修改时间：{{ metaInfo.lastModifiedTime }}</span>
                <span>最近修改人：{{ metaInfo.lastModifiedBy }}</span>
                <span>数据分类：{{ metaInfo.dataSource }}</span>
            </div>
        </div>

        <el-tabs
            v-model="activeTab"
            type="border-card"
            class="structure-tabs"
        >
            <!-- 字段信息 Tab -->
            <el-tab-pane name="fieldInfo">
                <template #label>
                    <span class="custom-tabs-label">
                        <el-icon><calendar /></el-icon>
                        <span>字段信息</span>
                    </span>
                </template>
                <el-table
                    :data="schemaRowTable"
                    height="500"
                    style="width: 100%"
                >
                    <el-table-column
                        prop="column"
                        label="数据表字段名"
                        width="180"
                    />
                    <el-table-column
                        prop="type"
                        label="字段类型"
                    />
                    <el-table-column
                        prop="desc"
                        label="字段描述"
                        width="180"
                    />
                </el-table>
            </el-tab-pane>
            <!-- 数据预览 Tab -->
            <el-tab-pane name="dataPreview">
                <template #label>
                    <span class="custom-tabs-label">
                        <el-icon><calendar /></el-icon>
                        <span>数据预览</span>
                    </span>
                </template>
                <el-table
                    :data="tableData"
                    style="width: 100%"
                >
                    <el-table-column
                        v-for="(header, index) in headers"
                        :key="index"
                        :label="header"
                        :prop="String(index)"
                    >
                        <template #default="scope">
                            {{ scope.row[index] }}
                        </template>
                    </el-table-column>
                </el-table>
            </el-tab-pane>
        </el-tabs>
    </div>
</template>

<script>
import {ElMessage} from 'element-plus';
import * as datasetApi from '@/apis/dataset';
import _ from 'lodash';
import config from '@/workbench/pages/dataset/config';

const emptyForm = {
    name: '',
    chname: '',
    dataSource: '',
    description: '',
    contactPerson: '',
    dataSchema: {},
    targetType: '',
    targetParams: {},
    dtype: 1,
    stype: 1,
    adaptor: '',
    adaptorParams: {},
    adaptorTriggerParams: {},
    triggerType: '',
    triggerParams: {},
    alarmConfig: {},
    status: 0,
    headers: [],
    tableData: [],
};

export default {
    beforeRouteEnter(to, from, next) {
        next(vm => {
            vm.init();
        });
    },
    data() {
        return {
            activeTab: 'fieldInfo',
            jobForm: _.cloneDeep(emptyForm),
            schemaRowTable: [],
            metaInfo: {
                description: '此数据集用于支持用户体验产品功能，数据已脱敏。',
                contactPerson: 'liuxinyi02',
                lastModifiedTime: '2024-11-13 21:06:36',
                lastModifiedBy: 'liuxinyi02',
                dataSource: 'tda_ubi_ecommerce_clickhouse',
            },

        };
    },
    methods: {
        init() {
            this.loadData();
        },
        delayLoad() {
            if (this.timeoutSign != null) {
                clearTimeout(this.timeoutSign);
            }
            this.timeoutSign = setTimeout(() => {
                this.timeoutSign = null;
                this.loadTemplate();
            }, 300);
        },
        loadData() {
            if (this.$route.query.name) {
                this.loading = true;
                datasetApi.meta.get({
                    name: this.$route.query.name
                }).then(data => {
                    if (data.data.length === 0) {
                        ElMessage.error('任务不存在');
                        return;
                    }
                    this.jobForm = data.data[0];
                    this.loading = false;
                    this.parseSchemaData(this.jobForm.dataSchema);
                    this.dataPreview(this.jobForm);
                    this.metaInfo.description = this.jobForm.description;
                    this.metaInfo.contactPerson = this.jobForm.contactPerson;
                    this.metaInfo.lastModifiedTime = this.formatTimestamp(this.jobForm.updateTime);
                    this.metaInfo.lastModifiedBy = this.jobForm.modifier;
                    this.metaInfo.dataSource = this.jobForm.dataSource;
                });
            } else {
                return;
            }
        },
        formatTimestamp(timestamp) {
            const date = new Date(timestamp * 1000);
            return date.toLocaleDateString();
        },
        parseSchemaData(dataSchema) {
            if (dataSchema && dataSchema.properties) {
                const properties = dataSchema.properties;
                this.schemaRowTable = Object.keys(properties).map((key) => {
                    const field = properties[key];
                    return {
                        column: field.title || key,
                        type: field.type || '',
                        desc: field.desc || '',
                    };
                });
            } else {
                ElMessage.warning('dataSchema 格式无效或为空');
                this.schemaRowTable = [];
            }
        },
        dataPreview(row) {
            this.dialogPreviewVisible = true;
            let data = [];
            try {
                data = JSON.parse(row.previewData);
            } catch (error) {
                this.headers = [];
                this.tableData = [];
                return;
            }

            if (Array.isArray(data) && data.length > 0) {
                if (data.hasHeader !== 1) {
                    try {
                        const schemaOrder = row.dataSchema.order;
                        if (Array.isArray(schemaOrder)) {
                            this.headers = schemaOrder;
                        } else {
                            this.headers = [];
                        }
                    } catch (error) {
                        this.headers = [];
                    }
                    this.tableData = [data[0], ...data.slice(1)];
                } else {
                    this.headers = data[0];
                    this.tableData = data.slice(1);
                }
            } else {
                this.headers = [];
                this.tableData = [];
            }
        },
        getMeta(route) {
            let breadcrumb = _.cloneDeep(config.breadcrumb);
            return {
                breadcrumb
            };
        },
    }
};
</script>

<style scoped>
/* 元信息区域样式 */
.meta-info {
  margin-bottom: 20px;
  padding: 20px;
  border: 1px solid #ddd;
  border-radius: 8px;
  background-color: #f9f9f9;
}

.meta-header {
  margin-bottom: 10px;
}

.meta-description {
  font-size: 18px;
  font-weight: bold;
  margin: 0;
}

.meta-contact {
  font-size: 16px;
  margin: 5px 0 0;
  color: #333;
}

.meta-footer {
  display: flex;
  justify-content: space-between;
  font-size: 12px;
  color: #999;
}
</style>
