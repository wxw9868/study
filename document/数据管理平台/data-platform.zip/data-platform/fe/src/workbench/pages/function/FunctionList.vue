<template>
    <div>
        <el-container>
            <sidebar :items="sidebarItems" />
            <el-main
                class="sidebar-main"
                style="padding: 0;"
            >
                <el-row>
                    <breadcrumb :data="breadcrumbItems" />
                </el-row>
                <el-row class="filter-row">
                    <el-form
                        :inline="true"
                        :model="filterForm"
                    >
                        <el-form-item label="查询">
                            <el-input
                                v-model="filterForm.word"
                                style="width: 300px;"
                                placeholder="请输入函数集名称进行模糊检索"
                                @input="delayLoad"
                            />
                        </el-form-item>
                    </el-form>
                </el-row>
                <el-row
                    :gutter="20"
                    style="margin-top: 20px;"
                >
                    <el-col
                        :key="index"
                        v-for="(item, index) in tableData"
                        :span="6"
                    >
                        <el-card
                            shadow="always"
                            style="cursor: pointer;"
                            @click="FunctionData(item)"
                        >
                            <div>
                                <div style="font-size: 16px; font-weight: bold;">
                                    {{ item.funcSetName }}
                                </div>
                                <div style="margin: 10px 0; color: #666;">
                                    {{ item.funcSetDesc }}
                                </div>
                            </div>
                        </el-card>
                    </el-col>
                </el-row>

                <!-- 包裹翻页组件的容器 -->
                <div class="pagination-container">
                    <el-pagination
                        v-model:current-page="page"
                        v-model:page-size="size"
                        :page-sizes="[10, 20, 50, 100]"
                        :total="total"
                        background
                        layout="sizes, prev, pager, next"
                        @size-change="loadData"
                        @current-change="loadData"
                    />
                </div>
            </el-main>
        </el-container>
    </div>
</template>

<script>
import Breadcrumb from '../../../pages/partial/Breadcrumb';
import Sidebar from '../../../pages/partial/SideBar';
import config from './config';
import * as functionApi from '../../../apis/function';
import _ from 'lodash';

export default {
    components: {
        Breadcrumb,
        Sidebar,
    },
    beforeRouteEnter(to, from, next) {
        next(vm => {
            vm.init();
        });
    },
    data: function () {
        let sidebar = _.cloneDeep(config.sidebar);
        return {
            timeoutSign: null,
            loading: true,
            jobData: [],
            filterForm: {
                word: ''
            },
            onlyUser: '',
            sidebarItems: sidebar,
            breadcrumbItems: [],
            page: 1,
            size: 10,
            total: 10,
            echo: 0,
            tableData: [],
        };
    },
    methods: {
        init() {
            let meta = this.getMeta(this.$route);
            this.page = 1;
            this.breadcrumbItems = meta.breadcrumb;
            this.loadData();
        },
        loadData() {
            this.loading = true;
            this.echo++;

            let query = {
                pdb: this.$route.query.pdb,
                funcSetName: this.filterForm.word,
                page: this.page,
                size: this.size,
                echo: this.echo
            };

            if (this.onlyUser) {
                query.owner = this.user.username;
            }

            let pendingRequests = 2;

            functionApi.meta.get(query).then(res => {
                if (res.status === 0 && res.echo === this.echo) {
                    this.jobData = res.data;
                    this.total = res.total;
                }
                if (--pendingRequests === 0) {
                    this.loading = false;
                }
            });

            functionApi.meta.functionSetData(query).then(res => {
                if (res.status === 0) {
                    this.tableData = res.data;
                }
                if (--pendingRequests === 0) {
                    this.loading = false;
                }
            });
        },
        delayLoad() {
            if (this.timeoutSign != null) {
                clearTimeout(this.timeoutSign);
            }
            this.timeoutSign = setTimeout(() => {
                this.timeoutSign = null;
                this.page = 1;
                this.loadData();
            }, 300);
        },
        FunctionData(props) {
            this.$router.push({
                path: '/workbench/function/data',
                query: {
                    funcSetName: props.funcSetName,
                }
            }).catch(() => {
            });
        },
        getMeta(route) {
            let breadcrumb = _.cloneDeep(config.breadcrumb);
            breadcrumb.push({
                path: '/workbench/function/list',
                title: '函数集管理'
            });
            return {
                breadcrumb
            };
        }
    }
};
</script>

<style lang="scss" scoped>
.filter-row {
  margin-bottom: 20px;
}

.pagination-container {
  margin-top: 20px;
}
</style>