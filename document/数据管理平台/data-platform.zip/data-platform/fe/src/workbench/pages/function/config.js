export default {
    sidebar: [{
        name: '函数列表',
        index: '/workbench/function/list',
        icon: 'el-icon-s-cooperation'
    }],
    breadcrumb: [{
        path: '/workbench/function/list',
        title: '函数集'
    }],
};