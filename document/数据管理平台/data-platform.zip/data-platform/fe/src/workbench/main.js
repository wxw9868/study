// import './assets/main.css'

import {createApp} from 'vue';
import {createPinia} from 'pinia';
import ElementPlus from 'element-plus';
import 'element-plus/dist/index.css';
import * as ElementPlusIconsVue from '@element-plus/icons-vue';
import {currentUser} from '../apis/users';
import {useUserStore} from '../stores/user';

import Header from '../pages/partial/WorkbenchHeader.vue';

import App from './App.vue';
import router from './router';

const app = createApp(App);


for (const [key, component] of Object.entries(ElementPlusIconsVue)) {
    app.component(key, component);
}

app.use(createPinia());
app.use(router);
app.use(ElementPlus);
app.component('MainHeader', Header);
const user = useUserStore();

currentUser.get({}, false).then(resp => {
    user.$patch(resp.data);
    if (resp.status === 0 && resp.data.isLogin === true) {
        app.mount('#app');
    } else if (resp.status === 0) {
        let url = window.location.href;
        window.location.href = '/api/users/login?url=' + encodeURIComponent(url);
    } else {
        alert('获取用户失败，请刷新重试 或 联系平台管理员：[' + resp.status + ']' + resp.message);
    }
}).catch(err => {
    console.log(err);
    alert('获取用户失败，请刷新重试 或 联系平台管理员');
});

