/*
 * @Author: yandong03 yandong03@baidu.com
 * @Date: 2024-07-18 11:04:08
 * @LastEditors: yandong03 yandong03@baidu.com
 * @LastEditTime: 2024-07-18 11:04:08
 * @FilePath: /fe/src/router/index.js
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
import {createRouter, createWebHistory} from 'vue-router';
import DataList from '../pages/dataset/DataList';
import FunctionList from '../pages/function/FunctionList';
import JupyterLab from '../pages/jupyter/JupyterLab';
import DataEdit from '../pages/dataset/DataEdit';
import DataInfo from '../pages/dataset/DataInfo';
import FunctionData from '../pages/function/FunctionData';

const router = createRouter({
    history: createWebHistory(import.meta.env.BASE_URL),
    routes: [
        {
            path: '/workbench',
            redirect: '/workbench/dataset/list' // 添加重定向规则
        },
        {
            path: '/workbench/dataset/list',
            name: 'dataList',
            component: DataList
        },
        {
            path: '/workbench/dataset/edit',
            name: 'DataEdit',
            component: DataEdit
        },
        {
            path: '/workbench/dataset/info',
            name: 'DatasetInfo',
            component: DataInfo
        },
        {
            path: '/workbench/function/list',
            name: 'functionList',
            component: FunctionList
        },
        {
            path: '/workbench/function/data',
            name: 'functionData',
            component: FunctionData
        },
        {
            path: '/workbench/jupyter/jupyterlab',
            name: 'jupyterlab',
            component: JupyterLab
        },
    ]
});

export default router;
