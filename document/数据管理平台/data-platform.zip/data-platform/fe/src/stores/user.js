import {defineStore} from 'pinia';

export const useUserStore = defineStore('user', {
    state: () => ({
        userName: '',
        name: '',
        isLogin: false,
        valid: false
    }),
    actions: {
    }
});
