<template>
    <el-aside width="180px">
        <el-menu
            :default-active="activePath"
            style="height: 100%;"
            :router="true"
        >
            <el-menu-item
                v-for="(item, index) in items"
                :key="index"
                :index="item.index"
            >
                <i
                    v-if="item.icon !== false"
                    :class="item.icon"
                ></i>{{ item.name }}
            </el-menu-item>
        </el-menu>
    </el-aside>
</template>

<script>

export default {
    props: {
        items: {
            type: Array,
            default: () => []
        }
    },
    data() {
        return {
            activeIndex: ''
        };
    },
    computed: {
        activePath() {
            let path = this.$route.path;
            if (path === '/') {
                return '/dimension/list';
            }
            return path;
        }
    },
    created() {
    },
    methods: {}
};
</script>
