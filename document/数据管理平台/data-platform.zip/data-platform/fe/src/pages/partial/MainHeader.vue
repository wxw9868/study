<template>
    <div class="el-menu--dark header-container">
        <div class="header-logo">
            <router-link
                to="/"
                class="header-title"
            >
                数据管理平台
            </router-link>
        </div>
        <el-menu
            :default-active="activePath"
            mode="horizontal"
            class="header-menu"
            :router="true"
            :ellipsis="false"
            background-color="#545c64"
            text-color="#fff"
            active-text-color="#ffd04b"
        >
            <el-sub-menu index="/dimension/list">
                <template #title>
                    维表管理
                </template>
                <el-menu-item
                    v-for="item in sidebar"
                    :key="item.name"
                    :index="item.index"
                >
                    {{ item.name }}
                </el-menu-item>
            </el-sub-menu>
            <el-sub-menu index="/dqc/list">
                <template #title>
                    DQC管理
                </template>
                <el-menu-item
                    v-for="item in dqcSidebar"
                    :key="item.name"
                    :index="item.index"
                >
                    {{ item.name }}
                </el-menu-item>
            </el-sub-menu>
            <el-sub-menu index="/science/abtest">
                <template #title>
                    数据科学
                </template>
                <el-menu-item
                    v-for="item in scienceSidebar"
                    :key="item.name"
                    :index="item.index"
                >
                    {{ item.name }}
                </el-menu-item>
            </el-sub-menu>
            <el-sub-menu index="/package/select">
                <template #title>
                    用户特征
                </template>
                <el-menu-item
                    v-for="item in featureConfigSidebar"
                    :key="item.name"
                    :index="item.index"
                >
                    {{ item.name }}
                </el-menu-item>
            </el-sub-menu>
            <el-sub-menu index="/manage/robotlist">
                <template #title>
                    基础管理
                </template>
                <el-menu-item
                    v-for="item in manageSidebar"
                    :key="item.name"
                    :index="item.index"
                >
                    {{ item.name }}
                </el-menu-item>
            </el-sub-menu>
            <el-sub-menu
                index="/manual"
                @click="openManual"
            >
                <template #title>
                    使用手册
                </template>
                <el-menu-item
                    index="/manual/dimension"
                    @click="openDimensionManual"
                >
                    维表管理
                </el-menu-item>
                <el-menu-item
                    index="/manual/dqc"
                    @click="openDqcManual"
                >
                    DQC管理
                </el-menu-item>
                <el-menu-item
                    index="/manual/science"
                    @click="openScienceTaskManual"
                >
                    数据科学
                </el-menu-item>
            </el-sub-menu>
        </el-menu>
        <div class="header-user">
            <!-- hi {{ user.userName }} -->
            <!-- <div class="user-pdb">
                产品线：default
            </div> -->
            <el-dropdown class="user-name">
                <span class="user-link">
                    hi, {{ user.userName }}
                    <el-icon class="el-icon--right">
                        <arrow-down />
                    </el-icon>
                </span>
                <!-- <span class="user-link">
                    hi, {{ user.userName }}
                </span> -->
                <template #dropdown>
                    <el-dropdown-menu>
                        <el-dropdown-item class="dropdown-item">
                            <div>
                                <router-link to="/dqc/rule_list">
                                    规则管理
                                </router-link>
                            </div>
                        </el-dropdown-item>
                        <el-dropdown-item
                            class="dropdown-item"
                        >
                            <div @click="logout">
                                注销
                            </div>
                        </el-dropdown-item>
                    </el-dropdown-menu>
                </template>
            </el-dropdown>
        </div>
    </div>
</template>

<script>
import config from '../dimension/config';
import manageConfig from '../manage/config';
import dqcConfig from '../dqc/config';
import scienceConfig from '../science/config';
import featureConfig from '../feature/config';
import {useUserStore} from '../../stores/user';
import {computed} from 'vue';
import {useRouter} from 'vue-router';

export default {
    setup() {
        let router = useRouter();
        const user = useUserStore();
        const activePath = computed(() => {
            let path = router.currentRoute.value.path;
            if (path.indexOf('/dimension') > -1) {
                return '/dimension/list';
            }
            if (path === '/') {
                return '/dimension/list';
            }
            return path;
        });
        return {
            activePath,
            user
        };
    },
    data() {
        return {
            sidebar: config.sidebar,
            manageSidebar: manageConfig.sidebar,
            dqcSidebar: dqcConfig.sidebar,
            scienceSidebar: scienceConfig.sidebar,
            featureConfigSidebar: featureConfig.sidebar,
        };
    },
    computed: {
    },
    methods: {
        logout() {
            window.location = '/logout';
            console.log('logout');
        },
        openManual() {
            window.open('https://ku.baidu-int.com/knowledge/HFVrC7hq1Q/aX31HWgyN_/50McHA1Giz/9g3krgmI0TutZt');
        },
        openDimensionManual() {
            window.open('https://ku.baidu-int.com/knowledge/HFVrC7hq1Q/aX31HWgyN_/50McHA1Giz/ycY37OVcIoT0jb');
        },
        openDqcManual() {
            window.open('https://ku.baidu-int.com/knowledge/HFVrC7hq1Q/aX31HWgyN_/50McHA1Giz/6_R9oCHtUdOGxE');
        },
        openScienceTaskManual() {
            window.open('https://ku.baidu-int.com/knowledge/HFVrC7hq1Q/aX31HWgyN_/50McHA1Giz/qJb3yrKPdfzXE-');
        }
    }
};
</script>

<style lang="less" scoped>
header {
    position: fixed;
}

.header-container {
    height: 60px;
    left: 0;
    top: 0;
    width: 100%;
    line-height: 60px;
    background-color: #545c64;
}

.header-logo {
    width: 240px;
    float: left;
}

.header-title {
    color: #fff;
    text-shadow: none;
    display: block;
    height: 60px;
    line-height: 60px;
    text-decoration: none;
    font-size: 20px;
    text-align: center;
}

.header-menu {
    float: left;
}

.header-user {
    float: right;
    position: relative;
    left: 0;
    padding: 0 20px;

    .user-pdb {
        color: #c0ccda;
        float: left;
        margin-right: 20px;
        font-size: 14px;
    }

    .user-name {
        float: left;
        height: 60px;
        align-items: center;
        color: #c0ccda;
        font-size: 14px;
    }
}

.header-pdb {
    float: right;
}

.user-link {
    cursor: pointer;
    color: #c0ccda;
}

.dropdown-item {
    font-size: 14px;
    line-height: 30px;

    a {
        color: inherit;
    }
}
</style>