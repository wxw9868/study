<template>
    <el-row>
        <el-col class="breadcrumb-line">
            <el-breadcrumb
                separator="/"
                class="breadcrumb-line"
            >
                <el-breadcrumb-item to="/">
                    首页
                </el-breadcrumb-item>
                <el-breadcrumb-item
                    v-for="(item, index) in data"
                    :key="index"
                    :to="item.path"
                >
                    {{ item.title }}
                </el-breadcrumb-item>
            </el-breadcrumb>
        </el-col>
    </el-row>
</template>

<script>
export default {
    props: {
        data: {
            type: Array,
            default: () => []
        }
    }
};
</script>

<style scoped lang="less">
.breadcrumb-line {
    padding: 10px 0;
}
</style>
