<template>
    <div>
        <div
            v-for="(item, index) in formData.data"
            :key="index"
            class="flex-container"
        >
            <div>
                <el-select
                    v-model="item.op1"
                    placeholder="选择操作符"
                    style="width: 150px;"
                    clearable
                    @change="updateParent"
                >
                    <el-option
                        v-for="op in operators"
                        :key="op"
                        :label="op"
                        :value="op"
                    />
                </el-select>
            </div>

            <div>
                <el-input
                    v-model="item.num1"
                    placeholder="不要加引号"
                    @change="updateParent"
                    @input="updateParent"
                />
            </div>

            <div>
                <el-select
                    v-model="item.op2"
                    placeholder="选择操作符"
                    style="width: 150px;"
                    clearable
                    @change="updateParent"
                >
                    <el-option
                        v-for="op in operators"
                        :key="op"
                        :label="op"
                        :value="op"
                    />
                </el-select>
            </div>

            <div>
                <el-input
                    v-model="item.num2"
                    placeholder="不要加引号"
                    @change="updateParent"
                    @input="updateParent"
                />
            </div>
            <div>
                <el-button
                    v-if="formData.data.length > 1"
                    type="danger"
                    @click="deleteOne(index)"
                >
                    删除
                </el-button>
            </div>
            <div>
                <el-button
                    v-if="index === formData.data.length -1 "
                    @click="addOne"
                >
                    添加
                </el-button>
            </div>
        </div>
    </div>
</template>

<script>
import {defineComponent, watch, ref} from 'vue';

export default defineComponent({
    name: 'StringRule',
    components: {
    },

    props: {
        modelValue: {
            type: Object,
            required: true,
        },
        fieldType: {
            type: String,
            required: true,
            default: 'string',
        },
        fieldName: {
            type: String,
            required: true,
        }
    },
    emits: ['update:modelValue'],
    setup(props, {emit}) {
        const formData = ref({...props.modelValue});
        const addOne = () => {
            formData.value.data.push({
                op1: '',
                num1: '',
                op2: '',
                num2: '',
            });
        };
        const deleteOne = (index) => {
            formData.value.data.splice(index, 1);
        };
        if (formData.value.data === undefined || formData.value.data.length <= 0) {
            formData.value.data = [];
            addOne();
        }
        const genRule = function () {
            let rules = [];
            formData.value.data.forEach((item) => {
                let curRule = [];
                if (item.op1 && item.num1) {
                    curRule.push(`${props.fieldName} ${item.op1} '${item.num1}'`);
                }
                if (item.op2 && item.num2) {
                    curRule.push(`${props.fieldName} ${item.op2} '${item.num2}'`);
                }
                if (curRule.length > 0) {
                    rules.push(`(${curRule.join(' and ')})`);
                }
            });
            return rules.join(' or ');
        };

        const operators = ['=', 'like', '!=', 'not like'];

        watch(
            () => props.modelValue,
            (newVal) => {
                formData.value = {...newVal};
            }
        );

        const updateParent = () => {
            formData.value.rule = genRule();
            emit('update:modelValue', formData.value);
        };

        return {
            formData,
            operators,
            addOne,
            deleteOne,
            updateParent,
        };
    },
    data() {
        return {
        };
    },
});
</script>

  <style scoped>
  /* Add your styles here */
  .flex-container {
        display: flex;
        flex-wrap: wrap;
        flex-direction: row;
        margin-bottom: 10px;
    }
  </style>