<template>
    <div>
        <el-form-item
            label="地址"
            label-width="100"
            :prop="`${parentName}.path`"

            :rules="[{required: true, message: '请输入Path', trigger: 'change'}]"
        >
            <el-input
                v-model="formData.path"
                @input="updateParent"
            />
        </el-form-item>
        <el-form-item
            label="UGI"
            label-width="100"
            :prop="`${parentName}.ugi`"
            :rules="[{required: true, message: '请输入ugi', trigger: 'change'}]"
        >
            <el-input
                v-model="formData.ugi"
                @input="updateParent"
            />
        </el-form-item>
    </div>
</template>

<script>
import {defineComponent, watch, ref} from 'vue';

export default defineComponent({
    name: 'AfsParams',
    components: {
    },

    props: {
        modelValue: {
            type: Object,
            required: true,
        },
        parentName: {
            type: String,
            required: true,
        }
    },
    emits: ['update:modelValue'],
    setup(props, {emit}) {
        const formData = ref({...props.modelValue});

        watch(
            () => props.modelValue,
            (newVal) => {
                formData.value = {...newVal};
            }
        );

        const updateParent = () => {
            emit('update:modelValue', formData.value);
        };

        return {
            formData,
            updateParent,
        };
    },
    data() {
        return {
        };
    },
});
</script>

  <style scoped>
  /* Add your styles here */
  </style>