<template>
    <div>
        <div>
            <el-button
                type="success"
                @click="addColumn"
            >
                添加列
            </el-button>
            <el-button
                type="warning"
                @click="addBySql"
            >
                通过建表语句导入
            </el-button>
        </div>
        <el-table
            :data="formData.schemaList"
            style="width: 100%"
        >
            <el-table-column
                label="列"
                prop="column"
                width="150"
            />
            <el-table-column
                label="列名（用于展示）"
                prop="name"
                width="180"
            />
            <el-table-column
                label="类型"
                width="120"
            >
                <template #default="scope">
                    <el-tag :type="TypeElTagTypeMap[scope.row.type]">
                        {{ scope.row.type }}
                    </el-tag>
                </template>
            </el-table-column>
            <el-table-column
                label="是否隐藏"
            >
                <template #default="scope">
                    <el-switch
                        v-model="scope.row.isHidden"
                        :disabled="true"
                    />
                </template>
            </el-table-column>
            <el-table-column
                label="是否派生"
            >
                <template #default="scope">
                    <el-switch
                        v-model="scope.row.isExtend"
                        :disabled="true"
                    />
                </template>
            </el-table-column>
            <el-table-column
                label="是否可枚举"
            >
                <template #default="scope">
                    <el-switch
                        v-model="scope.row.isEnum"
                        :disabled="true"
                    />
                </template>
            </el-table-column>
            <el-table-column
                label="枚举值"
                width="300"
            >
                <template #default="scope">
                    {{ scope.row.enum.split('\n').join('\t') }}
                </template>
            </el-table-column>
            <el-table-column
                label="操作"
                width="200"
            >
                <template #default="scope">
                    <el-button
                        size="small"
                        @click="handleEdit(scope.$index, scope.row)"
                    >
                        Edit
                    </el-button>
                    <el-button
                        size="small"
                        type="danger"
                        @click="handleDelete(scope.$index, scope.row)"
                    >
                        Delete
                    </el-button>
                </template>
            </el-table-column>
        </el-table>
        <el-dialog
            v-model="dialogTableVisible"
            title="添加行"
            width="1100"
        >
            <div>
                <el-form
                    ref="columnForm"
                    :model="form"
                    :rules="formRules"
                    width="1100"
                    label-width="100px"
                >
                    <el-form-item
                        prop="column"
                        label="字段"
                    >
                        <el-input v-model="form.column" />
                    </el-form-item>

                    <el-form-item
                        prop="name"
                        label="字段名"
                    >
                        <el-input v-model="form.name" />
                    </el-form-item>
                    <el-form-item
                        label="数据类型"
                        prop="type"
                    >
                        <el-select
                            v-model="form.type"
                            placeholder="数据类型"
                        >
                            <el-option
                                v-for="item in TypeList"
                                :key="item.value"
                                :label="item.name"
                                :value="item.value"
                            />
                        </el-select>
                    </el-form-item>
                    <el-form-item
                        prop="isHidden"
                        label="是否隐藏"
                    >
                        <el-switch
                            v-model="form.isHidden"
                        />
                    </el-form-item>
                    <el-form-item
                        prop="isExtend"
                        label="是否派生"
                    >
                        <el-switch
                            v-model="form.isExtend"
                        />
                    </el-form-item>
                    <el-form-item
                        v-if="form.isExtend"
                        prop="formula"
                        label="字段公式"
                    >
                        <el-input
                            v-model="form.formula"
                            placeholder="字段公式，如login_day_1+login_day_2"
                        />
                    </el-form-item>
                    <el-form-item
                        prop="isEnum"
                        label="是否可枚举"
                    >
                        <el-switch
                            v-model="form.isEnum"
                        />
                    </el-form-item>

                    <el-form-item
                        v-if="form.isEnum"
                        prop="enum"
                        label="枚举值"
                    >
                        <el-input
                            v-model="form.enum"
                            placeholder="换行符分割，每行一个枚举值"
                            type="textarea"
                            :autosize="{ minRows: 5, maxRows: 50 }"
                        />
                    </el-form-item>
                    <!-- <el-form-item label="仅报警检测">
                        <el-checkbox-group v-model="form.warningrules">
                            <el-checkbox
                                v-for="item in RuleList"
                                :key="item.name"
                                :value="item.value"
                                :label="item.name"
                            />
                        </el-checkbox-group>
                    </el-form-item> -->
                    <el-form-item>
                        <el-button
                            type="primary"
                            @click="onSubmit"
                        >
                            确认
                        </el-button>
                        <el-button @click="dialogTableVisible=false">
                            取消
                        </el-button>
                    </el-form-item>
                </el-form>
            </div>
        </el-dialog>


        <el-dialog
            v-model="dialogMultiRowVisible"
            title="从建表SQL中解析"
            width="800"
        >
            <el-form :model="multiRowFormData">
                <el-form-item
                    label=""
                    label-width="0"
                >
                    <el-input
                        v-model="multiRowFormData.sql"
                        autocomplete="off"
                        type="textarea"
                        placeholder="Create table xx..."
                        :autosize="{ minRows: 10 }"
                    />
                </el-form-item>
            </el-form>
            <template #footer>
                <div class="dialog-footer">
                    <el-button @click="dialogMultiRowVisible = false">
                        取消
                    </el-button>
                    <el-button
                        type="primary"
                        @click="confirmParseSQL"
                    >
                        确认
                    </el-button>
                </div>
            </template>
        </el-dialog>
        <el-dialog
            v-model="dialogPreviewVisible"
            title="解析出的字段预览"
            width="800"
        >
            <el-table :data="previewTableData">
                <el-table-column
                    prop="name"
                    label="字段"
                />
                <el-table-column
                    prop="type"
                    label="类型"
                />
            </el-table>
            <template #footer>
                <div class="dialog-footer">
                    <el-button @click="dialogPreviewVisible = false">
                        取消
                    </el-button>
                    <el-button
                        type="primary"
                        @click="confirmPreviewData"
                    >
                        确认
                    </el-button>
                </div>
            </template>
        </el-dialog>
    </div>
</template>

<script>
import {defineComponent, watch, ref, unref} from 'vue';
import config from './config';
import {ElMessage, ElMessageBox} from 'element-plus';
import * as dqcApi from '../../../apis/dqc';
// import * as featureApi from '../../../apis/feature';

import _ from 'lodash';

const emptyForm = {
    'column': '',
    'name': '',
    'type': '',
    'isEnum': false,
    'enum': '',
    isHidden: false,
    isExtend: false,
    formula: '',
};

export default defineComponent({
    name: 'TableSchema',
    components: {
    },
    props: {
        modelValue: {
            type: Object,
            required: true,
        },
        parentName: {
            type: String,
            required: true,
        }
    },
    emits: ['update:modelValue'],
    setup(props, {emit}) {
        const formData = ref({...props.modelValue});
        const form = ref(_.cloneDeep(emptyForm));
        const dialogTableVisible = ref(false);
        const editIndex = ref(-1);
        const columnForm = ref(null);
        const dialogMultiRowVisible = ref(false);
        const dialogPreviewVisible = ref(false);
        const multiRowFormData = ref({
            sql: '',
        });
        const previewTableData = ref([]);
        const replacedColumns = ref([]);

        // const vali
        const validateEnum = (rule, value, callback) => {
            if (form.value.isEnum) {
                const enumList = value.split('\n');
                let enumEmpty = true;
                for (let i in enumList) {
                    if (enumList[i].trim() === '') {
                        callback(new Error('枚举值不能为空'));
                        return;
                    }
                    enumEmpty = false;
                }
                if (enumEmpty) {
                    callback(new Error('枚举值不能为空'));
                    return;
                }
            }
            callback();
        };

        const formRules = ref({
            column: [
                {required: true, message: '请输入字段', trigger: 'blur'},
            ],
            name: [
                {required: true, message: '请输入字段名', trigger: 'blur'},
            ],
            type: [
                {required: true, message: '请选择数据类型', trigger: 'change'},
            ],
            isEnum: [
                {required: true, message: '请选择是否枚举', trigger: 'change'},
            ],
            isHidden: [
                {required: true, message: '请选择是否隐藏', trigger: 'change'},
            ],
            isExtend: [
                {required: true, message: '请选择是否派生字段', trigger: 'change'},
            ],
            formula: [
                {required: true, message: '请输入派生字段的计算公式', trigger: 'change'},
            ],
            enum: [
                {required: true, message: '请输入枚举值', trigger: 'blur'},
                {validator: validateEnum, trigger: 'blur'}
            ]
        });

        const updateParent = () => {
            emit('update:modelValue', formData.value);
        };
        if (formData.value.schemaList === undefined) {
            formData.value.schemaList = [];
            updateParent();
        }
        const handleEdit = (index, row) => {
            editIndex.value = index;
            form.value.column = row.column;
            form.value.name = row.name;
            form.value.type = row.type;
            form.value.isHidden = row.isHidden;
            form.value.isEnum = row.isEnum;
            form.value.enum = row.enum;
            form.value.formula = row.formula;
            form.value.isExtend = row.isExtend;
            dialogTableVisible.value = true;
        };

        const handleDelete = (index, row) => {
            formData.value.schemaList.splice(index, 1);
            updateParent();
        };

        const onSubmit = () => {
            columnForm.value.validate((valid) => {
                if (!valid) {
                    return;
                }
                if (editIndex.value > -1) {
                    formData.value.schemaList[editIndex.value] = _.cloneDeep(unref(form.value));
                    editIndex.value = -1;
                } else {
                    formData.value.schemaList.push(_.cloneDeep(unref(form.value)));
                }
                dialogTableVisible.value = false;
                updateParent();
            });
        };

        const addColumn = () => {
            form.value = _.cloneDeep(emptyForm);
            editIndex.value = -1;
            dialogTableVisible.value = true;
        };

        const addBySql = () => {
            dialogMultiRowVisible.value = true;
        };

        const confirmParseSQL = () => {
            dialogMultiRowVisible.value = true;
            dqcApi.meta.parseSql({
                sql: multiRowFormData.value.sql,
            }).then((res) => {
                previewTableData.value = res.data.column;
                replacedColumns.value = res.data.column;
                dialogPreviewVisible.value = true;
            });
        };

        const confirmPreviewData = () => {
            ElMessageBox.confirm(
                '确认后将清空之前已经填写的内容，是否继续？',
                'Warning',
                {
                    confirmButtonText: '确认',
                    cancelButtonText: '取消',
                    type: 'warning',
                }
            ).then(() => {
                console.log('confirm');
                let columns = [];
                replacedColumns.value.forEach((item) => {
                    columns.push({
                        column: item.name,
                        name: item.name,
                        type: item.type,
                        isEnum: false,
                        enum: '',
                        isHidden: false,
                        isExtend: false,
                        formula: '',
                    });
                });
                formData.value.schemaList = columns;
                updateParent();
                dialogPreviewVisible.value = false;
                dialogMultiRowVisible.value = false;
            }).catch(err => {
                console.log(err);
                ElMessage({
                    type: 'info',
                    message: '已放弃',
                });
                dialogPreviewVisible.value = false;
                dialogMultiRowVisible.value = false;
            });
        };

        watch(
            () => props.modelValue,
            (newVal) => {
                formData.value = {...newVal};
            }
        );

        return {
            formData,
            form,
            formRules,
            handleEdit,
            handleDelete,
            onSubmit,
            addBySql,
            updateParent,
            addColumn,
            confirmParseSQL,
            confirmPreviewData,
            multiRowFormData,
            columnForm,
            previewTableData,
            dialogTableVisible,
            dialogMultiRowVisible,
            dialogPreviewVisible,
        };
    },
    data() {
        return {
            TypeElTagTypeMap: config.TypeElTagTypeMap,
            TypeList: config.TypeList,
        };
    },
});
</script>

  <style scoped>
  /* Add your styles here */

    .check-item {
        width: 80%;

    }
  .el-form-item {
    margin-bottom: 15px;
  }
  </style>