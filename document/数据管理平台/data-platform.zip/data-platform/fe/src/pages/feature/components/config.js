export default {
    TypeList: [
        {
            name: 'string',
            value: 'string'
        },
        {
            name: 'int',
            value: 'int'
        },
        {
            name: 'bool',
            value: 'bool'
        },
        {
            name: 'float',
            value: 'float'
        },
        {
            name: 'double',
            value: 'double'
        }
    ],
    TypeElTagTypeMap: {
        string: 'info',
        int: 'success',
        bool: 'warning',
        float: 'danger',
        double: 'primary',
        undefined: ''
    }
};