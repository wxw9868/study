<template>
    <div>
        <el-container>
            <sidebar :items="sidebarItems" />
            <el-main
                class="sidebar-main"
                style="padding: 0;"
            >
                <el-row>
                    <breadcrumb :data="breadcrumbItems" />
                </el-row>
                <el-row>
                    Coming
                </el-row>
            </el-main>
        </el-container>
    </div>
</template>

<script>
import Breadcrumb from '../partial/Breadcrumb';
import Sidebar from '../partial/SideBar';
import config from './config';

import _ from 'lodash';

export default {
    components: {
        Sidebar,
        Breadcrumb
    },
    beforeRouteEnter(to, from, next) {
        next(vm => {
            vm.init();
        });
    },
    setup() {
        return {};
    },
    data() {
        let sidebar = _.cloneDeep(config.sidebar);
        return {
            sidebarItems: sidebar,
            breadcrumbItems: [],
        };
    },
    methods: {
        init() {
            let meta = this.getMeta(this.$route);
            this.page = 1;
            this.breadcrumbItems = meta.breadcrumb;
        },
        getMeta(route) {
            let breadcrumb = _.cloneDeep(config.breadcrumb);

            breadcrumb.push({
                path: '/feature/analysis',
                title: '用户成分分析'
            });
            return {
                breadcrumb
            };
        }
    }
};
</script>

<style lang="scss" scoped>

</style>

