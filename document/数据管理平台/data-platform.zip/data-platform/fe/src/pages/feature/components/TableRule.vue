<template>
    <div>
        <div
            v-for="(item, index) in tableSchema"
            :key="index"
        >
            <div v-if="item.isHidden !== true">
                <div class="flex-container">
                    <div>
                        {{ item.name }}
                    </div>
                    <div>
                        <el-popover
                            placement="right"
                            :width="400"
                            trigger="hover"
                        >
                            <template #reference>
                                <el-icon
                                    :size="20"
                                >
                                    <View />
                                </el-icon>
                            </template>
                            {{ getRule(item.column) }}
                        </el-popover>
                    </div>
                </div>


                <component
                    :is="getComponent(item)"
                    v-model="formData[item.column]"
                    :field-type="item.type"
                    :field-name="item.column"
                    :enum-value="item.enum"
                    @update-parent="updateParent"
                />
            </div>
        </div>
    </div>
</template>

<script>
import {defineComponent, watch, ref} from 'vue';
import EnumRule from './EnumRule.vue';
import StringRule from './StringRule.vue';
import IntRule from './IntRule.vue';

export default defineComponent({
    name: 'TableRule',
    components: {
        EnumRule,
        StringRule,
        IntRule,
    },

    props: {
        modelValue: {
            type: Object,
            required: true,
        },
        tableSchema: {
            type: Object,
            required: true,
        },
    },
    emits: ['update:modelValue'],
    setup(props, {emit}) {
        const formData = ref({...props.modelValue});

        const getComponent = (fieldItem) => {
            if (fieldItem.isEnum) {
                return 'EnumRule';
            }
            if (fieldItem.type === 'string') {
                return 'StringRule';
            }
            return 'IntRule';
        };

        // watch(
        //     () => props.modelValue,
        //     (newVal) => {
        //         formData.value = {...newVal};
        //     }
        // );

        const getRule = (column) => {
            if (!formData.value[column]) {
                return '';
            }
            return formData.value[column].rule;
        };

        const updateParent = () => {
            emit('update:modelValue', formData.value);
        };

        watch(
            () => formData.value,
            () => {
                updateParent();
            },
            {
                deep: true,
            },
        );

        return {
            formData,
            getRule,
            getComponent,
            updateParent,
        };
    },
    data() {
        return {
        };
    },
});
</script>

  <style scoped>
  /* Add your styles here */
  .flex-container {
        display: flex;
        flex-wrap: wrap;
        flex-direction: row;
    }

    .hidden {
        display: none;
    }
  </style>