<template>
    <div>
        <el-container>
            <sidebar :items="sidebarItems" />
            <el-main
                class="sidebar-main"
                style="padding: 0;"
            >
                <el-row>
                    <breadcrumb :data="breadcrumbItems" />
                </el-row>
                <el-row class="filter-row">
                    <el-form
                        :inline="true"
                        :model="filterForm"
                    >
                        <el-form-item label="查询">
                            <el-input
                                v-model="filterForm.word"
                                style="width: 300px;"
                                placeholder="请输入特征名称进行检索"
                                @input="delayLoad"
                            />
                        </el-form-item>
                    </el-form>
                </el-row>
                <el-row class="button-row">
                    <el-button
                        type="success"
                        @click="addFeature"
                    >
                        <el-icon class="el-icon--left">
                            <Plus />
                        </el-icon>
                        添加特征
                    </el-button>
                </el-row>
                <el-row>
                    <el-table
                        v-loading="loading"
                        :data="featureList"
                        empty-text="暂无数据"
                        border
                        style="width: 100%;"
                    >
                        <el-table-column
                            prop="id"
                            label="ID"
                        />
                        <el-table-column
                            prop="tableName"
                            label="名称"
                        />
                        <el-table-column
                            prop="creator"
                            label="创建人"
                        />
                        <el-table-column
                            label="操作"
                            width="300"
                        >
                            <template #default="scope">
                                <div>
                                    <el-button
                                        type="primary"
                                        size="small"
                                        @click="view(scope.row.id)"
                                    >
                                        查看
                                    </el-button>
                                    <el-button
                                        type="success"
                                        size="small"
                                        @click="edit(scope.row.id)"
                                    >
                                        编辑
                                    </el-button>
                                </div>
                            </template>
                        </el-table-column>
                    </el-table>
                    <el-pagination
                        v-model:current-page="page"
                        v-model:page-size="size"
                        :page-sizes="[10, 20, 50, 100]"
                        :total="total"
                        background
                        layout="sizes, prev, pager, next"
                        @size-change="loadData"
                        @current-change="loadData"
                    />
                </el-row>
            </el-main>
        </el-container>
    </div>
</template>

<script>
import Breadcrumb from '../partial/Breadcrumb';
import Sidebar from '../partial/SideBar';
import config from './config';
import * as featureApi from '../../apis/feature';

import _ from 'lodash';

export default {
    components: {
        Breadcrumb,
        Sidebar,
    },
    beforeRouteEnter(to, from, next) {
        next(vm => {
            vm.init();
        });
    },
    setup() {

        return {};
    },
    data() {
        let sidebar = _.cloneDeep(config.sidebar);
        return {
            sidebarItems: sidebar,
            breadcrumbItems: [],
            timeoutSign: null,
            loading: true,
            filterForm: {
                word: ''
            },
            featureList: [],
            page: 1,
            size: 10,
            total: 10,
            echo: 0
        };
    },
    methods: {
        init() {
            let meta = this.getMeta(this.$route);
            this.page = 1;
            this.breadcrumbItems = meta.breadcrumb;
            this.loadData();
        },
        loadData() {
            this.loading = true;
            this.echo++;
            let query = {
                search: this.filterForm.word,
                page: this.page,
                size: this.size,
                echo: this.echo
            };
            featureApi.userFeature.get(query).then(res => {
                if (res.status === 0 && res.echo === this.echo) {
                    this.featureList = res.data;
                    this.total = res.total;
                }
                this.loading = false;
            });
        },
        addFeature() {
            this.$router.push('/feature/edit').catch(() => {});
        },
        view(id) {
            this.$router.push({
                path: '/feature/view',
                query: {
                    id
                }
            }).catch(() => {});
        },
        edit(id) {
            this.$router.push({
                path: '/feature/edit',
                query: {
                    id
                }
            }).catch(() => {});
        },
        delayLoad() {
            if (this.timeoutSign != null) {
                clearTimeout(this.timeoutSign);
            }
            this.timeoutSign = setTimeout(() => {
                this.timeoutSign = null;
                this.page = 1;
                this.loadData();
            }, 300);
        },
        getMeta(route) {
            let breadcrumb = _.cloneDeep(config.breadcrumb);

            breadcrumb.push({
                path: '/package/feature',
                title: '特征管理'
            });
            return {
                breadcrumb
            };
        }
    }
};
</script>

<style lang="scss" scoped>

</style>

