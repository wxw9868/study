<template>
    <div>
        <el-container>
            <sidebar :items="sidebarItems" />
            <el-main
                class="sidebar-main"
                style="padding: 0;"
            >
                <el-row>
                    <breadcrumb :data="breadcrumbItems" />
                </el-row>
                <el-row v-loading="loading">
                    <div class="box-row">
                        <el-form
                            ref="form"
                            :model="form"
                            label-width="100"
                            style="width: 100%;"
                            :rules="rules"
                        >
                            <el-form-item
                                label="特征名"
                                prop="tableName"

                                style="width: 100%;"
                            >
                                <el-input
                                    v-model="form.tableName"
                                />
                            </el-form-item>
                            <el-form-item
                                label="特征描述"
                                prop="tableDesc"

                                style="width: 100%;"
                            >
                                <el-input
                                    v-model="form.tableDesc"
                                />
                            </el-form-item>
                            <el-form-item
                                label="表类型"
                                prop="tableType"
                            >
                                <el-select v-model="form.tableType">
                                    <el-option
                                        label="图灵表"
                                        value="turing"
                                    />
                                    <el-option
                                        label="AFS文件"
                                        value="afs"
                                    />
                                </el-select>
                            </el-form-item>

                            <turing-params
                                v-if="form.tableType === 'turing'"
                                v-model="form.tableParams"
                                parent-name="tableParams"
                            />
                            <afs-params
                                v-if="form.tableType === 'afs'"
                                v-model="form.tableParams"
                                parent-name="tableParams"
                            />
                            <el-form-item
                                label="字段"
                                prop="tableColumn"
                            >
                                <table-schema
                                    v-model="form.tableColumn"
                                    parent-name="tableColumn"
                                />
                            </el-form-item>
                            <el-form-item>
                                <el-button
                                    v-if="editable"
                                    type="primary"
                                    size="large"
                                    @click="submitForm"
                                >
                                    <span v-if="edit"> 更新 </span>
                                    <span v-if="!edit"> 新增 </span>
                                </el-button>
                                <el-button
                                    v-if="editable && edit"
                                    size="large"
                                    type="danger"
                                    @click="deleteJob"
                                >
                                    删除
                                </el-button>
                                <el-button
                                    size="large"
                                    @click="cancelForm"
                                >
                                    取消
                                </el-button>
                            </el-form-item>
                        </el-form>
                    </div>
                </el-row>
            </el-main>
        </el-container>
    </div>
</template>

<script>
import * as featureApi from '../../apis/feature';
import _ from 'lodash';
import {ElMessage} from 'element-plus';
import config from './config';
import Breadcrumb from '../partial/Breadcrumb';
import Sidebar from '../partial/SideBar';
import TableSchema from './components/TableSchema';
import AfsParams from './components/AfsParams';
import TuringParams from './components/TuringParams';


const emptyForm = {
    tableName: '',
    tableDesc: '',
    tableType: 'turing',
    tableParams: {},
    tableColumn: [],
};


export default {
    components: {
        Breadcrumb,
        Sidebar,
        TableSchema,
        AfsParams,
        TuringParams
    },
    beforeRouteEnter(to, from, next) {
        next(vm => {
            vm.init();
        });
    },
    setup() {
        return {};
    },
    data() {
        let meta = this.getMeta(this.$route);
        let sidebar = _.cloneDeep(config.sidebar);
        return {
            loading: false,
            timeoutSign: null,
            form: _.cloneDeep(emptyForm),
            rules: {
                tableName: [{
                    required: true,
                    message: '请输入特征名称'
                }],
                tableType: [{
                    required: true,
                    message: '请选择表类型'
                }],
                tableParams: [{
                    required: true,
                    message: '请输入表参数'
                }],
                tableDesc: [{
                    required: true,
                    message: '请输入特征描述'
                }],
                tableColumn: [{
                    required: true,
                    message: '请输入数据schema'
                }]
            },
            sidebarItems: sidebar,
            breadcrumbItems: meta.breadcrumb,
            edit: meta.edit,
            editable: meta.editable
        };
    },
    methods: {
        init() {
            this.loadData();

        },
        delayLoad() {
            if (this.timeoutSign != null) {
                clearTimeout(this.timeoutSign);
            }
            this.timeoutSign = setTimeout(() => {
                this.timeoutSign = null;
                this.loadTemplate();
            }, 300);
        },
        loadData() {
            if (this.$route.query.id) {
                this.loading = true;
                featureApi.userFeature.get({
                    id: this.$route.query.id
                }).then(data => {
                    if (data.data.length === 0) {
                        ElMessage.error('数据不存在');
                        return;
                    }
                    this.form = data.data[0];
                    this.loading = false;
                });
            } else {
                return;
            }
        },

        getMeta(route) {
            let breadcrumb = _.cloneDeep(config.breadcrumb);
            let editable = route.meta.editable;
            let edit = !!route.query.id;
            if (edit) {
                breadcrumb.push({
                    path: '/feature/edit',
                    title: '编辑特征'
                });
            } else {
                breadcrumb.push({
                    path: '/feature/edit',
                    title: '新建特征'
                });
            }
            return {
                breadcrumb,
                edit,
                editable
            };
        },
        submitForm() {
            this.$refs.form.validate(valid => {
                if (valid) {
                    if (this.form.id != null) {
                        featureApi.userFeature.patch(this.form.id, this.form).then(res => {
                            if (res.status === 0) {
                                this.$router.push('/feature/feature').catch(() => {});
                            }
                        });
                    } else {
                        featureApi.userFeature.post(this.form).then(res => {
                            if (res.status === 0) {
                                this.$router.push('/feature/feature').catch(() => {});
                            }
                        });
                    }
                } else {
                    ElMessage.error('表单验证失败');
                }
            });
        },
        cancelForm() {
            this.$router.push('/feature/feature').catch(() => {});
        },
        nameValid(rule, value, callback) {
            if (!/^[a-zA-Z0-9_.]*$/.test(value)) {
                callback(new Error('请输入合法字符：[a-zA-Z0-9_.]'));
                return;
            }
            callback();
        },
        deleteJob() {
            let name = this.$route.query.id;
            this.$confirm(`确认删除${name}么？`, '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'error'
            }).then(() => {
                featureApi.userFeature.delete({
                    pdb: this.$route.query.pdb,
                    id: name
                }).then(res => {
                    if (res.status === 0) {
                        this.$router.push('/feature/feature').catch(() => {});
                    }
                });
            });
        },
    }
};
</script>

<style lang="scss" scoped>

</style>