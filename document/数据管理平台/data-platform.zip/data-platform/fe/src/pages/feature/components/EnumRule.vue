<template>
    <div>
        <el-checkbox-group
            v-model="formData.data"
            @change="updateParent"
        >
            <el-checkbox
                v-for="item in enumValues"
                :key="item"
                :label="item"
                :value="item"
            />
        </el-checkbox-group>
    </div>
</template>

<script>
import {defineComponent, watch, ref, computed} from 'vue';

export default defineComponent({
    name: 'EnumRule',
    components: {
    },

    props: {
        modelValue: {
            type: Object,
            required: true,
        },
        fieldType: {
            type: String,
            required: true,
            default: 'string',
        },
        fieldName: {
            type: String,
            required: true,
        },
        enumValue: {
            type: String,
            required: true,
            default: () => '',
        },
    },
    emits: ['update:modelValue'],
    setup(props, {emit}) {
        const formData = ref({...props.modelValue});

        const genRule = function () {
            if (formData.value.data.length <= 0) {
                return '';
            }
            if (props.fieldType === 'string') {
                let op = '\'' + formData.value.data.join('\', \'') + '\'';
                return `${props.fieldName} in  (${op})`;
            }
            let inValues = formData.value.data.join(',');
            return `${props.fieldName} in  (${inValues})`;
        };

        const enumValues = computed(() => {
            return props.enumValue.split('\n');
        });
        watch(
            () => props.modelValue,
            (newVal) => {
                formData.value = {...newVal};
            }
        );

        const updateParent = () => {
            formData.value.rule = genRule();
            emit('update:modelValue', formData.value);
        };


        return {
            formData,
            enumValues,
            updateParent,
        };
    },
    data() {
        return {
        };
    },
});
</script>

  <style scoped>
  /* Add your styles here */
  </style>