<template>
    <div>
        <el-row>
            <el-col :span="6">
                <el-transfer
                    v-model="formData.selectFeature"
                    style="text-align: left; display: inline-block"
                    filterable
                    :titles="['特征集', '选中特征']"
                    :button-texts="['移除', '选中']"
                    :render-content="renderFunc"
                    :format="{
                        noChecked: '${total}',
                        hasChecked: '${checked}/${total}',
                    }"

                    :data="transferData"
                    @change="handleChange"
                />
            </el-col>

            <el-col :span="18">
                <div v-if="featureValueMap">
                    <div class="container">
                        <span class="title"><el-tag type="success">全局配置</el-tag></span>
                        <div class="item">
                            <span class="key">输出条数：</span> <el-input-number
                                v-model="formData.globalCondition.limit"
                                class="value"
                                style="width: 100px"
                            />
                        </div>
                        <div class="item">
                            <span class="key">是否过滤空cuid：</span>
                            <el-switch
                                v-model="formData.globalCondition.cuidNullFilter"
                                class="value"
                            />
                        </div>
                        <div class="item">
                            <span class="key">目标版本：</span>
                            <el-checkbox-group
                                v-model="formData.globalCondition.condition"
                                class="value"
                            >
                                <el-checkbox
                                    label="主版"
                                    value="1"
                                />
                                <el-checkbox
                                    label="Lite版"
                                    value="10001"
                                />
                            </el-checkbox-group>
                        </div>
                    </div>


                    <el-collapse
                        v-model="activeName"
                    >
                        <span class="title"><el-tag type="success">特征配置</el-tag></span>
                        <el-collapse-item
                            v-for="(item, index) in formData.selectFeature"
                            :key="index"
                            class="my-collapse-item"
                            :name="item"
                        >
                            <template #title>
                                {{ getTableName(item) }}
                                是否主表 <el-switch
                                    v-model="formData.mainTable[item]"
                                    @click.stop
                                />
                            </template>
                            <table-rule
                                v-model="formData.tableData[item]"
                                :table-schema="getTableSchema(item)"
                            />
                        </el-collapse-item>
                    </el-collapse>
                </div>
            </el-col>
        </el-row>
    </div>
</template>

<script>
import {defineComponent, watch, ref} from 'vue';
import * as featureApi from '../../../apis/feature';
import TableRule from './TableRule.vue';
import _ from 'lodash';

export default defineComponent({
    name: 'UserSelectParams',
    components: {
        TableRule
    },
    props: {
        modelValue: {
            type: Object,
            required: true,
        },
        parentName: {
            type: String,
            required: true,
        }
    },
    emits: ['update:modelValue'],
    setup(props, {emit}) {
        const formData = ref({...props.modelValue});
        const formValid = () => {
            if (formData.value.selectFeature === undefined) {
                formData.value.selectFeature = [];
                formData.value.tableData = {};
                formData.value.mainTable = {};
                formData.value.globalCondition = {
                    limit: 1000000,
                    cuidNullFilter: true,
                    client: []
                };
            }
        };
        // watch(
        //     () => props.modelValue,
        //     (newVal) => {
        //         formData.value = {...newVal};
        //         formValid();
        //     }
        // );
        const featureValueMap = ref({});
        const featureList = ref([]);
        const transferData = ref([]);
        formValid();

        const activeName = ref('');
        const loadFeatures = () => {
            featureApi.userFeature.get({
                page: 1,
                size: 1000,
            }).then((res) => {
                featureList.value = res.data;
                featureValueMap.value = {};
                transferData.value = [];
                featureList.value.forEach((item) => {
                    featureValueMap.value[item.id] = item;
                    transferData.value.push({
                        key: item.id,
                        label: item.tableName,
                    });
                });
                console.log(featureValueMap.value);
            });
        };
        loadFeatures();


        const handleChange = (data) => {
            activeName.value = data[0];
        };

        const getTableName = (item) => {
            if (featureValueMap.value[item]) {
                return featureValueMap.value[item].tableName;
            }
        };

        const getTableSchema = (item) => {
            if (featureValueMap.value[item]) {
                return featureValueMap.value[item].tableColumn.schemaList;
            }
            return [];
        };
        const outputPath = () => {
            let prefix = 'afs://wudang.afs.baidu.com:9902/user/search_data/dce_ns2/caoyu05';
            let timestamp = Date.now();
            let randomNum = Math.random().toString().slice(2);
            let uniquePath = `${prefix}/${timestamp}${randomNum}`;
            return uniquePath;
        };

        const paramsStandardize = () => {
            let outputValue = {
                path: outputPath(),
                ugi: 'search_data,search_data',
                globalCondition: formData.value.globalCondition,
            };
            let tableConditon = [];
            for (let key of formData.value.selectFeature) {
                if (!formData.value.tableData[key] || formData.value.tableData[key].length === 0) {
                    continue;
                }
                let item = {
                    tableName: featureValueMap.value[key].tableName,
                    schemaId: key,
                    tableType: featureValueMap.value[key].tableType,
                    isMain: formData.value.mainTable[key] || false,
                    tableSchema: featureValueMap.value[key].tableColumn.schemaList,
                    tableCondition: formData.value.tableData[key],
                    tableParams: featureValueMap.value[key].tableParams,
                };
                tableConditon.push(item);
            }
            outputValue.tableCondition = tableConditon;
            return outputValue;
        };

        const updateParent = () => {
            let emitValue = _.clone(formData.value);
            emitValue.taskParams = paramsStandardize();
            emit('update:modelValue', emitValue);
            console.log(emitValue.taskParams);
        };

        watch(
            () => formData.value,
            () => {
                updateParent();
            },
            {
                deep: true
            }
        );
        return {
            formData,
            activeName,
            featureValueMap,
            featureList,
            transferData,
            getTableSchema,
            getTableName,
            handleChange,
            updateParent
        };
    },
    data() {
        return {
        };
    },
    mounted() {
        // this.loadFeatures();
    },
    methods: {
        renderFunc(h, option) {
            return h('div', {}, [
                h('span', {}, option.label)
            ]);
        },
        handleButtonClick(option) {
            console.log(option);
        }
    },
});
</script>

  <style scoped>
  /* Add your styles here */
  .el-transfer__buttons button {
    flex-direction: column !important;
    display: inline-flex;
    display: block;
    }

  .el-transfer__buttons button span {
    display: block;
    }

    .container .item {
    display: flex;
    align-items: center;
}

.container .key {
    width: 150px; /* 或者你需要的宽度 */
}

.container .title {
    font-weight: bold;
}

.container .value {
    flex-grow: 1;
    max-width: 300px;
}

.my-collapse-item {
    background-color: lightblue;
    /*border-top: 1px solid #000; /* 黑色上边框 */
    border-bottom: 1px solid #000; /* 黑色下边框 */
    margin-bottom: 10px; /* 底部间隔 */
}
  </style>