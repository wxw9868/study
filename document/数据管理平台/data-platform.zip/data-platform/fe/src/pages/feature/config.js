export default {
    sidebar: [{
        name: '特征管理',
        index: '/feature/feature',
        icon: 'el-icon-s-cooperation'
    }, {
        name: '用户包圈选',
        index: '/feature/user_select/list',
        icon: 'el-icon-s-cooperation'
    }, {
        name: '用户成分分析',
        index: '/feature/analysis',
        icon: 'el-icon-s-cooperation'
    }],
    breadcrumb: [{
        path: '/feature/feature',
        title: '用户特征'
    }],
};