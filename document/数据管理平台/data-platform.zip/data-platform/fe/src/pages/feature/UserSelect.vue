<template>
    <div>
        <task-base
            :enable-schedule="false"
            :dialog-fullscreen="true"
        >
            <template #sidebar>
                <sidebar :items="sidebarItems" />
            </template>
            <template #operation>
            </template>
        </task-base>

        <!-- <el-container>
            <sidebar :items="sidebarItems" />
            <el-main
                class="sidebar-main"
                style="padding: 0;"
            >
                <el-row>
                    <breadcrumb :data="breadcrumbItems" />
                </el-row>
                <el-row>
                    用户包圈选
                </el-row>
            </el-main>
        </el-container> -->
    </div>
</template>

<script>
// import Breadcrumb from '../partial/Breadcrumb';
import Sidebar from '../partial/SideBar';
import config from './config';
import TaskBase from '../science/TaskBase';

import _ from 'lodash';

export default {
    components: {
        Sidebar,
        TaskBase,
    },
    beforeRouteEnter(to, from, next) {
        next(vm => {
            vm.init();
        });
    },
    setup() {

        return {};
    },
    data() {
        let sidebar = _.cloneDeep(config.sidebar);
        return {
            sidebarItems: sidebar,
            breadcrumbItems: [],
        };
    },
    methods: {
        init() {
            let meta = this.getMeta(this.$route);
            this.page = 1;
            this.breadcrumbItems = meta.breadcrumb;
            this.loadData();
        },
        loadData() {},
        getMeta(route) {
            let breadcrumb = _.cloneDeep(config.breadcrumb);

            breadcrumb.push({
                path: '/feature/user_select',
                title: '用户包圈选'
            });
            return {
                breadcrumb
            };
        }
    }
};
</script>

<style lang="scss" scoped>

</style>

