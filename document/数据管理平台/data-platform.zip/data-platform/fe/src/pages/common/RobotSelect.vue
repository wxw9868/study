<template>
    <div>
        <el-select
            v-model="robotName"
            placeholder="选择机器人"
            style="width: 240px"
            @change="updateParent"
        >
            <el-option
                v-for="item in options"
                :key="item.value"
                :label="item.label"
                :value="item.value"
            />
        </el-select>
    </div>
</template>

<script>
import {defineComponent, watch, ref} from 'vue';
import * as manageApi from '../../apis/manage';

export default defineComponent({
    name: 'RobotList',
    components: {
    },

    props: {
        modelValue: {
            type: String,
            required: true,
        },
        mode: {
            type: String,
            default: 'form',
        }
    },
    emits: ['update:modelValue', 'change'],
    setup(props, {emit}) {
        const robotName = ref(props.modelValue);
        const options = ref([]);
        let query = {
            type: 'robot',
            size: 100
        };
        manageApi.meta.get(query).then(res => {
            res.data.forEach(item => {
                options.value.push({
                    label: item.name,
                    value: item.name,
                });
            });
        });
        watch(
            () => props.modelValue,
            (newVal) => {
                robotName.value = newVal;
            }
        );

        const updateParent = () => {
            emit('update:modelValue', robotName.value);
            emit('change', robotName.value);
        };

        return {
            robotName,
            options,
            updateParent,
        };
    },
    data() {
        return {
        };
    },
});
</script>

  <style scoped>
  /* Add your styles here */
  </style>