import {format} from 'date-fns';

export function useDateFormatter() {

    function formatTableDate(row, column, cellValue) {
        let date =  new Date(cellValue * 1000);
        return format(date, 'yyyy-MM-dd HH:mm:ss');
    }
    return {formatTableDate};
}