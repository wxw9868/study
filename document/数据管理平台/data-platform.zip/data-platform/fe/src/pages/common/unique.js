export function useUniqueByKeys() {
    function uniqueByKeys(items, keys) {
        const seen = new Map();
        const result = [];
        const dupIndex = [];

        items.forEach((item, index) => {
            const keyString = keys.map(key => `${key}:${item[key]}`).join('|');
            if (!seen.has(keyString)) {
                seen.set(keyString, true);
                result.push(item);
            } else {
                dupIndex.push(index);
            }
        });

        return [result, dupIndex];
    }
    return {uniqueByKeys};
}