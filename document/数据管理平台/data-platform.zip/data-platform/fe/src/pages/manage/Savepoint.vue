<template>
    <div>
        <task-base />
    </div>
</template>

<script>
import TaskBase from './AsyncTask.vue';

export default {
    components: {
        TaskBase
    },
    setup() {

        return {
        };
    }
};
</script>

<style lang="scss" scoped>

</style>