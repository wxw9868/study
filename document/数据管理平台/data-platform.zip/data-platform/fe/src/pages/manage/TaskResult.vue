<template>
    <div>
        <el-table
            :data="objToArray(result)"
            style="width: 100%"
        >
            <el-table-column
                prop="key"
                label="Key"
                width="180"
            />
            <el-table-column
                prop="value"
                label="Value"
                width="180"
            />
        </el-table>
    </div>
</template>

<script>
import config from './config';

import * as manageApi from '../../apis/manage';
import {useDateFormatter} from '../common/date';

import _ from 'lodash';

export default {
    components: {
    },
    beforeRouteEnter(to, from, next) {
        next(vm => {
            vm.init();
        });
    },
    setup() {
        const dateFormatter = useDateFormatter();
        return {dateFormatter};
    },
    data: function () {
        let sidebar = _.cloneDeep(config.sidebar);
        return {
            timeoutSign: null,
            loading: true,
            onlyUser: '',
            sidebarItems: sidebar,
            breadcrumbItems: [],
            result: {},
            page: 1,
            size: 10,
            total: 10,
            echo: 0,
        };
    },
    computed: {
    },
    methods: {
        init() {
            let meta = this.getMeta(this.$route);
            this.onlyUser = meta.onlyUser;
            this.page = 1;
            this.breadcrumbItems = meta.breadcrumb;
            this.loadData();
        },
        objToArray(obj) {
            return Object.keys(obj).map(key => ({
                key: key,
                value: obj[key]
            }));
        },
        loadData() {
            this.loading = true;
            this.echo++;
            let scheduleApi = manageApi.asyncTask;
            scheduleApi.getOne(this.$route.query.id).then(res => {
                if (res.status === 0) {
                    this.jobData = res.data;
                    this.result = this.jobData.taskResult;
                }
                this.loading = false;
            });
        },
        getComponent(stype) {
            switch (stype) {
                case 'table':
                    return 'DynamicTable';
                case 'link':
                    return 'LinkResult';
            }
        },
        getMeta(route) {
            let breadcrumb = _.cloneDeep(config.breadcrumb);
            let onlyUser = route.matched.some(record => record.meta.onlyUser);

            breadcrumb.push({
                path: '/manage/result',
                title: '任务结果'
            });
            return {
                onlyUser,
                breadcrumb
            };
        }
    }
};
</script>
