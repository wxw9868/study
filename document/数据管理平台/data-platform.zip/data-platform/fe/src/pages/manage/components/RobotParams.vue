<template>
    <div>
        <div v-if="mode==='form'">
            <el-form-item
                label="AccessToken"
                :prop="`${parentName}.token`"
                label-width="120"
                label-position="left"
                :rules="[{required: true, message: '请输入AccessToken', trigger: 'blur'}]"
            >
                <el-input
                    v-model="formData.token"
                    @input="updateParent"
                />
            </el-form-item>
        </div>
        <div v-else>
            AccessToken: {{ formData.token }}
        </div>
    </div>
</template>

<script>
import {defineComponent, watch, ref} from 'vue';

export default defineComponent({
    name: 'RobotParams',
    components: {
    },

    props: {
        modelValue: {
            type: Object,
            required: true,
        },
        parentName: {
            type: String,
            required: true,
        },
        mode: {
            type: String,
            default: 'form',
        }
    },
    emits: ['update:modelValue'],
    setup(props, {emit}) {
        const formData = ref({...props.modelValue});

        watch(
            () => props.modelValue,
            (newVal) => {
                formData.value = {...newVal};
            }
        );

        const updateParent = () => {
            emit('update:modelValue', formData.value);
        };

        return {
            formData,
            updateParent,
        };
    },
    data() {
        return {
        };
    },
});
</script>

  <style scoped>
  /* Add your styles here */
  </style>