<template>
    <div>
        <el-container>
            <sidebar :items="sidebarItems" />
            <el-main
                class="sidebar-main"
                style="padding: 0;"
            >
                <el-row>
                    <breadcrumb :data="breadcrumbItems" />
                </el-row>
                <el-row class="filter-row">
                    <el-form
                        :inline="true"
                        :model="filterForm"
                    >
                        <el-form-item label="查询">
                            <el-input
                                v-model="filterForm.word"
                                style="width: 300px;"
                                placeholder="请输入维表名称或者中文名称进行模糊检索"
                                @input="delayLoad"
                            />
                        </el-form-item>
                    </el-form>
                </el-row>
                <el-row class="button-row">
                    <el-button
                        type="success"
                        @click="addData"
                    >
                        <el-icon class="el-icon--left">
                            <Plus />
                        </el-icon>
                        添加机器人
                    </el-button>
                </el-row>
                <el-row>
                    <el-table
                        v-loading="loading"
                        :data="jobData"
                        empty-text="暂无数据"
                        border
                        style="width: 100%;"
                    >
                        <el-table-column
                            prop="name"
                            label="名称"
                        />
                        <el-table-column
                            prop="params"
                            label="参数"
                        >
                            <template #default="scope">
                                <robot-params
                                    v-model="scope.row.params"
                                    parent-name="params"
                                    mode="view"
                                />
                            </template>
                        </el-table-column>
                        <el-table-column
                            prop="creator"
                            width="180px"
                            label="创建人"
                        />
                        <el-table-column
                            label="操作"
                            width="200px"
                        >
                            <template #default="scope">
                                <div>
                                    <el-button
                                        type="primary"
                                        size="small"
                                        @click="editData(scope.row.id, scope.row)"
                                    >
                                        编辑
                                    </el-button>
                                </div>
                            </template>
                        </el-table-column>
                    </el-table>
                    <el-pagination
                        v-model:current-page="page"
                        v-model:page-size="size"
                        :page-sizes="[10, 20, 50, 100]"
                        :total="total"
                        background
                        layout="sizes, prev, pager, next"
                        @size-change="loadData"
                        @current-change="loadData"
                    />
                </el-row>
            </el-main>
        </el-container>

        <el-dialog
            v-model="dialogFormVisible"
            title="机器人配置"
            width="600"
        >
            <el-form
                ref="form"
                :model="form"
                :rules="rules"
                label-width="120"
            >
                <el-form-item
                    label="name"
                    prop="name"
                >
                    <el-input
                        v-model="form.name"
                        :disabled="editMode==='edit'"
                    />
                </el-form-item>
                <robot-params
                    v-model="form.params"
                    parent-name="params"
                />
            </el-form>
            <template #footer>
                <div class="dialog-footer">
                    <el-button @click="dialogFormVisible = false">
                        取消
                    </el-button>
                    <el-button
                        type="primary"
                        @click="confirmAdd"
                    >
                        确认
                    </el-button>
                </div>
            </template>
        </el-dialog>
    </div>
</template>

<script>
import Breadcrumb from '../partial/Breadcrumb';
import Sidebar from '../partial/SideBar';
import config from './config';

import * as manageApi from '../../apis/manage';
import {ElMessage} from 'element-plus';
import {useDateFormatter} from '../common/date';
import RobotParams from './components/RobotParams';

import _ from 'lodash';

const emptyForm = {
    name: '',
    type: 'robot',
    params: {
        webhook: ''
    }
};

export default {
    components: {
        Breadcrumb,
        Sidebar,
        RobotParams
    },
    beforeRouteEnter(to, from, next) {
        next(vm => {
            vm.init();
        });
    },
    setup() {
        const dateFormatter = useDateFormatter();
        return {dateFormatter};
    },
    data: function () {
        let sidebar = _.cloneDeep(config.sidebar);
        return {
            timeoutSign: null,
            loading: true,
            jobData: [],
            filterForm: {
                word: ''
            },
            onlyUser: '',
            sidebarItems: sidebar,
            breadcrumbItems: [],
            page: 1,
            size: 10,
            total: 10,
            echo: 0,
            dialogFormVisible: false,
            form: {
                name: '',
                type: 'robot',
                params: {
                    webhook: ''
                }
            },
            rules: {
                name: [
                    {required: true, message: '请输入名称', trigger: 'blur'}
                ],
                params: [
                    {required: true, message: '请输入参数', trigger: 'blur'}
                ]
            },
            editMode: 'add',
            editId: null
        };
    },
    computed: {
    },
    methods: {
        init() {
            let meta = this.getMeta(this.$route);
            this.onlyUser = meta.onlyUser;
            this.page = 1;
            this.breadcrumbItems = meta.breadcrumb;
            this.loadData();
        },
        loadData() {
            this.loading = true;
            this.echo++;
            let query = {
                pdb: this.$route.query.pdb,
                search: this.filterForm.word,
                type: 'robot',
                page: this.page,
                size: this.size,
                echo: this.echo
            };
            if (this.onlyUser) {
                query.creator = this.user.username;
            }
            manageApi.meta.get(query).then(res => {
                if (res.status === 0 && res.echo === this.echo) {
                    this.jobData = res.data;
                    this.total = res.total;
                }
                this.loading = false;
            });
        },
        editData(id, data) {
            this.form = data;
            this.dialogFormVisible = true;
            this.editMode = 'edit';
            this.editId = id;
        },
        addData() {
            this.form = _.cloneDeep(emptyForm);
            this.dialogFormVisible = true;
            this.editMode = 'add';
            this.editId = null;
        },
        confirmAdd() {
            this.$refs.form.validate(valid => {
                if (valid) {
                    this.saveForm();
                } else {
                    ElMessage.warning('请检查表单');
                }
            });
        },
        saveForm() {
            if (this.editMode === 'add') {
                manageApi.meta.post(this.form).then(res => {
                    if (res.status === 0) {
                        ElMessage.success('添加成功');
                        this.loadData();
                    }
                    else {
                        ElMessage.warning(res.msg);
                    }
                    this.dialogFormVisible = false;
                });
            } else if (this.editMode === 'edit') {
                let data = {
                    type: this.form.type,
                    params: this.form.params,
                    name: this.form.name
                };
                manageApi.meta.patch(this.editId, data).then(res => {
                    if (res.status === 0) {
                        ElMessage.success('编辑成功');
                        this.loadData();
                    }
                    else {
                        ElMessage.warning(res.msg);
                    }
                    this.dialogFormVisible = false;
                });
            }
        },
        delayLoad() {
            if (this.timeoutSign != null) {
                clearTimeout(this.timeoutSign);
            }
            this.timeoutSign = setTimeout(() => {
                this.timeoutSign = null;
                this.page = 1;
                this.loadData();
            }, 300);
        },
        getMeta(route) {
            let breadcrumb = _.cloneDeep(config.breadcrumb);
            let onlyUser = route.matched.some(record => record.meta.onlyUser);

            breadcrumb.push({
                path: '/manage/robotlist',
                title: '机器人列表'
            });
            return {
                onlyUser,
                breadcrumb
            };
        }
    }
};
</script>
