export default {
    sidebar: [{
        name: '机器人管理',
        index: '/manage/robotlist',
        icon: 'el-icon-s-cooperation'
    }, {
        name: 'Flink任务启停',
        index: '/manage/savepoint',
        icon: 'el-icon-s-cooperation'
    }],
    breadcrumb: [{
        path: '/manage/robotlist',
        title: '管理'
    }],
    statusMap: {
        0: {name: '新建', type: 'info'},
        1: {name: '进行中', type: 'primary'},
        2: {name: '成功', type: 'success'},
        3: {name: '失败', type: 'danger'},
    },
};