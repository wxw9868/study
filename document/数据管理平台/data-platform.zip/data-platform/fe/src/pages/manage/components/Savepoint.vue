<template>
    <div>
        <el-form-item
            label-width="120"
            label-position="left"
            label="JobID"
            :prop="`${parentName}.jobId`"
            :rules="[{required: true, message: '请输入job id', trigger: 'change'}]"
        >
            <el-input
                v-model="formData.jobId"
                placeholder="请输入flink任务的job id"
                @input="updateParent"
            />
        </el-form-item>
    </div>
</template>

<script>
import {defineComponent, watch, ref} from 'vue';

export default defineComponent({
    name: 'SavePoint',
    components: {
    },
    props: {
        modelValue: {
            type: Object,
            required: true,
        },
        parentName: {
            type: String,
            required: true,
        }
    },
    emits: ['update:modelValue'],
    setup(props, {emit}) {
        const formData = ref({...props.modelValue});
        watch(
            () => props.modelValue,
            (newVal) => {
                formData.value = {...newVal};
            }
        );

        const updateParent = () => {
            emit('update:modelValue', formData.value);
        };

        const afsValid = (rule, value, callback) => {
            if (!/^afs:\/\/.*$/.test(value)) {
                callback(new Error('地址非法，请输入afs地址'));
                return;
            }
            callback();
        };

        return {
            formData,
            updateParent,
            afsValid,
        };
    },
    data() {
        return {
        };
    },
});
</script>

  <style scoped>
  /* Add your styles here */
  </style>