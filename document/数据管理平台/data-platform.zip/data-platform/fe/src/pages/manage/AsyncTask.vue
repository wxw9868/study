<template>
    <div>
        <el-container>
            <slot name="sidebar">
                <sidebar :items="sidebarItems" />
            </slot>
            <el-main
                class="sidebar-main"
                style="padding: 0;"
            >
                <el-row>
                    <breadcrumb :data="breadcrumbItems" />
                </el-row>
                <el-row class="filter-row">
                    <el-form
                        :inline="true"
                        :model="filterForm"
                    >
                        <el-form-item label="查询">
                            <el-input
                                v-model="filterForm.word"
                                style="width: 300px;"
                                placeholder="请输入任务名称进行检索"
                                @input="delayLoad"
                            />
                        </el-form-item>
                    </el-form>
                </el-row>
                <el-row class="button-row">
                    <el-button
                        type="success"
                        @click="addTask"
                    >
                        <el-icon class="el-icon--left">
                            <Plus />
                        </el-icon>
                        提交任务
                    </el-button>
                </el-row>
                <el-row>
                    <el-table
                        v-loading="loading"
                        :data="jobData"
                        empty-text="暂无数据"
                        border
                        style="width: 100%;"
                    >
                        <el-table-column
                            prop="id"
                            label="ID"
                        />
                        <el-table-column
                            prop="name"
                            label="名称"
                        />
                        <el-table-column
                            prop="creator"
                            label="创建人"
                        />
                        <el-table-column
                            prop="status"
                            label="任务状态"
                        >
                            <template #default="scope">
                                <el-tag
                                    :type="statusMap[scope.row.status].type"
                                >
                                    {{ statusMap[scope.row.status].name }}
                                </el-tag>
                            </template>
                        </el-table-column>
                        <el-table-column
                            label="操作"
                            width="300"
                        >
                            <template #default="scope">
                                <div>
                                    <el-button
                                        type="primary"
                                        size="small"
                                        @click="viewTask(scope.row.id, scope.row)"
                                    >
                                        查看任务
                                    </el-button>
                                    <el-button
                                        v-if="scope.row.status === 2"
                                        type="success"
                                        size="small"
                                        @click="viewResult(scope.row.id, scope.row)"
                                    >
                                        查看结果
                                    </el-button>
                                </div>
                            </template>
                        </el-table-column>
                    </el-table>
                    <el-pagination
                        v-model:current-page="page"
                        v-model:page-size="size"
                        :page-sizes="[10, 20, 50, 100]"
                        :total="total"
                        background
                        layout="sizes, prev, pager, next"
                        @size-change="loadData"
                        @current-change="loadData"
                    />
                </el-row>
            </el-main>
        </el-container>

        <el-dialog
            v-model="dialogAddVisible"
            title="提交任务"
            width="1200"
            :fullscreen="dialogFullscreen"
        >
            <el-form
                ref="formData"
                :model="formData"
                width="1100"
                :rules="rules"
            >
                <el-form-item
                    label="任务名称"
                    prop="name"
                    label-width="120"
                    label-position="left"
                >
                    <el-input
                        v-model="formData.name"
                        placeholder="请输入任务名称"
                    />
                </el-form-item>
                <slot name="params">
                    <component
                        :is="getFormComponent()"
                        :key="incrKey"
                        v-model="formData.taskParams"
                        parent-name="taskParams"
                    />
                </slot>

                <el-form-item v-if="formMode==='add'">
                    <el-button
                        type="success"
                        @click="confirmAdd"
                    >
                        提交
                    </el-button>
                    <el-button
                        type="danger"
                        @click="dialogAddVisible=false"
                    >
                        取消
                    </el-button>
                </el-form-item>
            </el-form>
        </el-dialog>

        <el-dialog
            v-model="dialogViewVisible"
            title="查看任务"
            width="1200"
        >
            <el-form
                :model="viewFormData"
                width="1300"
                label-width="100px"
            >
                <el-form-item label="任务名称">
                    <el-input v-model="viewFormData.name" />
                </el-form-item>
                <el-form-item label="任务参数">
                    <component
                        :is="getFormComponent()"
                        :key="viewKey"
                        v-model="viewFormData.taskParams"
                        parent-name="taskParams"
                    />
                </el-form-item>
            </el-form>
        </el-dialog>
    </div>
</template>

<script>
import Breadcrumb from '../partial/Breadcrumb';
import Sidebar from '../partial/SideBar';
import config from './config';

import * as manageApi from '../../apis/manage';
import {ElMessage} from 'element-plus';
import {useDateFormatter} from '../common/date';
// import VueForm from '@lljj/vue3-form-element';
import SavePoint from './components/Savepoint';


import _ from 'lodash';

const emptyForm = {
    name: '',
    taskParams: {}
};

export default {
    components: {
        Breadcrumb,
        Sidebar,
        SavePoint,
    },
    props: {
        enableSchedule: {
            type: Boolean,
            default: true
        },
        dialogFullscreen: {
            type: Boolean,
            default: false
        },
    },
    setup() {
        const dateFormatter = useDateFormatter();
        return {dateFormatter};
    },
    data: function () {
        let sidebar = _.cloneDeep(config.sidebar);
        return {
            timeoutSign: null,
            loading: true,
            jobData: [],
            filterForm: {
                word: ''
            },
            formData: {
                name: '',
                taskParams: {}
            },
            rules: {
                name: [
                    {required: true, message: '请输入任务名称，便于检索', trigger: 'blur'}
                ],
                taskParams: [
                    {required: true, message: '请输入参数', trigger: 'blur'}
                ],
            },
            incrKey: 1,
            viewKey: 1,
            onlyUser: '',
            taskType: '',
            sidebarItems: sidebar,
            statusMap: config.statusMap,
            breadcrumbItems: [],
            dialogAddVisible: false,
            dialogViewVisible: false,
            scheduleTypMap: config.scheduleTypMap,
            viewFormData: {},
            formMode: 'add',
            formId: null,
            page: 1,
            size: 10,
            total: 10,
            echo: 0
        };
    },
    computed: {
    },
    mounted() {
        console.log('onmounted init');
        this.init();
    },
    methods: {
        init() {
            console.log('init science task');
            let meta = this.getMeta(this.$route);
            this.onlyUser = meta.onlyUser;
            this.page = 1;
            this.taskType = meta.taskType;
            this.breadcrumbItems = meta.breadcrumb;
            this.loadData();
        },
        loadData() {
            this.loading = true;
            this.echo++;
            let query = {
                pdb: this.$route.query.pdb,
                search: this.filterForm.word,
                taskType: this.taskType,
                page: this.page,
                size: this.size,
                echo: this.echo
            };
            if (this.onlyUser) {
                query.creator = this.user.username;
            }
            manageApi.asyncTask.get(query).then(res => {
                if (res.status === 0 && res.echo === this.echo) {
                    this.jobData = res.data;
                    this.total = res.total;
                }
                this.loading = false;
            });
        },
        addTask() {
            this.incrKey += 1;
            this.formMode = 'add';
            this.formId = null;
            this.formData = _.cloneDeep(emptyForm);
            this.dialogAddVisible = true;
        },
        confirmAdd() {
            this.$refs.formData.validate().then(() => {
                let postData = this.formData;
                postData.taskType = this.taskType;
                if (this.formMode === 'add') {
                    manageApi.asyncTask.post(postData).then(res => {
                        if (res.status === 0) {
                            this.$message({
                                type: 'success',
                                message: '添加成功'
                            });
                            this.loadData();
                        } else {
                            ElMessage.warning(res.msg);
                        }
                    }).finally(() => {
                        this.dialogAddVisible = false;
                    });
                } else {
                    manageApi.asyncTask.patch(this.formId, postData).then(res => {
                        if (res.status === 0) {
                            this.$message({
                                type: 'success',
                                message: '添加成功'
                            });
                            this.loadData();
                        } else {
                            ElMessage.warning(res.msg);
                        }
                    }).finally(() => {
                        this.dialogAddVisible = false;
                    });
                }
            }).catch(err => {
                console.log(err);
                console.log('error submit!!');
            });
        },
        confirmEdit() {
            this.$refs.formData.validate().then(() => {
                let postData = this.formData;
                postData.taskType = this.taskType;
                manageApi.asyncTask.post(postData).then(res => {
                    if (res.status === 0) {
                        this.$message({
                            type: 'success',
                            message: '添加成功'
                        });
                        this.loadData();
                    } else {
                        ElMessage.warning(res.msg);
                    }
                }).finally(() => {
                    this.dialogAddVisible = false;
                });
            }).catch(err => {
                console.log(err);
                console.log('error submit!!');
            });
        },
        viewTask(id, data) {
            this.viewKey += 1;
            this.formMode = 'view';
            this.formId = id;
            // this.formData = _.cloneDeep(data);
            // this.dialogAddVisible = true;
            this.dialogViewVisible = true;
            this.viewFormData = _.cloneDeep(data);
        },

        viewResult(id, data) {
            this.$router.push({
                path: '/manage/taskresult',
                query: {id}
            });
        },
        getFormComponent() {
            switch (this.taskType) {
                case 'savepoint':
                    return 'SavePoint';
            }
            return '';
        },
        delayLoad() {
            if (this.timeoutSign != null) {
                clearTimeout(this.timeoutSign);
            }
            this.timeoutSign = setTimeout(() => {
                this.timeoutSign = null;
                this.page = 1;
                this.loadData();
            }, 300);
        },
        getMeta(route) {
            let breadcrumb = _.cloneDeep(config.breadcrumb);
            let onlyUser = route.matched.some(record => record.meta.onlyUser);
            let taskType = route.meta.type;
            let breadcrumbPush = route.meta.breadcrumb;

            breadcrumb.push(_.cloneDeep(breadcrumbPush));
            return {
                taskType,
                onlyUser,
                breadcrumb
            };
        }
    }
};
</script>
