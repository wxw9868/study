
const abTestSchema = {
    type: 'object',
    properties: {
        actionType: {
            type: 'string',
            title: '活动',
            description: '指定活动'
        },
        appType: {
            type: 'string',
            title: '端类型',
            enum: ['mainline', 'lite'],
            description: '端类型'
        },
        expUserPath: {
            type: 'string',
            title: '实验组用户地址',
            description: '请输入用户的afs地址',
        },
        attribute: {
            type: 'string',
            title: '特征集合',
            description: '选择特征集合',
            enum: ['general']
        }
    },
    required: ['expUserPath', 'actionType', 'appType', 'attribute'],
    additionalProperties: false,
};


export default {
    abtest: abTestSchema,
};