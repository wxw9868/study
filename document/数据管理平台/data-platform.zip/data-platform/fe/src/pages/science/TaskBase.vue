<template>
    <div>
        <el-container>
            <slot name="sidebar">
                <sidebar :items="sidebarItems" />
            </slot>
            <el-main
                class="sidebar-main"
                style="padding: 0;"
            >
                <el-row>
                    <breadcrumb :data="breadcrumbItems" />
                </el-row>
                <el-row class="filter-row">
                    <el-form
                        :inline="true"
                        :model="filterForm"
                    >
                        <el-form-item label="查询">
                            <el-input
                                v-model="filterForm.word"
                                style="width: 300px;"
                                placeholder="请输入任务名称进行检索"
                                @input="delayLoad"
                            />
                        </el-form-item>
                    </el-form>
                </el-row>
                <el-row class="button-row">
                    <el-button
                        type="success"
                        @click="addTask"
                    >
                        <el-icon class="el-icon--left">
                            <Plus />
                        </el-icon>
                        提交任务
                    </el-button>
                </el-row>
                <el-row>
                    <el-table
                        v-loading="loading"
                        :data="jobData"
                        empty-text="暂无数据"
                        border
                        style="width: 100%;"
                    >
                        <el-table-column
                            prop="id"
                            label="ID"
                        />
                        <el-table-column
                            prop="name"
                            label="名称"
                        />
                        <el-table-column
                            prop="creator"
                            label="创建人"
                        />
                        <el-table-column
                            prop="tid"
                            label="taskID"
                        >
                            <template #default="scope">
                                <span v-if="scope.row.scheduleType === 0">{{ scope.row.tid }}</span>
                                <el-tag v-else>
                                    无
                                </el-tag>
                            </template>
                        </el-table-column>
                        <el-table-column
                            v-if="enableSchedule"
                            label="调度类型"
                        >
                            <template #default="scope">
                                <el-tag

                                    :type="scheduleTypMap[scope.row.scheduleType].type"
                                >
                                    {{ scheduleTypMap[scope.row.scheduleType].name }}
                                </el-tag>
                            </template>
                        </el-table-column>
                        <el-table-column
                            prop="status"
                            label="任务状态"
                        >
                            <template #default="scope">
                                <el-tag
                                    v-if="scope.row.scheduleType === 0"
                                    :type="statusMap[scope.row.status].type"
                                >
                                    {{ statusMap[scope.row.status].name }}
                                </el-tag>
                                <div
                                    v-else
                                >
                                    <el-tag
                                        v-if="scope.row.status === 0"
                                        type="success"
                                    >
                                        例行中
                                    </el-tag>
                                    <el-tag
                                        v-else
                                        type="danger"
                                    >
                                        暂停例行
                                    </el-tag>
                                </div>
                            </template>
                        </el-table-column>
                        <el-table-column
                            label="操作"
                            width="300"
                        >
                            <template #default="scope">
                                <div>
                                    <el-button
                                        type="primary"
                                        size="small"
                                        @click="viewTask(scope.row.id, scope.row)"
                                    >
                                        查看任务
                                    </el-button>
                                    <el-button
                                        v-if="scope.row.scheduleType === 1"
                                        type="success"
                                        size="small"
                                        @click="viewHistory(scope.row.id)"
                                    >
                                        执行历史
                                    </el-button>
                                    <slot
                                        name="operation"
                                        :row="scope.row"
                                    >
                                    </slot>
                                    <el-button
                                        v-if="scope.row.status === 2 && scope.row.scheduleType === 0"
                                        type="success"
                                        size="small"
                                        @click="viewResult(scope.row.id, scope.row)"
                                    >
                                        查看结果
                                    </el-button>
                                    <el-button
                                        v-if="scope.row.status === 0 && scope.row.scheduleType === 0"
                                        type="danger"
                                        size="small"
                                        @click="cancel(scope.row.id, scope.row)"
                                    >
                                        取消执行
                                    </el-button>
                                    <el-button
                                        v-if="scope.row.status === 0 && scope.row.scheduleType === 1"
                                        type="danger"
                                        size="small"
                                        @click="cancelSchedule(scope.row.id, scope.row)"
                                    >
                                        取消例行
                                    </el-button>
                                    <el-button
                                        v-if="scope.row.status === 1 && scope.row.scheduleType === 1"
                                        type="danger"
                                        size="small"
                                        @click="startSchedule(scope.row.id, scope.row)"
                                    >
                                        恢复例行
                                    </el-button>
                                </div>
                            </template>
                        </el-table-column>
                    </el-table>
                    <el-pagination
                        v-model:current-page="page"
                        v-model:page-size="size"
                        :page-sizes="[10, 20, 50, 100]"
                        :total="total"
                        background
                        layout="sizes, prev, pager, next"
                        @size-change="loadData"
                        @current-change="loadData"
                    />
                </el-row>
            </el-main>
        </el-container>

        <el-dialog
            v-model="dialogAddVisible"
            title="提交任务"
            width="1200"
            :fullscreen="dialogFullscreen"
        >
            <el-form
                ref="formData"
                :model="formData"
                width="1100"
                :rules="rules"
            >
                <el-form-item
                    label="任务名称"
                    prop="name"
                    label-width="120"
                    label-position="left"
                >
                    <el-input
                        v-model="formData.name"
                        placeholder="请输入任务名称"
                    />
                </el-form-item>
                <el-form-item
                    v-if="enableSchedule"
                    label="调度类型"
                    prop="scheduleType"
                    label-width="120"
                    label-position="left"
                >
                    <el-select
                        v-model="formData.scheduleType"
                        :disabled="formMode === 'edit'"
                        placeholder="请选择调度类型"
                    >
                        <el-option
                            v-for="item in scheduleTypeList"
                            :key="item.value"
                            :label="item.label"
                            :value="item.value"
                        />
                    </el-select>
                </el-form-item>
                <slot name="params">
                    <component
                        :is="getFormComponent()"
                        :key="incrKey"
                        v-model="formData.taskParams"
                        parent-name="taskParams"
                    />
                </slot>
                <!-- <ab-test-params
                    v-model="formData.taskParams"
                    parent-name="taskParams"
                /> -->

                <el-form-item v-if="formData.scheduleType === 1 || formMode==='add'">
                    <el-button
                        type="success"
                        @click="confirmAdd"
                    >
                        提交
                    </el-button>
                    <el-button
                        type="danger"
                        @click="dialogAddVisible=false"
                    >
                        取消
                    </el-button>
                </el-form-item>
            </el-form>
        </el-dialog>

        <el-dialog
            v-model="dialogViewVisible"
            title="查看任务"
            width="1200"
        >
            <el-form
                :model="viewFormData"
                width="1300"
                label-width="100px"
            >
                <el-form-item label="任务名称">
                    <el-input v-model="viewFormData.name" />
                </el-form-item>
                <el-form-item label="任务参数">
                    <component
                        :is="getFormComponent()"
                        :key="viewKey"
                        v-model="viewFormData.taskParams"
                        parent-name="taskParams"
                    />
                    <!-- <ab-test-params
                        v-model="viewFormData.taskParams"
                        parent-name="taskParams"
                        key="abtest_0"
                    /> -->
                </el-form-item>
                <!-- <el-form-item>
                    <el-button
                        type="success"
                        @click="confirmEdit"
                    >
                        确认编辑
                    </el-button>
                </el-form-item> -->
            </el-form>
            <!-- <vue-form
                v-model="viewFormData"
                :schema="getFormSchema()"
            >
                <template>
                    <div>
                        <el-button @click="dialogViewVisible=false">
                            确认
                        </el-button>
                    </div>
                </template>
            </vue-form> -->
        </el-dialog>
    </div>
</template>

<script>
import Breadcrumb from '../partial/Breadcrumb';
import Sidebar from '../partial/SideBar';
import config from './config';
import taskParamsConfig from './taskParamsConfig';

import * as scienceApi from '../../apis/science';
import {ElMessage} from 'element-plus';
import {useDateFormatter} from '../common/date';
// import VueForm from '@lljj/vue3-form-element';
import AbTestParams from './components/AbTestParams';
import UserSelectParams from '../feature/components/UserSelectParams';


import _ from 'lodash';

const emptyForm = {
    name: '',
    taskParams: {}
};

export default {
    components: {
        Breadcrumb,
        Sidebar,
        AbTestParams,
        UserSelectParams
    },
    props: {
        enableSchedule: {
            type: Boolean,
            default: true
        },
        dialogFullscreen: {
            type: Boolean,
            default: false
        },
    },
    setup() {
        const dateFormatter = useDateFormatter();
        return {dateFormatter};
    },
    data: function () {
        let sidebar = _.cloneDeep(config.sidebar);
        return {
            timeoutSign: null,
            loading: true,
            jobData: [],
            filterForm: {
                word: ''
            },
            formData: {
                name: '',
                taskParams: {}
            },
            rules: {
                name: [
                    {required: true, message: '请输入任务名称，便于检索', trigger: 'blur'}
                ],
                taskParams: [
                    {required: true, message: '请输入参数', trigger: 'blur'}
                ],
                scheduleType: [
                    {
                        required: true,
                        message: '请选择调度类型',
                        trigger: 'change'
                    }
                ],
            },
            incrKey: 1,
            viewKey: 1,
            onlyUser: '',
            taskType: '',
            sidebarItems: sidebar,
            statusMap: config.statusMap,
            breadcrumbItems: [],
            dialogAddVisible: false,
            dialogViewVisible: false,
            taskParamsConfig: taskParamsConfig,
            scheduleTypeList: config.scheduleTypeList,
            scheduleTypMap: config.scheduleTypMap,
            viewFormData: {},
            formMode: 'add',
            formId: null,
            page: 1,
            size: 10,
            total: 10,
            echo: 0
        };
    },
    computed: {
    },
    // beforeRouteEnter(to, from, next) {
    //     next(vm => {
    //         vm.init();
    //     });
    // },
    mounted() {
        console.log('onmounted init');
        this.init();
    },
    methods: {
        init() {
            console.log('init science task');
            let meta = this.getMeta(this.$route);
            this.onlyUser = meta.onlyUser;
            this.page = 1;
            this.taskType = meta.taskType;
            this.breadcrumbItems = meta.breadcrumb;
            this.loadData();
        },
        loadData() {
            this.loading = true;
            this.echo++;
            let query = {
                pdb: this.$route.query.pdb,
                search: this.filterForm.word,
                taskType: this.taskType,
                page: this.page,
                size: this.size,
                echo: this.echo
            };
            if (this.onlyUser) {
                query.creator = this.user.username;
            }
            scienceApi.task.get(query).then(res => {
                if (res.status === 0 && res.echo === this.echo) {
                    this.jobData = res.data;
                    this.total = res.total;
                }
                this.loading = false;
            });
        },
        addTask() {
            this.incrKey += 1;
            this.formMode = 'add';
            this.formId = null;
            this.formData = _.cloneDeep(emptyForm);
            this.dialogAddVisible = true;
        },
        confirmAdd() {
            this.$refs.formData.validate().then(() => {
                let postData = this.formData;
                postData.taskType = this.taskType;
                if (this.formMode === 'add') {
                    scienceApi.task.post(postData).then(res => {
                        if (res.status === 0) {
                            this.$message({
                                type: 'success',
                                message: '添加成功'
                            });
                            this.loadData();
                        } else {
                            ElMessage.warning(res.msg);
                        }
                    }).finally(() => {
                        this.dialogAddVisible = false;
                    });
                } else {
                    scienceApi.task.patch(this.formId, postData).then(res => {
                        if (res.status === 0) {
                            this.$message({
                                type: 'success',
                                message: '添加成功'
                            });
                            this.loadData();
                        } else {
                            ElMessage.warning(res.msg);
                        }
                    }).finally(() => {
                        this.dialogAddVisible = false;
                    });
                }
            }).catch(err => {
                console.log(err);
                console.log('error submit!!');
            });
        },
        confirmEdit() {
            this.$refs.formData.validate().then(() => {
                let postData = this.formData;
                postData.taskType = this.taskType;
                scienceApi.task.post(postData).then(res => {
                    if (res.status === 0) {
                        this.$message({
                            type: 'success',
                            message: '添加成功'
                        });
                        this.loadData();
                    } else {
                        ElMessage.warning(res.msg);
                    }
                }).finally(() => {
                    this.dialogAddVisible = false;
                });
            }).catch(err => {
                console.log(err);
                console.log('error submit!!');
            });
        },
        viewTask(id, data) {
            this.viewKey += 1;
            this.formMode = 'view';
            this.formId = id;
            // this.formData = _.cloneDeep(data);
            // this.dialogAddVisible = true;
            this.dialogViewVisible = true;
            this.viewFormData = _.cloneDeep(data);
        },
        viewHistory(id) {
            this.$router.push({
                path: '/science/taskhistory',
                query: {id}
            });
        },
        viewAbTestResult(id, name) {
            this.$router.push({
                path: '/science/abestresult',
                query: {id, name}
            });
        },
        viewResult(id, data) {
            this.$router.push({
                path: '/science/taskresult',
                query: {id}
            });
        },
        cancelSchedule(id, data) {
            scienceApi.task.patch(id, {
                status: 1,
            }).then(res => {
                if (res.status === 0) {
                    this.$message({
                        type: 'success',
                        message: '取消成功'
                    });
                } else {
                    ElMessage.warning(res.msg);
                }
            }).finally(() => {
                this.loadData();
            });
        },
        startSchedule(id, data) {
            scienceApi.task.patch(id, {
                status: 0,
            }).then(res => {
                if (res.status === 0) {
                    this.$message({
                        type: 'success',
                        message: '取消成功'
                    });
                } else {
                    ElMessage.warning(res.msg);
                }
            }).finally(() => {
                this.loadData();
            });
        },
        cancel(id, data) {
            scienceApi.task.patch(id, {
                status: 4,
            }).then(res => {
                if (res.status === 0) {
                    this.$message({
                        type: 'success',
                        message: '取消成功'
                    });
                } else {
                    ElMessage.warning(res.msg);
                }
            }).finally(() => {
                this.loadData();
            });
        },
        getFormComponent() {
            console.log(this.taskType);
            switch (this.taskType) {
                case 'abtest':
                    return 'AbTestParams';
                case 'user_select':
                    return 'UserSelectParams';
            }
            return '';
        },
        getFormSchema() {
            let taskParams = this.taskParamsConfig[this.taskType];
            let schema = {
                'type': 'object',
                'properties': {
                    name: {
                        type: 'string',
                        title: '任务名称',
                        description: '请输入有意义的名称，便于检索'
                    },
                    taskParams: taskParams
                },
                required: ['name'],
            };
            return schema;
        },
        delayLoad() {
            if (this.timeoutSign != null) {
                clearTimeout(this.timeoutSign);
            }
            this.timeoutSign = setTimeout(() => {
                this.timeoutSign = null;
                this.page = 1;
                this.loadData();
            }, 300);
        },
        getMeta(route) {
            let breadcrumb = _.cloneDeep(config.breadcrumb);
            let onlyUser = route.matched.some(record => record.meta.onlyUser);
            let taskType = route.meta.type;
            let breadcrumbPush = route.meta.breadcrumb;

            breadcrumb.push(_.cloneDeep(breadcrumbPush));
            return {
                taskType,
                onlyUser,
                breadcrumb
            };
        }
    }
};
</script>
