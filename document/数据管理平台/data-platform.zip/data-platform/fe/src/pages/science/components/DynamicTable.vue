<template>
    <div>
        <slot :export="exportToExcel"></slot>
        <el-table
            :data="tableData"
            border
            height="1000"
        >
            <el-table-column
                type="index"
                width="100"
                label="序号"
            />
            <el-table-column
                v-for="column in columns"
                :key="column.prop"
                :prop="column.prop"
                :label="column.label"
            />
        </el-table>
    </div>
</template>

<script>
import {defineComponent, ref, watchEffect} from 'vue';
import * as XLSX from 'xlsx';

export default defineComponent({
    components: {
    },
    props: {
        data: {
            type: Array,
            required: true,
        }
    },
    emits: ['update:modelValue'],
    setup(props, {emit}) {
        const columns = ref([]);

        const tableData = ref(props.data);

        const exportToExcel = (tableName) => {
            // 获取列的顺序（属性名称）
            const headers = columns.value.map(column => column.prop);

            // 将表格数据转换为工作表，并指定列的顺序
            const worksheet = XLSX.utils.json_to_sheet(tableData.value, {header: headers});

            // 自定义标题行
            XLSX.utils.sheet_add_aoa(worksheet, [columns.value.map(col => col.label)], {origin: 'A1'});

            // 创建工作簿并添加工作表
            const workbook = XLSX.utils.book_new();
            XLSX.utils.book_append_sheet(workbook, worksheet, 'Sheet1');

            // 生成 Excel 文件并触发下载
            XLSX.writeFile(workbook, `${tableName}.xlsx`);
        };
        watchEffect(() => {
            if (props.data.length === 0) {
                columns.value = [];
                tableData.value = [];
                return;
            }
            const [keys, ...rows] = props.data;

            const columnOrder = keys.map(key => ({prop: key, label: key}));

            const result = rows.map(row =>
                row.reduce((obj, value, index) => {
                    obj[keys[index]] = value;
                    return obj;
                }, {})
            );
            tableData.value = result;
            columns.value = columnOrder;
        });
        // watch(() => props.data, (newVal) => {
        //     tableData.value = newVal;
        // });
        // watch(tableData, (newVal) => {
        //     emit('update:modelValue', newVal);
        // });

        return {
            columns,
            tableData,
            exportToExcel
        };
    },
    data() {
        return {
        };
    },
});
</script>

  <style>

  .el-table .warning-row {
  --el-table-tr-bg-color: var(--el-color-warning-light-9);
}
  </style>