<template>
    <div>
        <el-container>
            <sidebar :items="sidebarItems" />
            <el-main
                class="sidebar-main"
                style="padding: 0;"
            >
                <el-row>
                    <breadcrumb :data="breadcrumbItems" />
                </el-row>
                <el-row>
                    <el-table
                        v-loading="loading"
                        :data="jobData"
                        empty-text="暂无数据"
                        border
                        style="width: 100%;"
                    >
                        <el-table-column
                            prop="id"
                            label="ID"
                        />
                        <el-table-column
                            prop="creator"
                            label="创建人"
                        />
                        <el-table-column
                            prop="jobId"
                            label="jobID"
                        />
                        <el-table-column
                            prop="runType"
                            label="任务类型"
                        />
                        <el-table-column
                            prop="tid"
                            label="taskID"
                        />
                        <el-table-column
                            prop="status"
                            label="任务状态"
                        >
                            <template #default="scope">
                                <el-tag :type="statusMap[scope.row.status].type">
                                    {{ statusMap[scope.row.status].name }}
                                </el-tag>
                            </template>
                        </el-table-column>
                        <el-table-column
                            label="操作"
                            width="300"
                        >
                            <template #default="scope">
                                <div>
                                    <el-button
                                        v-if="scope.row.status === 2"
                                        type="success"
                                        size="small"
                                        @click="viewResult(scope.row.id, scope.row)"
                                    >
                                        查看结果
                                    </el-button>
                                    <el-button
                                        v-if="scope.row.status !== 2"
                                        type="danger"
                                        size="small"
                                        @click="setSuccess(scope.row.id, scope.row)"
                                    >
                                        置为成功
                                    </el-button>
                                </div>
                            </template>
                        </el-table-column>
                    </el-table>
                    <el-pagination
                        v-model:current-page="page"
                        v-model:page-size="size"
                        :page-sizes="[10, 20, 50, 100]"
                        :total="total"
                        background
                        layout="sizes, prev, pager, next"
                        @size-change="loadData"
                        @current-change="loadData"
                    />
                </el-row>
            </el-main>
        </el-container>
    </div>
</template>

<script>
import Breadcrumb from '../partial/Breadcrumb';
import Sidebar from '../partial/SideBar';
import config from './config';
import taskParamsConfig from './taskParamsConfig';
import * as scienceApi from '../../apis/science';
import {useDateFormatter} from '../common/date';
import {ElMessage} from 'element-plus';
import _ from 'lodash';

export default {
    components: {
        Breadcrumb,
        Sidebar
    },
    beforeRouteEnter(to, from, next) {
        next(vm => {
            vm.init();
        });
    },
    setup() {
        const dateFormatter = useDateFormatter();
        return {dateFormatter};
    },
    data: function () {
        let sidebar = _.cloneDeep(config.sidebar);
        return {
            timeoutSign: null,
            loading: true,
            jobData: [],
            taskType: '',
            sidebarItems: sidebar,
            statusMap: config.statusMap,
            breadcrumbItems: [],
            taskParamsConfig: taskParamsConfig,
            scheduleTypeList: config.scheduleTypeList,
            scheduleTypMap: config.scheduleTypMap,
            page: 1,
            size: 10,
            total: 10,
            echo: 0
        };
    },
    computed: {
    },
    methods: {
        init() {
            let meta = this.getMeta(this.$route);
            this.page = 1;
            this.taskType = meta.taskType;
            this.breadcrumbItems = meta.breadcrumb;
            this.loadData();
        },
        loadData() {
            this.loading = true;
            this.echo++;
            let query = {
                taskId: this.$route.query.id,
                page: this.page,
                size: this.size,
                echo: this.echo
            };
            scienceApi.taskHistory.get(query).then(res => {
                if (res.status === 0 && res.echo === this.echo) {
                    this.jobData = res.data;
                    this.total = res.total;
                }
                this.loading = false;
            });
        },
        viewResult(id, data) {
            this.$router.push({
                path: '/science/taskresult',
                query: {
                    id: id,
                    type: 'schedule'
                }
            });
        },
        setSuccess(id, data) {
            scienceApi.task.setSuccess({
                id: id,
                jobId: data.jobId,
            }).then(res => {
                if (res.status === 0) {
                    ElMessage.success('操作成功');
                }
            });
        },
        delayLoad() {
            if (this.timeoutSign != null) {
                clearTimeout(this.timeoutSign);
            }
            this.timeoutSign = setTimeout(() => {
                this.timeoutSign = null;
                this.page = 1;
                this.loadData();
            }, 300);
        },
        getMeta(route) {
            let breadcrumb = _.cloneDeep(config.breadcrumb);
            let onlyUser = route.matched.some(record => record.meta.onlyUser);
            let taskType = route.meta.type;

            breadcrumb.push({
                path: '/science/abtest',
                title: '虚拟AB'
            });
            return {
                taskType,
                onlyUser,
                breadcrumb
            };
        }
    }
};
</script>
