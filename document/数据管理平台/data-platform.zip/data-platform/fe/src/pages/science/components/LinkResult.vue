<template>
    <div>
        <a href="data">结果链接</a>
    </div>
</template>

<script>
export default {
    props: {
        data: {
            type: String,
            required: true
        }
    },
    setup() {
        return {};
    }
};
</script>

<style lang="scss" scoped>

</style>