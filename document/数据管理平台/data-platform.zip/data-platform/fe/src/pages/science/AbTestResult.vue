<template>
    <div>
        <div class="table-container">
            <el-button
                type="primary"
                @click="exportToExcel"
            >
                导出到 Excel
            </el-button>
            <el-table
                v-loading="loading"
                :data="paginatedData"
                style="width: 100%"
                height="500px"
                :header-cell-style="{ background: '#f2f2f2', fontWeight: 'bold' }"
                :row-class-name="tableRowClassName"
                border
                :fixed="false"
            >
                <el-table-column
                    v-for="(field, index) in tableFields"
                    :key="index"
                    :label="field"
                    :prop="field"
                    :min-width="150"
                    sortable
                />
            </el-table>

            <div class="pagination-container">
                <el-pagination
                    v-model:current-page="currentPage"
                    v-model:page-size="pageSize"
                    background
                    layout="prev, pager, next, jumper, sizes, total"
                    :page-sizes="[10, 20, 50, 100]"
                    :total="total"
                    @size-change="handleSizeChange"
                    @current-change="handleCurrentChange"
                />
            </div>
        </div>
    </div>
</template>

<script>
import * as scienceApi from '../../apis/science';
import _ from 'lodash';
import * as XLSX from 'xlsx';
import config from './config';

export default {
    data() {
        return {
            tableFields: [],
            tableData: [],
            paginatedData: [],
            loading: false,
            onlyUser: '',
            breadcrumbItems: [],
            page: 1,
            size: 10,
            total: 0,
            echo: 0,
            result: {},
            currentPage: 1,
            pageSize: 10,
        };
    },
    created() {
        this.init();
    },
    methods: {
        init() {
            const meta = this.getMeta(this.$route);
            this.onlyUser = meta.onlyUser;
            this.page = 1;
            this.breadcrumbItems = meta.breadcrumb;
            this.loadData();
        },
        loadData() {
            this.loading = true;
            this.echo++;
            let scheduleApi = scienceApi.task;
            scheduleApi.GetAbTestResult({
                taskId: this.$route.query.id,
            })
                .then(res => {
                    if (res.status === 0) {
                        this.result = res.data;
                        this.processData(this.result);
                    } else {
                        this.$message.error(res.msg || '加载数据失败');
                    }
                    this.loading = false;
                })
                .catch(error => {
                    console.error('Error loading data:', error);
                    this.$message.error('请求数据时发生错误');
                    this.loading = false;
                });
        },
        processData(data) {
            this.tableFields = data.fields.split('\t');

            this.tableData = data.values.map(row => {
                const rowValues = row.trim().split('\t');
                const rowData = {};
                this.tableFields.forEach((field, index) => {
                    const value = rowValues[index];
                    const parsedValue = parseFloat(value);
                    if (!isNaN(parsedValue) && value.indexOf('E') !== -1) {
                        rowData[field] = parsedValue.toString();
                    } else {
                        rowData[field] = value;
                    }
                });
                return rowData;
            });

            this.total = this.tableData.length;
            this.addAverageRow();
            this.setPaginatedData();
        },
        addAverageRow() {
            const averageRow = {};
            const numColumns = this.tableFields.length;
            averageRow[this.tableFields[0]] = '均值';
            for (let index = 2; index < numColumns; index++) {
                const columnValues =
              this.tableData.map(row => parseFloat(row[this.tableFields[index]])).filter(value => !isNaN(value));

                if (columnValues.length > 0) {
                    const sum = columnValues.reduce((acc, curr) => acc + curr, 0);
                    averageRow[this.tableFields[index]] = (sum / columnValues.length).toFixed(2);
                } else {
                    averageRow[this.tableFields[index]] = 'N/A';
                }
            }

            this.tableData.push(averageRow);
            this.addDiffRow(averageRow);

            this.addRatioRow(averageRow);
        },
        addDiffRow(averageRow) {
            const diffRow = {};
            diffRow[this.tableFields[0]] = '均值diff';


            for (let index = 2; index < 24; index++) {
                const currentValue = parseFloat(averageRow[this.tableFields[index]]);
                const correspondingValue = parseFloat(averageRow[this.tableFields[index + 22]]);
                if (!isNaN(currentValue) && !isNaN(correspondingValue)) {
                    diffRow[this.tableFields[index]] = (currentValue - correspondingValue).toFixed(2);
                } else {
                    diffRow[this.tableFields[index]] = 'N/A';
                }
            }

            this.tableData.push(diffRow);
        },
        addRatioRow(averageRow) {
            const ratioRow = {};
            ratioRow[this.tableFields[0]] = '均值占比';

            for (let index = 2; index < 24; index++) {
                const meanValue = parseFloat(averageRow[this.tableFields[index]]);
                const diffValue = parseFloat(this.tableData[this.tableData.length - 1][this.tableFields[index]]);
                if (!isNaN(meanValue) && meanValue !== 0) {
                    ratioRow[this.tableFields[index]] = ((diffValue / meanValue) * 100).toFixed(2) + '%';
                } else {
                    ratioRow[this.tableFields[index]] = 'N/A';
                }
            }

            this.tableData.push(ratioRow);
        },
        setPaginatedData() {
            const start = (this.currentPage - 1) * this.pageSize;
            const end = start + this.pageSize;
            this.paginatedData = this.tableData.slice(start, end);
        },
        handleSizeChange(newSize) {
            this.pageSize = newSize;
            this.setPaginatedData();
        },
        handleCurrentChange(newPage) {
            this.currentPage = newPage;
            this.setPaginatedData();
        },
        getMeta(route) {
            const breadcrumb = _.cloneDeep(config.breadcrumb);
            const onlyUser = route.matched.some(record => record.meta.onlyUser);

            breadcrumb.push({
                path: '/science/abtest',
                title: '虚拟AB'
            });
            return {
                onlyUser,
                breadcrumb
            };
        },
        tableRowClassName({row, rowIndex}) {
            return rowIndex % 2 === 0 ? 'even-row' : 'odd-row';
        },
        exportToExcel() {
            const worksheet = XLSX.utils.json_to_sheet(this.tableData);
            const workbook = XLSX.utils.book_new();
            XLSX.utils.book_append_sheet(workbook, worksheet, this.$route.query.id);
            XLSX.writeFile(workbook, this.$route.query.name + '.xlsx');
        }
    }
};
</script>

  <style scoped>
  .table-container {
    padding-top: 20px; /* 表格顶部内边距 */
    padding-left: 10px; /* 表格左侧内边距 */
  }
  .pagination-container {
    margin-top: 20px;
    text-align: right;
  }

  /* 表格行样式 */
  .even-row {
    background-color: #f9f9f9;
  }

  .odd-row {
    background-color: #ffffff;
  }

  /* 可选：增加表格的悬停效果 */
  .el-table tr:hover {
    background-color: #f1f1f1;
  }
  </style>