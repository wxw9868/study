<template>
    <div>
        <task-base>
            <template #operation="scope">
                <el-button
                    v-if="scope.row.scheduleType === 1"
                    type="success"
                    size="small"
                    @click="viewAbTestResult(scope.row.id, scope.row.name)"
                >
                    查看AB结果
                </el-button>
            </template>
        </task-base>
    </div>
</template>

<script>
import TaskBase from './TaskBase.vue';
import {useRouter} from 'vue-router';

export default {
    components: {
        TaskBase
    },
    setup() {
        const router = useRouter();
        const viewAbTestResult = (id, name) => {
            router.push({
                path: '/science/abestresult',
                query: {id, name}
            });
        };
        return {
            viewAbTestResult
        };
    }
};
</script>

<style lang="scss" scoped>

</style>