export default {
    sidebar: [{
        name: '虚拟AB',
        index: '/science/abtest',
        icon: 'el-icon-s-cooperation'
    }],
    breadcrumb: [{
        path: '/science/abtest',
        title: '数据科学'
    }],
    statusMap: {
        0: {name: '新建', type: 'info'},
        1: {name: '进行中', type: 'primary'},
        2: {name: '成功', type: 'success'},
        3: {name: '失败', type: 'danger'},
        4: {name: '已取消', type: 'warning'}
    },
    scheduleTypeList: [
        {
            value: 0,
            label: '单次'
        },
        {
            value: 1,
            label: '例行'
        }
    ],
    scheduleTypMap: {
        0: {
            name: '单次调度',
            type: 'primary'
        },
        1: {
            name: '例行调度',
            type: 'success'
        }
    },
};