<template>
    <div>
        <el-form-item
            label-width="120"
            label-position="left"
            label="开始时间"
            :prop="`${parentName}.timeRange`"
            :rules="[{required: true, message: '请选择开始时间跟结束时间', trigger: 'change'}]"
        >
            <!-- <el-date-picker
                v-model="formData.timeStart"
                type="date"
                placeholder="选择开始日期"
                :shortcuts="shortcuts"
                :disabled-date="disabledDate"
                value-format="YYYY-MM-DD"
                @change="updateParent"
            /> -->
            <el-date-picker
                v-model="formData.timeRange"
                type="daterange"
                unlink-panels
                range-separator="To"
                start-placeholder="开始日期"
                end-placeholder="结束日期"
                :shortcuts="shortcuts"
                value-format="YYYY-MM-DD"
                @change="updateParent"
            />
        </el-form-item>
        <el-form-item
            label-width="120"
            label-position="left"
            label="活动类型"
            style="margin-top: 15px"
            :prop="`${parentName}.actionType`"
            :rules="[{required: true, message: '选择或者输入活动类型', trigger: 'change'}]"
        >
            <el-select
                v-model="formData.actionType"
                allow-create
                filterable
                default-first-option
                placeholder="选择或者输入活动类型"
                style="width: 500px"
                @change="updateParent"
            >
                <el-option
                    v-for="item in actionOptions"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value"
                />
            </el-select>
        </el-form-item>

        <el-form-item
            label-width="120"
            label-position="left"
            style="margin-top: 15px"
            label="端类型"
            :prop="`${parentName}.appType`"
            :rules="[{required: true, message: '请选择端类型', trigger: 'change'}]"
        >
            <el-select
                v-model="formData.appType"
                default-first-option
                :reserve-keyword="false"
                placeholder="请选择端类型"
                style="width: 500px"
                @change="updateParent"
            >
                <el-option
                    v-for="item in appTypeOptions"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value"
                />
            </el-select>
        </el-form-item>

        <el-form-item
            label-width="120"
            label-position="left"
            style="margin-top: 15px"
            label="特征选取"
            :prop="`${parentName}.attribute`"
            :rules="[{required: true, message: '选择所需特征', trigger: 'change'}]"
        >
            <el-select
                v-model="formData.attribute"
                allow-create
                default-first-option
                :reserve-keyword="false"
                placeholder="选择所需特征"
                style="width: 500px"
                @change="updateParent"
            >
                <el-option
                    v-for="item in attributeOptions"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value"
                />
            </el-select>
        </el-form-item>

        <el-form-item
            label-width="120"
            label-position="left"
            style="margin-top: 15px"
            label="实验组用户包"
            :prop="`${parentName}.expUserPath`"
            :rules="[{required: true, message: '请输入实验组用户包地址', trigger: 'change'},
                     {validator: afsValid, trigger: 'blur'}]"
        >
            <el-input
                v-model="formData.expUserPath"
                style="width: 800px"
                @input="updateParent"
            />
        </el-form-item>

        <el-form-item
            label-width="120"
            label-position="left"
            style="margin-top: 15px"
            label="AFS UGI"
            :prop="`${parentName}.ugi`"
            :rules="[{required: true, message: '请输入AFS UGI', trigger: 'blur'}]"
        >
            <el-input
                v-model="formData.ugi"
                style="width: 500px"
                @input="updateParent"
            />
        </el-form-item>
    </div>
</template>

<script>
import {defineComponent, watch, ref} from 'vue';

export default defineComponent({
    name: 'AbTestParams',
    components: {
    },
    props: {
        modelValue: {
            type: Object,
            required: true,
        },
        parentName: {
            type: String,
            required: true,
        }
    },
    emits: ['update:modelValue'],
    setup(props, {emit}) {
        const formData = ref({...props.modelValue});

        const actionOptions = [
            {
                value: '开屏活动',
                label: '开屏活动',
            },
            {
                value: '开学季',
                label: '开学季',
            },
            {
                value: '搜有红包',
                label: '搜有红包',
            },
            {
                value: '神龙红包',
                label: '神龙红包',
            },
            {
                value: '泛知识答题',
                label: '泛知识答题',
            }
        ];
        const appTypeOptions = [
            {
                value: 'mainline',
                label: '主板',
            },
            {
                value: 'lite',
                label: '极速版'
            }
        ];
        const attributeOptions = [
            {
                value: 'general',
                label: '通用特征'
            },
            {
                value: 'openscreen',
                label: '开屏特征'
            }
        ];

        watch(
            () => props.modelValue,
            (newVal) => {
                formData.value = {...newVal};
            }
        );

        const updateParent = () => {
            emit('update:modelValue', formData.value);
        };

        const afsValid = (rule, value, callback) => {
            if (!/^afs:\/\/.*$/.test(value)) {
                callback(new Error('地址非法，请输入afs地址'));
                return;
            }
            callback();
        };
        const shortcuts = [
            {
                text: 'Today',
                value: new Date(),
            },
            {
                text: 'Yesterday',
                value: () => {
                    const date = new Date();
                    date.setTime(date.getTime() - 3600 * 1000 * 24);
                    return date;
                },
            },
            {
                text: 'A week ago',
                value: () => {
                    const date = new Date();
                    date.setTime(date.getTime() - 3600 * 1000 * 24 * 7);
                    return date;
                },
            },
        ];

        const disabledDate = (time) => {
            return time.getTime() > Date.now();
        };

        return {
            formData,
            updateParent,
            afsValid,
            disabledDate,
            actionOptions,
            appTypeOptions,
            attributeOptions,
            shortcuts
        };
    },
    data() {
        return {
        };
    },
});
</script>

  <style scoped>
  /* Add your styles here */
  </style>