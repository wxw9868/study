<template>
    <div>
        <el-tabs
            v-model="activeName"
            type="card"
        >
            <el-tab-pane
                v-for="item in result.data"
                :key="item.tab_name"
                :label="item.tab_name"
                :name="item.tab_name"
            >
                <div
                    v-for="(contentItem, index) in item.item_list"
                    :key="index"
                >
                    <component
                        :is="getComponent(contentItem.stype)"
                        :data="contentItem.content"
                    >
                        <template #default="scope">
                            {{ contentItem.title }}
                            <el-button
                                type="success"
                                @click="scope.export(contentItem.title)"
                            >
                                导出
                            </el-button>
                        </template>
                    </component>
                </div>
            </el-tab-pane>
        </el-tabs>
    </div>
</template>

<script>
import Breadcrumb from '../partial/Breadcrumb';
import Sidebar from '../partial/SideBar';
import config from './config';

import DynamicTable from './components/DynamicTable';
import LinkResult from './components/LinkResult';
import * as scienceApi from '../../apis/science';
import {useDateFormatter} from '../common/date';

import _ from 'lodash';

export default {
    components: {
        Breadcrumb,
        Sidebar,
        DynamicTable,
        LinkResult
    },
    beforeRouteEnter(to, from, next) {
        next(vm => {
            vm.init();
        });
    },
    setup() {
        const dateFormatter = useDateFormatter();
        return {dateFormatter};
    },
    data: function () {
        let sidebar = _.cloneDeep(config.sidebar);
        return {
            timeoutSign: null,
            loading: true,
            onlyUser: '',
            activeName: '',
            sidebarItems: sidebar,
            breadcrumbItems: [],
            result: {},
            page: 1,
            size: 10,
            total: 10,
            echo: 0,
        };
    },
    computed: {
    },
    methods: {
        init() {
            let meta = this.getMeta(this.$route);
            this.onlyUser = meta.onlyUser;
            this.page = 1;
            this.breadcrumbItems = meta.breadcrumb;
            this.loadData();
        },
        loadData() {
            this.loading = true;
            this.echo++;
            let scheduleApi = scienceApi.task;
            if (this.$route.query.type === 'schedule') {
                scheduleApi = scienceApi.taskHistory;
            }
            scheduleApi.getOne(this.$route.query.id).then(res => {
                if (res.status === 0) {
                    this.jobData = res.data;
                    this.total = res.total;
                    this.result = this.jobData.result;
                    this.activeName = this.result.tab_list[0];
                }
                this.loading = false;
            });
        },
        getComponent(stype) {
            switch (stype) {
                case 'table':
                    return 'DynamicTable';
                case 'link':
                    return 'LinkResult';
            }
        },
        getMeta(route) {
            let breadcrumb = _.cloneDeep(config.breadcrumb);
            let onlyUser = route.matched.some(record => record.meta.onlyUser);

            breadcrumb.push({
                path: '/science/abtest',
                title: '虚拟AB'
            });
            return {
                onlyUser,
                breadcrumb
            };
        }
    }
};
</script>
