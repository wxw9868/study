<template>
    <div>
        <el-select
            v-model="formData"
            style="width: 200px;"
            @change="updateParent"
        >
            <el-option
                v-for="(item, index) in columnsOptions()"
                :key="index"
                :label="item.label"
                :value="item.value"
            />
        </el-select>
    </div>
</template>

<script>
import {ref} from 'vue';

export default {
    props: {
        modelValue: {
            type: String,
            required: true
        },
        enum: {
            type: String,
            required: true
        }
    },
    emits: ['update:modelValue', 'change'],
    setup(props, {emit}) {
        const formData = ref(props.modelValue);

        const updateParent = () => {
            console.log(formData.value);
            emit('update:modelValue', formData.value);
            emit('change', formData.value);
        };

        const columnsOptions = () => {
            let input = props.enum;
            if (!input) {
                return [];
            }
            const pairs = input.split(',');
            const result = pairs.map(pair => {
                const [key, value] = pair.split(':'); // 按冒号分割
                return {label: value, value: key}; // 构造对象
            });

            return result;
        };
        // watch(
        //     () => props.modelValue,
        //     (newVal) => {
        //         formData.value = {...newVal};
        //     }
        // );

        return {
            columnsOptions,
            formData,
            updateParent
        };
    }
};
</script>

<style lang="scss" scoped>

</style>