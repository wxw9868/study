<template>
    <div>
        <el-form-item
            label="类型"
            :prop="`${parentName}.type`"
            label-width="200"
            label-position="left"
            :rules="[{required: true, message: '请输入类型', trigger: 'change'}]"
        >
            <el-select
                v-model="formData.type"
                style="width: 500px;"
                @change="updateParent"
            >
                <el-option
                    v-for="(item, index) in paramsTypes"
                    :key="index"
                    :label="item.label"
                    :value="item.value"
                />
            </el-select>
        </el-form-item>
        <el-form-item
            v-if="formData.type === 'column'"
            label="是否允许选择多列"
            :prop="`${parentName}.multiple`"
            label-width="200"
            label-position="left"
            :rules="[{required: false, message: '请选择是否允许多选', trigger: 'change'}]"
        >
            <el-switch
                v-model="formData.multiple"
                @input="updateParent"
            />
        </el-form-item>

        <el-form-item
            v-if="formData.type === 'string' || formData.type === 'number' || formData.type === 'enum'"
            label="默认值"
            :prop="`${parentName}.default`"
            label-width="200"
            label-position="left"
            :rules="[{required: false, message: '请输入默认值', trigger: 'change'}]"
        >
            <el-input-number
                v-if="formData.type === 'number'"
                v-model="formData.default"
                @input="updateParent"
            />
            <el-input
                v-else
                v-model="formData.default"
                @input="updateParent"
            />
        </el-form-item>

        <el-form-item
            v-if="formData.type === 'enum'"
            label="枚举值"
            :prop="`${parentName}.enum`"
            label-width="200"
            label-position="left"
            :rules="[{required: true, message: '请输入enum，格式是value:label,value:label', trigger: 'change'}]"
        >
            <el-input
                v-model="formData.enum"
                @input="updateParent"
            />
        </el-form-item>

        <el-form-item
            label="name"
            :prop="`${parentName}.name`"
            label-width="200"
            label-position="left"
            :rules="[{required: true, message: '请输入name', trigger: 'change'}]"
        >
            <el-input
                v-model="formData.name"
                @input="updateParent"
            />
        </el-form-item>
        <el-form-item
            label="label"
            :prop="`${parentName}.label`"
            label-width="200"
            label-position="left"
            :rules="[{required: true, message: '请输入label', trigger: 'change'}]"
        >
            <el-input
                v-model="formData.label"
                @input="updateParent"
            />
        </el-form-item>
        <el-form-item
            label="输入提示"
            :prop="`${parentName}.comment`"
            label-width="200"
            label-position="left"
            :rules="[{required: false, message: '请输入', trigger: 'change'}]"
        >
            <el-input
                v-model="formData.comment"
                @input="updateParent"
            />
        </el-form-item>
        <el-form-item
            v-if="formData.type === 'column_compare' || formData.type === 'column'"
            label="是否仅限制指标列"
            :prop="`${parentName}.isValueOnly`"
            label-width="200"
            label-position="left"
            :rules="[{required: false, message: '请选择', trigger: 'change'}]"
        >
            <el-switch
                v-model="formData.isValueOnly"
                @input="updateParent"
            />
        </el-form-item>
        <el-form-item
            label="是否必须"
            :prop="`${parentName}.isRequired`"
            label-width="200"
            label-position="left"
            :rules="[{required: false, message: '请选择', trigger: 'change'}]"
        >
            <el-switch
                v-model="formData.isRequired"
                @input="updateParent"
            />
        </el-form-item>

        <el-form-item
            label="宽度"
            :prop="`${parentName}.width`"
            label-width="200"
            label-position="left"
            :rules="[{required: false, message: '请输入显示宽度', trigger: 'change'}]"
        >
            <el-input-number
                v-model="formData.width"
                @input="updateParent"
            />
        </el-form-item>
    </div>
</template>

<script>
import {defineComponent, watch, ref} from 'vue';
import config from './config';

export default defineComponent({
    name: 'RuleConfigParams',
    components: {
    },

    props: {
        modelValue: {
            type: Object,
            required: true,
        },
        parentName: {
            type: String,
            required: true,
        }
    },
    emits: ['update:modelValue'],
    setup(props, {emit}) {
        const formData = ref({...props.modelValue});
        const paramsTypes = ref([
            {
                label: 'string',
                value: 'string',
            },
            {
                label: 'number',
                value: 'number',
            },
            {
                label: 'boolean',
                value: 'boolean',
            },
            {
                label: '枚举值',
                value: 'enum',
            },
            {
                label: '选取列',
                value: 'column',
            },
            {
                label: '列比较',
                value: 'column_compare',
            },
            {
                label: '多组列比较',
                value: 'column_compare_list',
            },
        ]);

        watch(
            () => props.modelValue,
            (newVal) => {
                formData.value = {...newVal};
            }
        );

        const updateParent = () => {
            emit('update:modelValue', formData.value);
        };

        return {
            formData,
            paramsTypes,
            updateParent,
        };
    },
    data() {
        return {
            AfsClusterList: config.AfsClusterList,
        };
    },
});
</script>

  <style scoped>
  /* Add your styles here */
  </style>