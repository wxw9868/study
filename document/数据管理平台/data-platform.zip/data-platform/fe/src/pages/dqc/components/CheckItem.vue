<template>
    <div>
        <div v-if="!simple">
            <el-tag style="width: 120px;">
                {{ name }}
            </el-tag>
            <span>开启：</span>
            <el-switch
                v-model="formData.checked"
                @change="updateParent"
            />

            <div
                v-if="formData.checked"
                style="display: inline-block;"
            >
                <span>开启阻断：</span>

                <el-switch

                    v-model="formData.needBlock"
                    @change="updateParent"
                />
                <span v-if="needValue">
                    数值：
                </span>

                <el-input-number
                    v-if="needValue"
                    v-model="formData.value"
                    @input="updateParent"
                />

                <span v-if="needIntervalValue">
                    下限：
                </span>

                <el-input
                    v-if="needIntervalValue"
                    v-model.number="formData.intervalValue[0]"
                    style="width: 100px;"
                    clearable
                    @input="updateParent"
                />
                <span v-if="needIntervalValue">
                    上限：
                </span>
                <el-input
                    v-if="needIntervalValue"
                    v-model.number="formData.intervalValue[1]"
                    style="width: 100px;"
                    clearable
                    @input="updateParent"
                />
            </div>
        </div>
        <div v-else>
            <el-tag
                v-if="formData.checked && !formData.needBlock"
                style="width: 120px;"
                type="warning"
            >
                {{ name }}
            </el-tag>
            <el-tag
                v-if="formData.checked && formData.needBlock"
                style="width: 120px;"
                type="danger"
            >
                {{ name }}
            </el-tag>
        </div>
    </div>
</template>

<script>
import {watch, ref} from 'vue';


export default {
    props: {
        modelValue: {
            type: Object,
            required: true
        },
        name: {type: String, required: true},
        needValue: {type: Boolean, default: false},
        needIntervalValue: {type: Boolean, default: false},
        simple: {type: Boolean, default: false}
    },
    emits: ['update:modelValue'],
    setup(props, {emit}) {
        const formData = ref({...props.modelValue});

        const updateParent = () => {
            emit('update:modelValue', formData.value);
        };

        watch(
            () => props.modelValue,
            (newVal) => {
                formData.value = {...newVal};
            }
        );

        return {

            formData,
            updateParent
        };
    }
};
</script>

<style lang="scss" scoped>

</style>