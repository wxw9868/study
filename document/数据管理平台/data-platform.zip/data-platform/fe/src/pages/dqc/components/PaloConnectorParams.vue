<template>
    <div>
        <el-form-item
            label="IP"
            :prop="`${parentName}.ip`"
            style="width: 500px;"
            label-width="80"
            label-position="left"
            :rules="[{required: true, message: '请输入IP', trigger: 'change'}]"
        >
            <el-input
                v-model="formData.ip"
                @input="updateParent"
            />
        </el-form-item>
        <el-form-item
            label="Port"
            :prop="`${parentName}.port`"
            style="width: 500px;"
            label-width="80"
            label-position="left"
            :rules="[{required: true, message: '请输入Port', trigger: 'change'}]"
        >
            <el-input
                v-model="formData.port"
                type="number"
                @input="updateParent"
            />
        </el-form-item>
        <el-form-item
            label="用户名"
            :prop="`${parentName}.user`"
            style="width: 500px;"
            label-width="80"
            label-position="left"
            :rules="[{required: true, message: '请输入用户名', trigger: 'change'}]"
        >
            <el-input
                v-model="formData.user"
                @input="updateParent"
            />
        </el-form-item>
        <el-form-item
            label="密码"
            :prop="`${parentName}.passwd`"
            style="width: 500px;"
            label-width="80"
            label-position="left"
            :rules="[{required: true, message: '请输入密码', trigger: 'change'}]"
        >
            <el-input
                v-model="formData.passwd"
                @input="updateParent"
            />
        </el-form-item>
        <el-form-item
            label="database"
            :prop="`${parentName}.database`"
            style="width: 500px;"
            label-width="80"
            label-position="left"
            :rules="[{required: true, message: '请输入数据库名', trigger: 'change'}]"
        >
            <el-input
                v-model="formData.database"
                @input="updateParent"
            />
        </el-form-item>
    </div>
</template>

<script>
import {defineComponent, watch, ref} from 'vue';

export default defineComponent({
    name: 'PaloConnectorParams',
    components: {
    },

    props: {
        modelValue: {
            type: Object,
            required: true,
        },
        parentName: {
            type: String,
            required: true,
        }
    },
    emits: ['update:modelValue'],
    setup(props, {emit}) {
        const formData = ref({...props.modelValue});

        watch(
            () => props.modelValue,
            (newVal) => {
                formData.value = {...newVal};
            }
        );

        const updateParent = () => {
            emit('update:modelValue', formData.value);
        };

        return {
            formData,
            updateParent,
        };
    },
    data() {
        return {
        };
    },
});
</script>

  <style scoped>
  /* Add your styles here */
  </style>