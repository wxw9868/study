<template>
    <div>
        <el-container>
            <sidebar :items="sidebarItems" />
            <el-main
                class="sidebar-main"
                style="padding: 0;"
            >
                <el-row>
                    <breadcrumb :data="breadcrumbItems" />
                </el-row>
                <el-row v-loading="loading">
                    <div class="box-row">
                        <el-form
                            ref="form"
                            :model="form"
                            label-width="100"
                            style="width: 100%;"
                            :rules="rules"
                        >
                            <el-form-item
                                label="模型名称"
                                prop="name"

                                style="width: 100%;"
                            >
                                <el-input
                                    v-model="form.name"
                                    :disabled="edit"
                                />
                            </el-form-item>

                            <el-form-item
                                label="中文名称"
                                prop="chname"

                                style="width: 100%;"
                            >
                                <el-input
                                    v-model="form.chname"
                                />
                            </el-form-item>
                            <el-form-item
                                label="模型描述"
                                prop="description"
                            >
                                <el-input
                                    v-model="form.description"
                                    type="text"
                                />
                            </el-form-item>
                            <el-form-item
                                label="类型"
                                prop="type"
                            >
                                <el-select
                                    v-model="form.type"
                                    :disabled="edit"
                                >
                                    <el-option
                                        label="Palo"
                                        value="Palo"
                                    />
                                    <el-option
                                        label="Afs"
                                        value="Afs"
                                    />
                                </el-select>
                            </el-form-item>
                            <el-form-item
                                label="数据源"
                                prop="connectorId"
                            >
                                <el-select
                                    v-model="form.connectorId"
                                >
                                    <el-option
                                        v-for="item in connectorMap[form.type]"
                                        :key="item.value"
                                        :label="item.label"
                                        :value="item.value"
                                    />
                                </el-select>
                            </el-form-item>
                            <el-form-item
                                label="参数"
                                prop="params"
                            >
                                <component
                                    :is="getModelParamsComponent()"
                                    v-model="form.params"
                                    parent-name="params"
                                />
                            </el-form-item>
                            <el-form-item
                                label="列"
                                prop="columns"
                            >
                                <table-column
                                    v-model="form.columns"
                                    parent-name="columns"
                                />
                            </el-form-item>
                            <el-form-item>
                                <el-button
                                    type="primary"
                                    size="large"
                                    @click="submitForm"
                                >
                                    提交
                                </el-button>
                                <el-button
                                    v-if="edit"
                                    size="large"
                                    type="danger"
                                    @click="deleteJob"
                                >
                                    删除
                                </el-button>
                                <el-button
                                    size="large"
                                    @click="cancelForm"
                                >
                                    取消
                                </el-button>
                            </el-form-item>
                        </el-form>
                    </div>
                </el-row>
            </el-main>
        </el-container>
    </div>
</template>

<script>
import * as dqcApi from '../../apis/dqc';
import _ from 'lodash';
import {ElMessage} from 'element-plus';
import config from './config';
import Breadcrumb from '../partial/Breadcrumb';
import Sidebar from '../partial/SideBar';
import AfsModelParams from './components/AfsModelParams';
import PaloModelParams from './components/PaloModelParams';
import TableColumn from './components/TableColumn';

const emptyForm = {
    name: '',
    description: '',
    type: 'Palo',
    columns: [],
    params: {},
};

export default {
    components: {
        Breadcrumb,
        Sidebar,
        AfsModelParams,
        PaloModelParams,
        TableColumn
    },
    beforeRouteEnter(to, from, next) {
        next(vm => {
            vm.init();
        });
    },
    setup() {
        return {};
    },
    data() {
        let meta = this.getMeta(this.$route);
        let sidebar = _.cloneDeep(config.sidebar);
        return {
            loading: false,
            timeoutSign: null,
            form: _.cloneDeep(emptyForm),
            connectorMap: {},
            rules: {
                name: [{
                    required: true,
                    message: '请输入名称'
                }, {
                    validator: this.nameValid,
                    trigger: 'blur'
                }],
                type: [{
                    required: true,
                    message: '请选择类型'
                }],
                connectorId: [{
                    required: true,
                    message: '请绑定数据源'
                }]
            },
            sidebarItems: sidebar,
            breadcrumbItems: meta.breadcrumb,
            edit: meta.edit
        };
    },
    methods: {
        init() {
            this.loadData();
            this.loadConnectors();
        },
        delayLoad() {
            if (this.timeoutSign != null) {
                clearTimeout(this.timeoutSign);
            }
            this.timeoutSign = setTimeout(() => {
                this.timeoutSign = null;
                this.loadTemplate();
            }, 300);
        },
        loadConnectors() {
            dqcApi.connector.get({
                size: 1000
            }).then(res => {
                let data = res.data;
                let connectorMap = {
                    'Palo': [],
                    'Afs': []
                };
                data.forEach(item => {
                    connectorMap[item.type].push({
                        label: item.name,
                        value: item.id,
                    });
                });
                this.connectorMap = connectorMap;
            });
        },
        loadData() {
            if (this.$route.query.id) {
                this.loading = true;
                dqcApi.model.get({
                    id: this.$route.query.id
                }).then(data => {
                    if (data.data.length === 0) {
                        ElMessage.error('数据不存在');
                        return;
                    }
                    this.form = data.data[0];
                    this.loading = false;
                });
            } else {
                return;
            }
        },

        getMeta(route) {
            let breadcrumb = _.cloneDeep(config.breadcrumb);
            let edit = !!route.query.id;
            if (edit) {
                breadcrumb.push({
                    path: '/dqc/model_edit',
                    title: '编辑数据'
                });
            } else {
                breadcrumb.push({
                    path: '/dqc/model_edit',
                    title: '新建数据'
                });
            }
            return {
                breadcrumb,
                edit
            };
        },
        submitForm() {
            this.$refs.form.validate(valid => {
                if (valid) {
                    if (this.form.id != null) {
                        dqcApi.model.patch(this.form.id, this.form).then(res => {
                            if (res.status === 0) {
                                this.$router.push('/dqc/model_list').catch(() => {});
                            }
                        });
                    } else {
                        dqcApi.model.post(this.form).then(res => {
                            if (res.status === 0) {
                                this.$router.push('/dqc/model_list').catch(() => {});
                            }
                        });
                    }
                } else {
                    ElMessage.error('表单验证失败');
                }
            });
        },
        cancelForm() {
            this.$router.push('/dqc/model_list').catch(() => {});
        },
        nameValid(rule, value, callback) {
            if (!/^[a-zA-Z0-9_.]*$/.test(value)) {
                callback(new Error('请输入合法字符：[a-zA-Z0-9_.]'));
                return;
            }
            callback();
        },
        deleteJob() {
            let id = this.$route.query.id;
            this.$confirm(`确认删除id=${id}模型么？`, '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'error'
            }).then(() => {
                dqcApi.model.delete({
                    pdb: this.$route.query.pdb,
                    id: id
                }).then(res => {
                    if (res.status === 0) {
                        this.$router.push('/dqc/model_list').catch(() => {});
                    }
                });
            });
        },
        getModelParamsComponent() {
            return config.modelComponentMap[this.form.type];
        }
    }
};
</script>

<style lang="scss" scoped>

</style>