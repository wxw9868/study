<template>
    <div>
        <div>
            <el-button
                type="success"
                @click="addColumn"
            >
                添加列
            </el-button>
            <el-button
                type="warning"
                @click="addBySql"
            >
                通过建表语句导入
            </el-button>
        </div>
        <el-table
            :data="formData"
            style="width: 100%"
        >
            <el-table-column
                label="列"
                prop="column"
                width="150"
            />
            <el-table-column
                label="列名（用于展示）"
                prop="name"
                width="180"
            />
            <el-table-column
                label="是否复合列"
                prop="composite"
                width="180"
            >
                <template #default="scope">
                    <el-tag v-if="!scope.row.isValue">
                        维度
                    </el-tag>
                    <el-tag
                        v-else
                        type="success"
                    >
                        指标
                    </el-tag>
                </template>
            </el-table-column>
            <el-table-column
                label="是否指标列"
                prop="isValue"
                width="180"
            >
                <template #default="scope">
                    <el-switch
                        v-model="scope.row.isValue"
                    />
                </template>
            </el-table-column>
            <el-table-column
                label="类型"
                width="120"
            >
                <template #default="scope">
                    <el-tag :type="TypeElTagTypeMap[scope.row.type]">
                        {{ scope.row.type }}
                    </el-tag>
                </template>
            </el-table-column>
            <el-table-column
                label="操作"
                width="200"
            >
                <template #default="scope">
                    <el-button
                        size="small"
                        @click="handleEdit(scope.$index, scope.row)"
                    >
                        Edit
                    </el-button>
                    <el-button
                        size="small"
                        type="danger"
                        @click="handleDelete(scope.$index, scope.row)"
                    >
                        Delete
                    </el-button>
                </template>
            </el-table-column>
        </el-table>


        <el-dialog
            v-model="dialogTableVisible"
            title="添加列"
            width="1100"
        >
            <div>
                <el-form
                    ref="columnForm"
                    :model="form"
                    :rules="formRules"
                    width="1100"
                    label-width="100px"
                >
                    <el-form-item
                        prop="column"
                        label="字段"
                    >
                        <el-input v-model="form.column" />
                    </el-form-item>

                    <el-form-item
                        prop="name"
                        label="字段名"
                    >
                        <el-input v-model="form.name" />
                    </el-form-item>

                    <el-form-item
                        prop="isValue"
                        label="是否指标列"
                    >
                        <el-switch v-model="form.isValue" />
                    </el-form-item>

                    <el-form-item
                        prop="isDate"
                        label="是否日期列"
                    >
                        <el-switch v-model="form.isDate" />
                    </el-form-item>

                    <el-form-item
                        v-if="form.isDate"
                        prop="dateFormat"
                        label="日期格式"
                    >
                        <el-input v-model="form.dateFormat" />
                    </el-form-item>

                    <el-form-item
                        prop="isHour"
                        label="是否小时列"
                    >
                        <el-switch v-model="form.isHour" />
                    </el-form-item>

                    <el-form-item
                        prop="isMinute"
                        label="是否分钟列"
                    >
                        <el-switch v-model="form.isMinute" />
                    </el-form-item>

                    <el-form-item
                        prop="composite"
                        label="是否复合列"
                    >
                        <el-switch v-model="form.composite" />
                    </el-form-item>
                    <el-form-item
                        v-if="form.composite"
                        prop="formula"
                        label="公式"
                    >
                        <el-input v-model="form.formula" />
                    </el-form-item>
                    <el-form-item
                        label="数据类型"
                        prop="type"
                    >
                        <el-select
                            v-model="form.type"
                            placeholder="数据类型"
                        >
                            <el-option
                                v-for="item in TypeList"
                                :key="item.value"
                                :label="item.name"
                                :value="item.value"
                            />
                        </el-select>
                    </el-form-item>
                    <el-form-item>
                        <el-button
                            type="primary"
                            @click="onSubmit"
                        >
                            确认
                        </el-button>
                        <el-button @click="dialogTableVisible=false">
                            取消
                        </el-button>
                    </el-form-item>
                </el-form>
            </div>
        </el-dialog>


        <el-dialog
            v-model="dialogMultiRowVisible"
            title="从建表SQL中解析"
            width="800"
        >
            <el-form :model="multiRowFormData">
                <el-form-item
                    label=""
                    label-width="0"
                >
                    <el-input
                        v-model="multiRowFormData.sql"
                        autocomplete="off"
                        type="textarea"
                        placeholder="Create table xx..."
                        :autosize="{ minRows: 10 }"
                    />
                </el-form-item>
            </el-form>
            <template #footer>
                <div class="dialog-footer">
                    <el-button @click="dialogMultiRowVisible = false">
                        取消
                    </el-button>
                    <el-button
                        type="primary"
                        @click="confirmParseSQL"
                    >
                        确认
                    </el-button>
                </div>
            </template>
        </el-dialog>
        <el-dialog
            v-model="dialogPreviewVisible"
            title="解析出的字段预览"
            width="800"
        >
            <el-table :data="previewTableData">
                <el-table-column
                    prop="name"
                    label="字段"
                />
                <el-table-column
                    prop="type"
                    label="类型"
                />
            </el-table>
            <template #footer>
                <div class="dialog-footer">
                    <el-button @click="dialogPreviewVisible = false">
                        取消
                    </el-button>
                    <el-button
                        type="primary"
                        @click="confirmPreviewData"
                    >
                        确认
                    </el-button>
                </div>
            </template>
        </el-dialog>
    </div>
</template>

<script>
import {defineComponent, watch, ref, unref} from 'vue';
import config from './config';
import {ElMessage, ElMessageBox} from 'element-plus';
import * as dqcApi from '../../../apis/dqc';
import _ from 'lodash';

const emptyForm = {
    'column': '',
    'name': '',
    'type': '',
    'required': false,
    'isDate': false,
    'isHour': false,
    'isMinute': false,
    'isValue': false,
    'dateFormat': '%Y-%m-%d'
};

export default defineComponent({
    name: 'TableColumn',
    components: {
    },
    props: {
        modelValue: {
            type: Array,
            required: true,
        },
        parentName: {
            type: String,
            required: true,
        }
    },
    emits: ['update:modelValue'],
    setup(props, {emit}) {

        const formData = ref(JSON.parse(JSON.stringify(props.modelValue)));
        const updateParent = () => {
            emit('update:modelValue', formData.value);
        };
        if (!Array.isArray(formData.value)) {
            formData.value = [];
            updateParent();
        }
        const form = ref(_.cloneDeep(emptyForm));
        const dialogTableVisible = ref(false);
        const editIndex = ref(-1);
        const columnForm = ref(null);
        const dialogMultiRowVisible = ref(false);
        const dialogPreviewVisible = ref(false);
        const multiRowFormData = ref({
            sql: '',
        });
        const previewTableData = ref([]);
        const replacedColumns = ref([]);
        const ruleMap = ref(config.RuleMap);

        const compositeChange = (index, value) => {
            if (value) {
                formData.value[index].required = false;
            }
        };

        const formulaValid = (rule, value, callback) => {
            let vals = {};
            formData.value.forEach((item) => {
                if (item.composite) {
                    return;
                }
                vals[item.column] = item.type;
            });
            dqcApi.meta.checkFormula({
                formula: value,
                vals: vals
            }).then(data => {
                if (data.status === 0 && data.data === true) {
                    callback();
                } else {
                    callback(new Error(data.msg));
                }
            }).catch(err => {
                callback(new Error('公式错误'));
            });
        };


        const formRules = ref({
            column: [
                {required: true, message: '请输入字段', trigger: 'blur'},
            ],
            name: [
                {required: true, message: '请输入字段名', trigger: 'blur'},
            ],
            type: [
                {required: true, message: '请选择数据类型', trigger: 'change'},
            ],
            formula: [
                {required: true, message: '请输入公式', trigger: 'blur'},
                {
                    validator: formulaValid,
                    trigger: 'blur'
                }
            ],
        });
        const handleEdit = (index, row) => {
            editIndex.value = index;
            form.value.column = row.column;
            form.value.name = row.name;
            form.value.type = row.type;
            form.value.required = row.required;
            form.value.composite = row.composite;
            form.value.formula = row.formula;
            form.value.isDate = row.isDate;
            form.value.isHour = row.isHour;
            form.value.isMinute = row.isMinute;
            form.value.isValue = row.isValue;
            form.value.dateFormat = row.dateFormat;
            dialogTableVisible.value = true;
        };

        const handleDelete = (index, row) => {
            formData.value.splice(index, 1);
            updateParent();
        };

        const onSubmit = () => {
            columnForm.value.validate((valid) => {
                if (!valid) {
                    return;
                }
                if (editIndex.value > -1) {
                    formData.value[editIndex.value] = _.cloneDeep(unref(form.value));
                    editIndex.value = -1;
                } else {
                    formData.value.push(_.cloneDeep(unref(form.value)));
                }
                dialogTableVisible.value = false;
                updateParent();
            });
        };

        const addColumn = () => {
            form.value = _.cloneDeep(emptyForm);
            editIndex.value = -1;
            dialogTableVisible.value = true;
        };

        const addBySql = () => {
            dialogMultiRowVisible.value = true;
        };

        const confirmParseSQL = () => {
            dialogMultiRowVisible.value = true;
            dqcApi.meta.parseSql({
                sql: multiRowFormData.value.sql,
            }).then((res) => {
                previewTableData.value = res.data.column;
                replacedColumns.value = res.data.column;
                dialogPreviewVisible.value = true;
            });
        };

        const confirmPreviewData = () => {
            ElMessageBox.confirm(
                '确认后将清空之前已经填写的内容，是否继续？',
                'Warning',
                {
                    confirmButtonText: '确认',
                    cancelButtonText: '取消',
                    type: 'warning',
                }
            ).then(() => {
                let columns = [];
                replacedColumns.value.forEach((item) => {
                    columns.push({
                        column: item.name,
                        name: item.name,
                        type: item.type,
                        required: false,
                        composite: false,
                    });
                });
                formData.value = columns;
                updateParent();
                dialogPreviewVisible.value = false;
                dialogMultiRowVisible.value = false;
            }).catch(err => {
                console.log(err);
                ElMessage({
                    type: 'info',
                    message: '已放弃',
                });
                dialogPreviewVisible.value = false;
                dialogMultiRowVisible.value = false;
            });
        };

        watch(
            () => props.modelValue,
            (newVal) => {
                formData.value = [...newVal];
            }
        );

        return {
            formData,
            form,
            formRules,
            ruleMap,
            handleEdit,
            handleDelete,
            onSubmit,
            addBySql,
            updateParent,
            addColumn,
            confirmParseSQL,
            confirmPreviewData,
            compositeChange,
            multiRowFormData,
            columnForm,
            previewTableData,
            dialogTableVisible,
            dialogMultiRowVisible,
            dialogPreviewVisible,
        };
    },
    data() {
        return {
            RuleList: config.RuleList,
            TypeElTagTypeMap: config.TypeElTagTypeMap,
            RuleMap: config.RuleMap,
            TypeList: config.TypeList,
        };
    },
});
</script>

  <style scoped>
  /* Add your styles here */

    .check-item {
        width: 80%;

    }
  .el-form-item {
    margin-bottom: 15px;
  }
  </style>