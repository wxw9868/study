export default {
    RuleList: [
        {
            value: 'nullcheck',
            name: '空值检测'
        },
        {
            value: 'distinct',
            name: '唯一值检测'
        },
        {
            value: 'range',
            name: '范围检测'
        }
    ],
    RuleMap: {
        nullcheck: {
            name: '空值检测',
            color: '#409EFF',
            needValue: false,
            needIntervalValue: false,
            value: {
                checked: false,
                needBlock: false
            }
        },
        distinct: {
            name: '唯一值检测',
            color: '#67C23A',
            needValue: false,
            needIntervalValue: false,
            value: {
                checked: false,
                needBlock: false
            }
        },
        range: {
            name: '范围检测',
            color: '#E6A23C',
            needValue: false,
            needIntervalValue: true,
            value: {
                checked: false,
                needBlock: false,
                value: 0,
                intervalValue: [0, 0]
            }
        }
    },
    TypeList: [
        {
            name: 'string',
            value: 'string'
        },
        {
            name: 'int',
            value: 'int'
        },
        {
            name: 'bool',
            value: 'bool'
        },
        {
            name: 'float',
            value: 'float'
        },
        {
            name: 'double',
            value: 'double'
        }
    ],
    // 一个Object，key是数据库中的数据类型，value是element-ui中对应的颜色
    TypeElTagTypeMap: {
        string: 'info',
        int: 'success',
        bool: 'warning',
        float: 'danger',
        double: 'primary',
        undefined: ''
    },
    AfsClusterList: [
        {
            name: 'wudang',
            path: 'afs://wudang.afs.baidu.com:9902'
        },
        {
            name: 'wolong',
            path: 'afs://wolong.afs.baidu.com:9902'
        },
        {
            name: 'kunpeng',
            path: 'afs://kunpeng.afs.baidu.com:9902'
        },
        {
            name: 'baihua',
            path: 'afs://baihua.afs.baidu.com:9902'
        },
        {
            name: 'cnn-bd-main',
            path: 'afs://cnn-bd-main.afs.baidu.com:9902',
        },
        {
            name: 'xingtian',
            path: 'afs://xingtian.afs.baidu.com:9902'
        }
    ]
};