<template>
    <div>
        <div
            v-for="(col, index) in formData"
            :key="index"
        >
            <column-compare
                :key="col.id"
                v-model="formData[index]"
                :only-value-column="true"
                :columns="columns"

                @change="updateParent"
            />
            <el-button
                v-if="formData.length > 1"
                class="delete-btn"
                @click="removeGroup(index)"
            >
                删除
            </el-button>
        </div>
        <el-button
            class="add-btn"
            @click="addGroup"
        >
            添加新组
        </el-button>
    </div>
</template>

<script>
import ColumnCompare from './ColumnCompare.vue';
import {watch, ref} from 'vue';

export default {
    components: {
        ColumnCompare
    },
    props: {
        modelValue: {
            type: Array,
            required: true
        },
        columns: {
            type: Array,
            required: true
        },
        onlyValueColumn: {
            type: Boolean,
            default: false
        },
    },
    emits: ['update:modelValue', 'change'],
    setup(props, {emit}) {
        const formData = ref([]);
        const incrKey = ref(1);
        if (props.modelValue === undefined) {
            formData.value = [{id: incrKey.value++}];
        } else {
            formData.value = [...props.modelValue];
        }
        if (!Array.isArray(formData.value) || formData.value.length === 0) {
            formData.value = new Array(1).fill({
                id: incrKey.value
            });
        }

        const updateParent = () => {
            emit('update:modelValue', formData.value);
            emit('change');
        };

        // 添加新组
        const addGroup = () => {
            formData.value.push({id: ++incrKey.value});
            updateParent();
        };

        // 删除指定组
        const removeGroup = (index) => {
            formData.value.splice(index, 1);
            updateParent();
        };

        watch(
            () => props.modelValue,
            (newVal) => {
                formData.value = [...newVal];
            }
        );

        return {
            formData,
            addGroup,
            removeGroup,
            updateParent,
        };
    }
};
</script>

<style lang="scss" scoped>
.inline-form-items {
  display: flex;
  flex-wrap: wrap; /* 如果空间不足，允许换行 */
  gap: 10px; /* 控制每组之间的间距 */
  align-items: center; /* 垂直居中对齐 */
}

.form-group {
  display: flex;
  align-items: center; /* 确保 column-select 和 el-select 垂直居中 */
  gap: 5px; /* 控制 column-select 和 el-select 之间的间距 */
}

.inline-form-items .el-form-item {
  margin-bottom: 0; /* 移除默认的底部边距 */
  flex-shrink: 0; /* 防止元素缩小过多 */
}

.inline-form-items .el-input,
.inline-form-items .el-button,
.inline-form-items .el-checkbox {
  font-size: 12px; /* 调整字体大小以使其更紧凑 */
}
</style>