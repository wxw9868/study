<template>
    <div>
        <el-container>
            <sidebar :items="sidebarItems" />
            <el-main
                class="sidebar-main"
                style="padding: 0;"
            >
                <el-row>
                    <breadcrumb :data="breadcrumbItems" />
                </el-row>
                <el-row class="filter-row">
                    <el-form
                        :inline="true"
                        :model="filterForm"
                    >
                        <el-form-item label="查询">
                            <el-input
                                v-model="filterForm.word"
                                style="width: 260px;"
                                placeholder="请输入task名称进行模糊检索"
                                @input="delayLoad"
                            />
                        </el-form-item>
                        <el-form-item label="任务状态">
                            <el-select
                                v-model="filterForm.status"
                                style="width: 260px;"
                                @change="delayLoad"
                            >
                                <el-option
                                    v-for="(item, index) in statusList"
                                    :key="index"
                                    :value="item.value"
                                    :label="item.label"
                                />
                            </el-select>
                        </el-form-item>
                        <el-form-item label="DQC状态">
                            <el-select
                                v-model="filterForm.dqcStatus"
                                style="width: 260px;"
                                @change="delayLoad"
                            >
                                <el-option
                                    v-for="(item, index) in dqcStatusList"
                                    :key="index"
                                    :value="item.value"
                                    :label="item.label"
                                />
                            </el-select>
                        </el-form-item>
                    </el-form>
                </el-row>
                <el-row class="button-row">
                    <el-button
                        type="success"
                        @click="addData"
                    >
                        <el-icon class="el-icon--left">
                            <Plus />
                        </el-icon>
                        添加task
                    </el-button>
                </el-row>
                <el-row>
                    <el-table
                        v-loading="loading"
                        :data="jobData"
                        empty-text="暂无数据"
                        border
                        style="width: 100%;"
                    >
                        <el-table-column
                            prop="id"
                            label="任务ID"
                        />
                        <el-table-column
                            prop="title"
                            label="名称"
                        />
                        <el-table-column
                            prop="description"
                            label="描述"
                        />
                        <el-table-column
                            label="任务状态"
                        >
                            <template #default="scope">
                                <el-tag :type="statusMap[scope.row.status].type">
                                    {{ statusMap[scope.row.status].label }}
                                </el-tag>
                            </template>
                        </el-table-column>
                        <el-table-column
                            label="Dqc状态"
                        >
                            <template #default="scope">
                                <el-tag :type="dqcStatusMap[scope.row.dqcStatus].type">
                                    {{ dqcStatusMap[scope.row.dqcStatus].label }}
                                </el-tag>
                            </template>
                        </el-table-column>
                        <el-table-column
                            prop="creator"
                            label="创建人"
                        />
                        <el-table-column
                            prop="triggerSource"
                            label="任务来源"
                        />
                        <el-table-column
                            label="任务类型"
                        >
                            <template #default="scope">
                                <el-tag v-if="scope.row.dataIds.length === 1">
                                    单表任务
                                </el-tag>
                                <el-tag
                                    v-else
                                    type="success"
                                >
                                    多表任务
                                </el-tag>
                            </template>
                        </el-table-column>
                        <el-table-column
                            prop="modifier"
                            label="最近修改人"
                        />
                        <el-table-column
                            label="操作"
                            width="250px"
                        >
                            <template #default="scope">
                                <div>
                                    <el-button
                                        type="primary"
                                        size="small"
                                        @click="editMeta(scope.row.id)"
                                    >
                                        编辑
                                    </el-button>
                                    <el-button
                                        type="info"
                                        size="small"
                                        @click="startViewProgress(scope.row.id)"
                                    >
                                        查看进度
                                    </el-button>
                                    <el-button
                                        v-if="scope.row.status === 2"
                                        type="success"
                                        size="small"
                                        @click="viewReport(scope.row.id)"
                                    >
                                        查看报告
                                    </el-button>
                                    <el-button
                                        v-if="taskWithChildren[scope.row.id]"
                                        type="success"
                                        size="small"
                                        @click="viewChildren(scope.row.id)"
                                    >
                                        查看实例
                                    </el-button>
                                </div>
                            </template>
                        </el-table-column>
                    </el-table>
                    <el-pagination
                        v-model:current-page="page"
                        v-model:page-size="size"
                        :page-sizes="[10, 20, 50, 100]"
                        :total="total"
                        background
                        layout="sizes, prev, pager, next"
                        @size-change="loadData"
                        @current-change="loadData"
                    />
                </el-row>
            </el-main>
        </el-container>
        <el-dialog
            v-model="dialogModelChooseVisible"
            title="选择要校检的模型"
            width="1000"
        >
            <el-select
                v-model="curDataId"
                style="width: 240px"
                filterable
                large
            >
                <el-option
                    v-for="(mitem, mindex) in modelList"
                    :key="mindex"
                    :label="mitem.name"
                    :value="mitem.id"
                    :disabled="chooseDataIds.find(v=>v==mitem.id) !== undefined"
                >
                    <span style="float: left">
                        {{ modelMap[mitem.id].chname }}
                        <el-tag
                            v-if="mitem.type==='Afs'"
                            type="danger"
                        >
                            {{ modelMap[mitem.id].type }}
                        </el-tag>
                        <el-tag v-else>
                            {{ modelMap[mitem.id].type }}
                        </el-tag>
                    </span>
                    <span
                        style="float: right;color: var(--el-text-color-secondary);font-size: 13px;"
                    >
                        {{ modelMap[mitem.id].name }}
                    </span>
                </el-option>
            </el-select>
            <el-button @click="addDataIds">
                确认添加
            </el-button>

            <div>
                <el-card
                    class="custom-card"
                >
                    <template #header>
                        <div class="card-header">
                            <el-tag type="success">
                                当前所选模型
                            </el-tag>
                        </div>
                    </template>
                    <div class="card-content">
                        <vue-draggable
                            v-model="chooseDataIds"
                            class="draggable-list"
                        >
                            <el-row
                                v-for="(id, index) in chooseDataIds"
                                :key="index"
                                class="draggable-item"
                            >
                                <el-col :span="8">
                                    {{ modelMap[id].chname }}
                                </el-col>
                                <el-col :span="4">
                                    <el-tag
                                        v-if="modelMap[id].type==='Afs'"
                                        type="danger"
                                    >
                                        {{ modelMap[id].type }}
                                    </el-tag>
                                    <el-tag v-else>
                                        {{ modelMap[id].type }}
                                    </el-tag>
                                </el-col>
                                <el-col :span="8">
                                    <span class="model-name">{{ modelMap[id].name }}</span>
                                </el-col>
                                <el-col :span="4">
                                    <el-button
                                        type="danger"
                                        size="mini"
                                        class="delete-button"
                                        @click="deleteChooseId(index)"
                                    >
                                        删除
                                    </el-button>
                                </el-col>
                            </el-row>
                        </vue-draggable>
                    </div>
                    <template #footer>
                        <span class="footer-text">可以通过拖拽调整模型顺序</span>
                    </template>
                </el-card>
            </div>
            <div>
                <el-button
                    v-if="chooseDataIds.length > 0"
                    type="success"
                    @click="confirmAdd"
                >
                    以当前所选数据新增任务
                </el-button>
            </div>
        </el-dialog>

        <el-dialog
            v-model="centerDialogVisible"
            :title="`任务进度 id=${curTaskId}`"
            width="800"
            align-center
            @close="stopViewProgress"
        >
            <span><pre>{{ progress }}</pre></span>
            <template #footer>
                <div class="dialog-footer">
                    <el-button
                        type="primary"
                        @click="centerDialogVisible = false"
                    >
                        确认
                    </el-button>
                </div>
            </template>
        </el-dialog>
    </div>
</template>

<script>
import Breadcrumb from '../partial/Breadcrumb';
import Sidebar from '../partial/SideBar';
import config from './config';
import {VueDraggable} from 'vue-draggable-plus';

import * as dqcApi from '../../apis/dqc';

import {useDateFormatter} from '../common/date';


import _ from 'lodash';

export default {
    components: {
        Breadcrumb,
        Sidebar,
        VueDraggable
    },
    beforeRouteEnter(to, from, next) {
        next(vm => {
            vm.init();
        });
    },
    setup() {
        const dateFormatter = useDateFormatter();
        return {dateFormatter};
    },
    data: function () {
        let sidebar = _.cloneDeep(config.sidebar);
        return {
            timeoutSign: null,
            loading: true,
            jobData: [],
            filterForm: {
                word: '',
                status: null,
                dqcStatus: null,
            },
            onlyUser: '',
            sidebarItems: sidebar,
            breadcrumbItems: [],
            page: 1,
            size: 10,
            total: 10,
            echo: 0,
            dialogTableVisible: false,
            dialogModelChooseVisible: false,
            modelList: [],
            modelMap: {},
            chooseDataIds: [],
            curDataId: null,
            statusList: config.statusList,
            statusMap: config.statusMap,
            dqcStatusList: config.dqcStatusList,
            dqcStatusMap: config.dqcStatusMap,
            progress: '',
            centerDialogVisible: false,
            curTaskId: null,
            intervalId: null,
            isRequesting: false,
            taskWithChildren: {}
        };
    },
    computed: {
    },
    methods: {
        init() {
            let meta = this.getMeta(this.$route);
            this.onlyUser = meta.onlyUser;
            this.page = 1;
            this.breadcrumbItems = meta.breadcrumb;
            this.loadData();
            this.loadModel();

        },
        viewReport(id) {
            this.$router.push({
                path: '/dqc/result_view',
                query: {
                    id,
                }
            }).catch(() => {});
        },
        viewChildren(id) {
            this.$router.push({
                path: '/dqc/task_children_list',
                query: {
                    fatherID: id,
                    id: this.$route.query.id,
                }
            }).catch(() => {});
        },
        loadModel() {
            this.modelMap = {};
            dqcApi.model.get({
                size: 1000,
            }).then(data => {
                this.modelList = data.data;
                this.modelList.forEach(item => {
                    this.modelMap[item.id] = item;
                });
            });
        },
        loadData() {
            this.loading = true;
            this.taskWithChildren = {};
            this.echo++;
            let fatherID = 0;
            if (this.$route.query.fatherID) {
                fatherID = this.$route.query.fatherID;
            }
            let query = {
                pdb: this.$route.query.pdb,
                search: this.filterForm.word,
                page: this.page,
                size: this.size,
                echo: this.echo,
                jobId: this.$route.query.id,
                fatherID: fatherID,
            };
            if (this.onlyUser) {
                query.owner = this.user.username;
            }
            if (this.filterForm.status !== null) {
                query.status = this.filterForm.status;
            }
            if (this.filterForm.dqcStatus !== null) {
                query.dqcStatus = this.filterForm.dqcStatus;
            }
            dqcApi.task.get(query).then(res => {
                let ids = [];
                if (res.status === 0 && res.echo === this.echo) {
                    this.jobData = res.data;
                    this.total = res.total;
                    ids = res.data.map(item => item.id);
                }
                this.loading = false;
                return ids;
            }).then(ids => {
                dqcApi.task.taskWithChildren(ids.join(',')).then(res => {
                    res.data.forEach(item => {
                        this.taskWithChildren[item.FatherID] = item.Count;
                    });
                });
            });
        },
        delayLoad() {
            if (this.timeoutSign != null) {
                clearTimeout(this.timeoutSign);
            }
            this.timeoutSign = setTimeout(() => {
                this.timeoutSign = null;
                this.page = 1;
                this.loadData();
            }, 300);
        },
        viewProgress(id) {
            dqcApi.task.get({id: id}).then(res => {
                if (res.status === 0) {
                    this.progress = res.data[0].progress;
                    this.centerDialogVisible = true;
                    this.curTaskId = id;
                }
            });
        },
        startViewProgress(id) {
            // 防止重复启动
            if (this.intervalId) {
                console.warn('Request is already in progress');
                return;
            }
            this.isRequesting = true; // 开始请求
            this.curTaskId = id;
            this.centerDialogVisible = true; // 打开对话框（如果需要）

            // 定义请求方法
            const fetchProgress = () => {
                dqcApi.task.get({id: id}).then(res => {
                    if (res.status === 0) {
                        this.progress = res.data[0].progress;

                        // 检查状态是否为非0或非1，结束请求
                        if (res.data[0].status !== 0 && res.data[0].status !== 1) {
                            this.stopViewProgress();
                        }
                    } else {
                        // 如果接口返回非0状态，也可以考虑停止请求
                        this.stopViewProgress();
                    }
                }).catch(error => {
                    console.error('Error fetching progress:', error);
                    this.stopViewProgress(); // 遇到错误也停止请求
                });
            };

            // 立即调用一次，然后每两秒调用一次
            fetchProgress();
            this.intervalId = setInterval(fetchProgress, 2000);
        },
        stopViewProgress() {
            if (this.intervalId) {
                console.warn('stop view progress');
                clearInterval(this.intervalId); // 清除定时器
                this.intervalId = null;
            }
            this.isRequesting = false; // 停止请求标志
        },

        addData() {
            this.dialogModelChooseVisible = true;
            this.chooseDataIds = [];
        },
        addDataIds() {
            if (this.curDataId !== null) {
                this.chooseDataIds.push(this.curDataId);
                this.curDataId = null;
            }
        },
        deleteChooseId(index) {
            this.chooseDataIds.splice(index, 1);
        },
        confirmAdd() {
            console.log(this.chooseDataIds.join(','));
            this.$router.push({
                path: '/dqc/task_edit',
                query: {
                    dataIds: this.chooseDataIds.join(','),
                    jobId: this.$route.query.id,
                }}).catch(() => {});
        },
        editMeta(id) {
            this.$router.push({
                path: '/dqc/task_edit',
                query: {
                    id,
                    jobId: this.$route.query.id
                }
            }).catch(() => {});
        },
        getMeta(route) {
            let breadcrumb = _.cloneDeep(config.breadcrumb);
            let onlyUser = route.matched.some(record => record.meta.onlyUser);

            breadcrumb.push({
                path: '/dqc/task_list',
                title: '任务列表'
            });
            return {
                onlyUser,
                breadcrumb
            };
        }
    }
};
</script>

<style scoped>

pre {
    white-space: pre-wrap; /* 允许自动换行 */
    word-wrap: break-word; /* 兼容旧浏览器，确保长单词也能换行 */
}

.custom-card {
    border: 1px solid #ebeef5;
    border-radius: 8px;
    box-shadow: 0 2px 12px rgba(0, 0, 0, 0.1);
    overflow: hidden;
}

/* 标题样式 */
.card-header {
    display: flex;
    align-items: center;
    font-size: 16px;
    font-weight: bold;
    color: #333;
}

/* 内容区域样式 */
.card-content {
    padding: 10px 0;
}

/* 拖拽列表样式 */
.draggable-list {
    min-height: 50px;
}

/* 拖拽项样式 */
.draggable-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 8px 12px;
    margin-bottom: 8px;
    background: #f9f9f9;
    border: 1px solid #ebeef5;
    border-radius: 4px;
    transition: all 0.3s ease;
}

.draggable-item:hover {
    background: #f0f0f0;
    border-color: #dcdfe6;
}

/* 模型名称样式 */
.model-name {
    font-size: 14px;
    color: #606266;
}

/* 删除按钮样式 */
.delete-button {
    margin-left: 10px;
}

/* 页脚文本样式 */
.footer-text {
    font-size: 12px;
    color: #909399;
    text-align: center;
}
</style>