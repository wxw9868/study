<template>
    <div>
        <el-form-item
            label="集群"
            :prop="`${parentName}.cluster`"
            style="width: 500px;"
            label-width="80"
            label-position="left"
            :rules="[{required: true, message: '请选择集群', trigger: 'change'}]"
        >
            <el-select
                v-model="formData.cluster"
                filterable
                @change="updateParent"
            >
                <el-option
                    v-for="item in AfsClusterList"
                    :key="item.path"
                    :label="item.name"
                    :value="item.path"
                />
            </el-select>
        </el-form-item>

        <el-form-item
            label="UGI"
            :prop="`${parentName}.ugi`"
            style="width: 500px;"
            label-width="80"
            label-position="left"
            :rules="[{required: true, message: '请输入ugi', trigger: 'change'}]"
        >
            <el-input
                v-model="formData.ugi"
                placeholder="user,passwd"
                @input="updateParent"
            />
        </el-form-item>
    </div>
</template>

<script>
import {defineComponent, watch, ref} from 'vue';
import config from './config';

export default defineComponent({
    name: 'AfsConnectorParams',
    components: {
    },

    props: {
        modelValue: {
            type: Object,
            required: true,
        },
        parentName: {
            type: String,
            required: true,
        }
    },
    emits: ['update:modelValue'],
    setup(props, {emit}) {
        const formData = ref({...props.modelValue});

        watch(
            () => props.modelValue,
            (newVal) => {
                formData.value = {...newVal};
            }
        );

        const updateParent = () => {
            emit('update:modelValue', formData.value);
        };

        return {
            formData,
            updateParent,
        };
    },
    data() {
        return {
            AfsClusterList: config.AfsClusterList,
        };
    },
});
</script>

  <style scoped>
  /* Add your styles here */
  </style>