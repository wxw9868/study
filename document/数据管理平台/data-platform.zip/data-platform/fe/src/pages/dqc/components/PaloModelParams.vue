<template>
    <div>
        <el-form-item
            label="表名"
            :prop="`${parentName}.table_name`"
            style="width: 500px;"
            label-width="100"
            label-position="left"
            :rules="[{required: true, message: '请输入表名', trigger: 'change'}]"
        >
            <el-input
                v-model="formData.table_name"
                @input="updateParent"
            />
        </el-form-item>
        <el-form-item
            label="汇总值"
            :prop="`${parentName}.aggr_key`"
            style="width: 500px;"
            label-width="100"
            label-position="left"
            :rules="[{required: false, message: '请输入汇总值', trigger: 'change'}]"
        >
            <el-input
                v-model="formData.aggr_key"
                @input="updateParent"
            />
        </el-form-item>
    </div>
</template>

<script>
import {defineComponent, watch, ref} from 'vue';
import config from './config';

export default defineComponent({
    name: 'AfsParams',
    components: {
    },

    props: {
        modelValue: {
            type: Object,
            required: true,
        },
        parentName: {
            type: String,
            required: true,
        }
    },
    emits: ['update:modelValue'],
    setup(props, {emit}) {
        const formData = ref({...props.modelValue});

        watch(
            () => props.modelValue,
            (newVal) => {
                formData.value = {...newVal};
            }
        );

        const updateParent = () => {
            emit('update:modelValue', formData.value);
        };

        return {
            formData,
            updateParent,
        };
    },
    data() {
        return {
            AfsClusterList: config.AfsClusterList,
        };
    },
});
</script>

  <style scoped>
  /* Add your styles here */
  </style>