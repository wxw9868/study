export default {
    sidebar: [{
        name: '数据列表【旧】',
        index: '/dqc/list',
        icon: 'el-icon-s-cooperation'
    }, {
        name: '数据源管理',
        index: '/dqc/connector_list',
        icon: 'el-icon-s-cooperation'
    }, {
        name: '数据模型管理',
        index: '/dqc/model_list',
        icon: 'el-icon-s-cooperation'
    }, {
        name: '任务管理',
        index: '/dqc/job_list',
        icon: 'el-icon-s-cooperation'
    }],
    breadcrumb: [{
        path: '/dqc/list',
        title: 'DQC管理'
    }],
    connectorComponentMap: {
        'Palo': 'PaloConnectorParams',
        'Afs': 'AfsConnectorParams',
    },
    modelComponentMap: {
        'Palo': 'PaloModelParams',
        'Afs': 'AfsModelParams',
    },
    statusList: [
        {
            value: 0,
            label: '未开始'
        },
        {
            value: 1,
            label: '运行中'
        },
        {
            value: 2,
            label: '已完成'
        },
        {
            value: 3,
            label: '已失败'
        }
    ],
    statusMap: {
        0: {label: '未开始', type: 'info'},
        1: {label: '运行中', type: 'info'},
        2: {label: '已完成', type: 'success'},
        3: {label: '已失败', type: 'danger'}
    },
    dqcStatusList: [
        {
            value: 0,
            label: '未开始'
        },
        {
            value: 1,
            label: '成功'
        },
        {
            value: 2,
            label: '失败'
        }
    ],
    dqcStatusMap: {
        0: {label: '未开始', type: 'info'},
        1: {label: '成功', type: 'success'},
        2: {label: '失败', type: 'danger'}
    },
};