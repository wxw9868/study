<template>
    <div>
        <el-container>
            <sidebar :items="sidebarItems" />
            <el-main
                class="sidebar-main"
                style="padding: 0;"
            >
                <el-row>
                    <breadcrumb :data="breadcrumbItems" />
                </el-row>
                <el-row class="filter-row">
                    <el-form
                        :inline="true"
                        :model="filterForm"
                    >
                        <el-form-item label="查询">
                            <el-input
                                v-model="filterForm.word"
                                style="width: 260px;"
                                placeholder="请输入模型名称进行模糊检索"
                                @input="delayLoad"
                            />
                        </el-form-item>
                    </el-form>
                </el-row>
                <el-row class="button-row">
                    <el-button
                        type="success"
                        @click="addData"
                    >
                        <el-icon class="el-icon--left">
                            <Plus />
                        </el-icon>
                        添加数据模型
                    </el-button>
                </el-row>
                <el-row>
                    <el-table
                        v-loading="loading"
                        :data="jobData"
                        empty-text="暂无数据"
                        border
                        style="width: 100%;"
                    >
                        <el-table-column
                            prop="id"
                            label="模型ID"
                        />
                        <el-table-column
                            prop="name"
                            label="名称"
                        />
                        <el-table-column
                            prop="type"
                            label="类型"
                        />
                        <el-table-column
                            prop="chname"
                            label="中文名称"
                        />
                        <el-table-column
                            prop="description"
                            label="描述"
                        />
                        <el-table-column
                            prop="creator"
                            width="180px"
                            label="创建人"
                        />
                        <el-table-column
                            prop="modifier"
                            width="180px"
                            label="最近修改人"
                        />
                        <el-table-column
                            label="操作"
                            width="230px"
                        >
                            <template #default="scope">
                                <div>
                                    <el-button
                                        type="primary"
                                        size="small"
                                        @click="editMeta(scope.row.id)"
                                    >
                                        编辑
                                    </el-button>
                                </div>
                            </template>
                        </el-table-column>
                    </el-table>
                    <el-pagination
                        v-model:current-page="page"
                        v-model:page-size="size"
                        :page-sizes="[10, 20, 50, 100]"
                        :total="total"
                        background
                        layout="sizes, prev, pager, next"
                        @size-change="loadData"
                        @current-change="loadData"
                    />
                </el-row>
            </el-main>
        </el-container>
    </div>
</template>

<script>
import Breadcrumb from '../partial/Breadcrumb';
import Sidebar from '../partial/SideBar';
import config from './config';


import * as dqcApi from '../../apis/dqc';

import {useDateFormatter} from '../common/date';

import _ from 'lodash';

export default {
    components: {
        Breadcrumb,
        Sidebar,

    },
    beforeRouteEnter(to, from, next) {
        next(vm => {
            vm.init();
        });
    },
    setup() {
        const dateFormatter = useDateFormatter();
        return {dateFormatter};
    },
    data: function () {
        let sidebar = _.cloneDeep(config.sidebar);
        return {
            timeoutSign: null,
            loading: true,
            jobData: [],
            filterForm: {
                word: ''
            },
            onlyUser: '',
            sidebarItems: sidebar,
            breadcrumbItems: [],
            page: 1,
            size: 10,
            total: 10,
            echo: 0,
            dialogTableVisible: false,
        };
    },
    computed: {
    },
    methods: {
        init() {
            let meta = this.getMeta(this.$route);
            this.onlyUser = meta.onlyUser;
            this.page = 1;
            this.breadcrumbItems = meta.breadcrumb;
            this.loadData();
        },
        loadData() {
            this.loading = true;
            this.echo++;
            let query = {
                pdb: this.$route.query.pdb,
                search: this.filterForm.word,
                page: this.page,
                size: this.size,
                echo: this.echo
            };
            if (this.onlyUser) {
                query.owner = this.user.username;
            }
            dqcApi.model.get(query).then(res => {
                if (res.status === 0 && res.echo === this.echo) {
                    this.jobData = res.data;
                    this.total = res.total;
                }
                this.loading = false;
            });
        },
        delayLoad() {
            if (this.timeoutSign != null) {
                clearTimeout(this.timeoutSign);
            }
            this.timeoutSign = setTimeout(() => {
                this.timeoutSign = null;
                this.page = 1;
                this.loadData();
            }, 300);
        },
        addData() {
            this.$router.push('/dqc/model_edit').catch(() => {});
        },
        editMeta(id) {
            this.$router.push({
                path: '/dqc/model_edit',
                query: {
                    id,
                }
            }).catch(() => {});
        },
        getMeta(route) {
            let breadcrumb = _.cloneDeep(config.breadcrumb);
            let onlyUser = route.matched.some(record => record.meta.onlyUser);

            breadcrumb.push({
                path: '/dqc/model_list',
                title: '数据列表'
            });
            return {
                onlyUser,
                breadcrumb
            };
        }
    }
};
</script>
