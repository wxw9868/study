<template>
    <div>
        <el-select
            v-model="formData"
            style="width: 150px;"
            placeholder="请选择列"
            :multiple="multi"
            @change="updateParent"
        >
            <el-option
                v-for="(item, index) in columnsOptions()"
                :key="index"
                :label="item.label"
                :value="item.value"
            />
        </el-select>
    </div>
</template>

<script>
import {ref} from 'vue';

export default {
    props: {
        modelValue: {
            type: [String, Array],
            required: true
        },
        columns: {
            type: Array,
            required: true
        },
        onlyDimensionColumn: {
            type: Boolean,
            default: false
        },
        onlyValueColumn: {
            type: Boolean,
            default: false
        },
        multi: {
            type: Boolean,
            default: false
        }
    },
    emits: ['update:modelValue', 'change'],
    setup(props, {emit}) {
        const formData = ref(props.modelValue);

        const updateParent = () => {
            console.log(formData.value);
            emit('update:modelValue', formData.value);
            emit('change', formData.value);
        };

        const columnsOptions = () => {
            let columns = props.columns.filter((item) => {
                if (props.onlyDimensionColumn) {
                    if (!item.isValue) {
                        return true;
                    }
                    return false;
                }
                if (props.onlyValueColumn) {
                    if (item.isValue) {
                        return true;
                    }
                    return false;
                }
                return true;
            });
            let options = [];
            columns.forEach((item) => {
                options.push({
                    label: item.name,
                    value: item.column
                });
            });
            console.log(options);
            return options;
        };
        // watch(
        //     () => props.modelValue,
        //     (newVal) => {
        //         formData.value = {...newVal};
        //     }
        // );

        return {
            columnsOptions,
            formData,
            updateParent
        };
    }
};
</script>

<style lang="scss" scoped>

</style>