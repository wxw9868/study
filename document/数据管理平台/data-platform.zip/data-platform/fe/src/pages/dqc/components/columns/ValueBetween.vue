<template>
    <div>
        <!-- 设计一个flex排版，column1 op1 column2 op2 ...每个结构是个el-select-->
        <div
            v-for="(column, index) in formData.columnsList"
            :key="index"
        >
            <column-select
                v-model="formData.columns[index]"
                :only-value-column="true"
                :columns="column"
                @change="updateParent"
            />
            <el-select
                v-if="index < formData.columnsList.length -1"
                v-model="formData.opList[index]"
                @change="updateParent"
            >
                <el-option
                    v-for="item in opOptions"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value"
                />
            </el-select>
        </div>
    </div>
</template>

<script>
import ColumnSelect from './ColumnSelect.vue';
import {watch, ref} from 'vue';

export default {
    components: {
        ColumnSelect
    },
    props: {
        modelValue: {
            type: String,
            required: true
        },
        columnsList: {
            type: Array,
            required: true
        }
    },
    emits: ['update:modelValue', 'change'],
    setup(props, {emit}) {
        const formData = ref({...props.modelValue});
        if (!Array.isArray(formData.value.columns) || formData.value.columns.length === 0) {
            formData.value.columns = new Array(props.columnsList.length).fill(null);
        }
        if (!Array.isArray(formData.value.opList) || formData.value.opList.length === 0) {
            formData.value.opList = new Array(props.columnsList.length - 1).fill(null);
        }
        const opOptions = ref([
            {
                label: '<=',
                value: '<='
            },
            {
                label: '>=',
                value: '>='
            },
            {
                label: '=',
                value: '='
            },
            {
                label: '<',
                value: '<'
            },
            {
                label: '>',
                value: '>'
            }
        ]);

        const updateParent = () => {
            emit('update:modelValue', formData.value);
            emit('change');
        };

        watch(
            () => props.modelValue,
            (newVal) => {
                formData.value = {...newVal};
            }
        );

        return {
            formData,
            updateParent,
            opOptions
        };
    }
};
</script>

<style lang="scss" scoped>

</style>