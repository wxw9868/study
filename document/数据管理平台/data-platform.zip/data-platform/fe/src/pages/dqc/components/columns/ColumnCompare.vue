<template>
    <div class="inline-form-items">
        <div v-if="formData.columns.length <= 1">
            可选列太少啦，至少需要2列才能进行操作！
        </div>
        <div
            v-for="(_, index) in formData.columns"
            v-else
            :key="index"
            class="form-group"
        >
            <column-select
                v-model="formData.columns[index]"
                :only-value-column="true"
                :columns="columns"

                @change="updateParent"
            />
            <el-select
                v-if="index < formData.columns.length -1"
                v-model="formData.opList[index]"
                placeholder="请选择操作符"
                style="width: 100px;"
                @change="updateParent"
            >
                <el-option
                    v-for="item in opOptions"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value"
                />
            </el-select>
        </div>
    </div>
</template>

<script>
import ColumnSelect from './ColumnSelect.vue';
import {watch, ref} from 'vue';

export default {
    components: {
        ColumnSelect
    },
    props: {
        modelValue: {
            type: Object,
            required: true
        },
        columns: {
            type: Array,
            required: true
        },
        onlyValueColumn: {
            type: Boolean,
            default: false
        },
    },
    emits: ['update:modelValue', 'change'],
    setup(props, {emit}) {
        const formData = ref({...props.modelValue});

        let columns = props.columns.filter((item) => {
            if (props.onlyValueColumn) {
                if (item.isValue) {
                    return true;
                }
                return false;
            }
            return true;
        });

        if (!Array.isArray(formData.value.columns) || formData.value.columns.length === 0) {
            formData.value.columns = new Array(columns.length).fill(null);
        }
        if (!Array.isArray(formData.value.opList) || formData.value.opList.length === 0) {
            formData.value.opList = new Array(columns.length - 1).fill(null);
        }
        const opOptions = ref([
            {
                label: '<=',
                value: '<='
            },
            {
                label: '>=',
                value: '>='
            },
            {
                label: '=',
                value: '='
            },
            {
                label: '<',
                value: '<'
            },
            {
                label: '>',
                value: '>'
            }
        ]);

        const updateParent = () => {
            emit('update:modelValue', formData.value);
            emit('change');
        };

        watch(
            () => props.modelValue,
            (newVal) => {
                formData.value = {...newVal};
            }
        );

        return {
            formData,
            updateParent,
            opOptions,
        };
    }
};
</script>

<style lang="scss" scoped>
.inline-form-items {
  display: flex;
  flex-wrap: wrap; /* 如果空间不足，允许换行 */
  gap: 10px; /* 控制每组之间的间距 */
  align-items: center; /* 垂直居中对齐 */
  box-sizing: border-box;
}

.form-group {
  display: flex;
  align-items: center; /* 确保 column-select 和 el-select 垂直居中 */
  gap: 5px; /* 控制 column-select 和 el-select 之间的间距 */
  flex: 1 1 auto;
}

.inline-form-items .el-form-item {
  margin-bottom: 0; /* 移除默认的底部边距 */
  //flex-shrink: 0; /* 防止元素缩小过多 */
}

.inline-form-items .el-input,
.inline-form-items .el-button,
.inline-form-items .el-checkbox {
  font-size: 12px; /* 调整字体大小以使其更紧凑 */
}
</style>