<template>
    <div>
        <el-container>
            <sidebar :items="sidebarItems" />
            <el-main
                class="sidebar-main"
                style="padding: 0;"
            >
                <el-row>
                    <breadcrumb :data="breadcrumbItems" />
                </el-row>
                <el-row v-loading="loading">
                    <div class="box-row">
                        <el-form
                            ref="form"
                            :model="form"
                            label-width="100"
                            style="width: 100%;"
                            :rules="rules"
                        >
                            <el-form-item
                                label="数据名"
                                prop="name"

                                style="width: 100%;"
                            >
                                <el-input
                                    v-model="form.name"
                                    :disabled="edit"
                                />
                            </el-form-item>
                            <el-form-item
                                label="数据中文名"
                                prop="chname"
                            >
                                <el-input v-model="form.chname" />
                            </el-form-item>
                            <el-form-item
                                label="Schema"
                                prop="schema"
                            >
                                <table-schema
                                    v-model="form.schema"
                                    parent-name="schema"
                                />
                            </el-form-item>
                            <el-form-item
                                label="报警配置"
                                prop="noticeConfig"
                            >
                                <notice-params
                                    v-model="form.noticeConfig"
                                    parent-name="noticeConfig"
                                    label-width="100"
                                />
                            </el-form-item>
                            <el-form-item>
                                <el-button
                                    type="primary"
                                    size="large"
                                    @click="submitForm"
                                >
                                    提交
                                </el-button>
                                <el-button
                                    v-if="edit"
                                    size="large"
                                    type="danger"
                                    @click="deleteJob"
                                >
                                    删除
                                </el-button>
                                <el-button
                                    size="large"
                                    @click="cancelForm"
                                >
                                    取消
                                </el-button>
                            </el-form-item>
                        </el-form>
                    </div>
                </el-row>
            </el-main>
        </el-container>
    </div>
</template>

<script>
import * as dqcApi from '../../apis/dqc';
import _ from 'lodash';
import {ElMessage} from 'element-plus';
import config from './config';
import Breadcrumb from '../partial/Breadcrumb';
import Sidebar from '../partial/SideBar';
import TableSchema from './components/TableSchema';
import NoticeParams from '../dimension/components/NoticeParams';


const emptyForm = {
    name: '',
    chname: '',
    sourceType: '',
    sourceParams: {},
    schema: {}
};


export default {
    components: {
        Breadcrumb,
        Sidebar,
        TableSchema,
        NoticeParams,
    },
    beforeRouteEnter(to, from, next) {
        next(vm => {
            vm.init();
        });
    },
    setup() {


        return {};
    },
    data() {
        let meta = this.getMeta(this.$route);
        let sidebar = _.cloneDeep(config.sidebar);
        return {
            loading: false,
            timeoutSign: null,
            form: _.cloneDeep(emptyForm),
            rules: {
                name: [{
                    required: true,
                    message: '请输入维表名称'
                }, {
                    validator: this.nameValid,
                    trigger: 'blur'
                }],
                chname: [{
                    required: true,
                    message: '请输入中文名称'
                }],
                dataSchema: [{
                    required: true,
                    message: '请输入数据schema'
                }, {
                    validator: this.jsonSchemaValid,
                    trigger: 'blur'
                }]
            },
            sidebarItems: sidebar,
            breadcrumbItems: meta.breadcrumb,
            edit: meta.edit
        };
    },
    methods: {
        init() {
            this.loadData();
        },
        delayLoad() {
            if (this.timeoutSign != null) {
                clearTimeout(this.timeoutSign);
            }
            this.timeoutSign = setTimeout(() => {
                this.timeoutSign = null;
                this.loadTemplate();
            }, 300);
        },
        loadData() {
            if (this.$route.query.name) {
                this.loading = true;
                dqcApi.meta.get({
                    name: this.$route.query.name
                }).then(data => {
                    if (data.data.length === 0) {
                        ElMessage.error('数据不存在');
                        return;
                    }
                    this.form = data.data[0];
                    this.loading = false;
                });
            } else {
                return;
            }
        },

        getMeta(route) {
            let breadcrumb = _.cloneDeep(config.breadcrumb);
            let edit = !!route.query.name;
            if (edit) {
                breadcrumb.push({
                    path: '/dqc/edit',
                    title: '编辑数据'
                });
            } else {
                breadcrumb.push({
                    path: '/dqc/edit',
                    title: '新建数据'
                });
            }
            return {
                breadcrumb,
                edit
            };
        },
        submitForm() {
            this.$refs.form.validate(valid => {
                if (valid) {
                    if (this.form.id != null) {
                        dqcApi.meta.patch(this.form.id, this.form).then(res => {
                            if (res.status === 0) {
                                this.$router.push('/dqc/list').catch(() => {});
                            }
                        });
                    } else {
                        dqcApi.meta.post(this.form).then(res => {
                            if (res.status === 0) {
                                this.$router.push('/dqc/list').catch(() => {});
                            }
                        });
                    }
                } else {
                    ElMessage.error('表单验证失败');
                }
            });
        },
        cancelForm() {
            this.$router.push('/dqc/list').catch(() => {});
        },
        nameValid(rule, value, callback) {
            if (!/^[a-zA-Z0-9_.]*$/.test(value)) {
                callback(new Error('请输入合法字符：[a-zA-Z0-9_.]'));
                return;
            }
            callback();
        },
        deleteJob() {
            let name = this.$route.query.name;
            this.$confirm(`确认删除${name}么？`, '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'error'
            }).then(() => {
                dqcApi.meta.delete({
                    pdb: this.$route.query.pdb,
                    name: name
                }).then(res => {
                    if (res.status === 0) {
                        this.$router.push('/dqc/list').catch(() => {});
                    }
                });
            });
        },
    }
};
</script>

<style lang="scss" scoped>

</style>