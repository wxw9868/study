<template>
    <div>
        <el-container>
            <sidebar :items="sidebarItems" />
            <el-main
                class="sidebar-main"
                style="padding: 0;"
            >
                <el-row>
                    <breadcrumb :data="breadcrumbItems" />
                </el-row>
                <el-row v-loading="loading">
                    <div class="box-row">
                        <el-form
                            ref="form"
                            :model="form"
                            label-width="100"
                            style="width: 100%;"
                            :rules="rules"
                        >
                            <el-form-item
                                label="名称"
                                prop="name"
                                style="width: 800px;"
                            >
                                <el-input
                                    v-model="form.name"
                                />
                            </el-form-item>
                            <el-form-item
                                label="规则类型"
                                prop="ruleType"
                                style="width: 100%;"
                            >
                                <el-input
                                    v-model="form.ruleType"
                                />
                            </el-form-item>
                            <el-form-item
                                label="类型"
                                prop="type"
                            >
                                <el-select
                                    v-model="form.type"
                                    :disabled="edit"
                                >
                                    <el-option
                                        label="单表规则"
                                        value="single"
                                    />
                                    <el-option
                                        label="多表规则"
                                        value="multi"
                                    />
                                </el-select>
                            </el-form-item>
                            <el-form-item
                                label="参数"
                                prop="params"
                                class="form-item-container"
                            >
                                <div class="params-container">
                                    <div
                                        v-for="(item, index) in form.params"
                                        :key="index"
                                        class="rule-config-params-container"
                                    >
                                        <rule-config-params
                                            :key="incrKey"
                                            :model-value="item"
                                            :parent-name="`params.${index}`"
                                            @update:model-value="val => form.params[index] = val"
                                        />
                                        <el-button
                                            size="small"
                                            class="delete-button"
                                            @click="form.params.splice(index, 1)"
                                        >
                                            删除
                                        </el-button>
                                    </div>
                                </div>
                                <div class="add-button-container">
                                    <el-button
                                        type="success"
                                        class="add-button"
                                        @click="incrKey++; form.params.push({})"
                                    >
                                        添加
                                    </el-button>
                                </div>
                            </el-form-item>
                            <el-form-item>
                                <el-button
                                    type="primary"
                                    size="large"
                                    @click="submitForm"
                                >
                                    提交
                                </el-button>
                                <el-button
                                    v-if="edit"
                                    size="large"
                                    type="danger"
                                    @click="deleteJob"
                                >
                                    删除
                                </el-button>
                                <el-button
                                    size="large"
                                    @click="cancelForm"
                                >
                                    取消
                                </el-button>
                            </el-form-item>
                        </el-form>
                    </div>
                </el-row>
            </el-main>
        </el-container>
    </div>
</template>

<script>
import * as dqcApi from '../../apis/dqc';
import _ from 'lodash';
import {ElMessage} from 'element-plus';
import config from './config';
import Breadcrumb from '../partial/Breadcrumb';
import Sidebar from '../partial/SideBar';
import RuleConfigParams from './components/RuleConfigParams';

const emptyForm = {
    name: '',
    ruleType: '',
    type: 'single',
    params: [],
};

export default {
    components: {
        Breadcrumb,
        Sidebar,
        RuleConfigParams
    },
    beforeRouteEnter(to, from, next) {
        next(vm => {
            vm.init();
        });
    },
    setup() {
        return {};
    },
    data() {
        let meta = this.getMeta(this.$route);
        let sidebar = _.cloneDeep(config.sidebar);
        return {
            loading: false,
            timeoutSign: null,
            form: _.cloneDeep(emptyForm),
            connectorMap: {},
            incrKey: 1,
            rules: {
                name: [{
                    required: true,
                    message: '请输入名称'
                }],
                type: [{
                    required: true,
                    message: '请输入名称'
                }, {
                    validator: this.nameValid,
                    trigger: 'blur'
                }],
                ruleType: [{
                    required: true,
                    message: '请选择规则类型'
                }],
                params: [{
                    required: true,
                    message: '请选择参数'
                }],
            },
            sidebarItems: sidebar,
            breadcrumbItems: meta.breadcrumb,
            edit: meta.edit
        };
    },
    methods: {
        init() {
            this.loadData();
        },
        loadData() {
            if (this.$route.query.id) {
                this.loading = true;
                dqcApi.rule.get({
                    id: this.$route.query.id
                }).then(data => {
                    if (data.data.length === 0) {
                        ElMessage.error('数据不存在');
                        return;
                    }
                    this.form = data.data[0];
                    this.loading = false;
                });
            } else {
                return;
            }
        },

        getMeta(route) {
            let breadcrumb = _.cloneDeep(config.breadcrumb);
            let edit = !!route.query.id;
            if (edit) {
                breadcrumb.push({
                    path: '/dqc/rule_edit',
                    title: '编辑规则'
                });
            } else {
                breadcrumb.push({
                    path: '/dqc/rule_edit',
                    title: '新建规则'
                });
            }
            return {
                breadcrumb,
                edit
            };
        },
        submitForm() {
            this.$refs.form.validate((valid, fields) => {
                if (valid) {
                    if (this.form.id != null) {
                        dqcApi.rule.patch(this.form.id, this.form).then(res => {
                            if (res.status === 0) {
                                this.$router.push('/dqc/rule_list').catch(() => {});
                            }
                        });
                    } else {
                        dqcApi.rule.post(this.form).then(res => {
                            if (res.status === 0) {
                                this.$router.push('/dqc/rule_list').catch(() => {});
                            }
                        });
                    }
                } else {
                    ElMessage.error('表单验证失败');
                    console.log(fields);
                }
            });
        },
        cancelForm() {
            this.$router.push('/dqc/rule_list').catch(() => {});
        },
        nameValid(rule, value, callback) {
            if (!/^[a-zA-Z0-9_.]*$/.test(value)) {
                callback(new Error('请输入合法字符：[a-zA-Z0-9_.]'));
                return;
            }
            callback();
        },
        deleteJob() {
            let id = this.$route.query.id;
            this.$confirm(`确认删除id=${id}规则么？`, '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'error'
            }).then(() => {
                dqcApi.rule.delete({
                    pdb: this.$route.query.pdb,
                    id: id
                }).then(res => {
                    if (res.status === 0) {
                        this.$router.push('/dqc/rule_list').catch(() => {});
                    }
                });
            });
        },
        getModelParamsComponent() {
            return config.modelComponentMap[this.form.type];
        }
    }
};
</script>

<style lang="scss" scoped>
.sidebar-main {
  padding: 20px;
  background-color: #f9f9f9; // 增加背景色，提升视觉层次感
}

.box-row {
  background: #fff; // 为表单容器增加白色背景
  padding: 20px;
  border-radius: 8px; // 增加圆角，使界面更柔和
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1); // 添加阴影，提升立体感
}

.el-form-item {
  margin-bottom: 20px; // 增加表单项之间的间距

  &:last-child {
    margin-bottom: 0; // 最后一个表单项不需要间距
  }
}

.el-form-item__label {
  font-weight: bold; // 加粗标签文字，提升可读性
  color: #333; // 标签文字颜色
}

.el-input, .el-select {
  width: 100%; // 确保输入框和选择框占满容器宽度
}

.el-button {
  margin-right: 10px; // 按钮之间的间距

  &:last-child {
    margin-right: 0; // 最后一个按钮不需要间距
  }
}

.el-button[type="primary"] {
  background-color: #409eff; // 主按钮背景色
  border-color: #409eff; // 主按钮边框色
  color: #fff; // 主按钮文字颜色

  &:hover {
    background-color: #66b1ff; // 悬停时的背景色
    border-color: #66b1ff; // 悬停时的边框色
  }
}

.el-button[type="danger"] {
  background-color: #f56c6c; // 危险按钮背景色
  border-color: #f56c6c; // 危险按钮边框色
  color: #fff; // 危险按钮文字颜色

  &:hover {
    background-color: #f78989; // 悬停时的背景色
    border-color: #f78989; // 悬停时的边框色
  }
}

.params-container {
  display: flex;
  flex-direction: column;
  gap: 10px; // 每个参数项之间的间距
}

.rule-config-params-container {
  display: flex;
  align-items: center; // 垂直居中对齐
}

.delete-button {
  margin-left: 10px; // 删除按钮与参数项之间的间距
}

.add-button-container {
  margin-top: 20px; // 添加按钮与参数项之间的间距
  display: flex;
  justify-content: center; // 居中显示添加按钮
}

.add-button {
  width: 100%; // 使添加按钮占满容器宽度
  max-width: 200px; // 可选：限制按钮的最大宽度
}

</style>