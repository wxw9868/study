<template>
    <div class="inline-form-items">
        <el-form-item
            v-for="(config, index) in configList"
            :key="index"
            :label="config.label"
            :prop="`${parentName}.${config.name}`"
            label-width="100"
            label-position="left"
            :rules="[{required: config.isRequired, message: `请输入${config.name}`, trigger: 'change'}]"
        >
            <div v-if="config.type === 'string'">
                <el-tooltip
                    v-if="config.comment"
                    effect="dark"
                    :content="config.comment"
                    placement="top-start"
                >
                    <el-input
                        v-model="formData[config.name]"
                        :style="`width:${controlWidth(config)}px`"
                        @input="updateParent"
                    />
                </el-tooltip>
                <el-input
                    v-else
                    v-model="formData[config.name]"
                    :style="`width:${controlWidth(config)}px`"
                    @input="updateParent"
                />
            </div>
            <div v-if="config.type === 'number'">
                <el-tooltip
                    v-if="config.comment"
                    effect="dark"
                    :content="config.comment"
                    placement="top-start"
                >
                    <el-input-number
                        v-model="formData[config.name]"
                        :style="`width:${controlWidth(config)}px`"
                        @input="updateParent"
                    />
                </el-tooltip>
                <el-input-number
                    v-else
                    v-model="formData[config.name]"
                    :style="`width:${controlWidth(config)}px`"
                    @input="updateParent"
                />
            </div>
            <div v-if="config.type === 'column'">
                <el-tooltip
                    v-if="config.comment"
                    effect="dark"
                    :content="config.comment"
                    placement="top-start"
                >
                    <column-select
                        v-model="formData[config.name]"
                        :columns="modelColumns[0]"
                        :only-value-column="config.isValueOnly"
                        :multi="config.multiple"
                        @change="updateParent"
                    />
                </el-tooltip>
                <column-select
                    v-else
                    v-model="formData[config.name]"
                    :columns="modelColumns[0]"
                    :only-value-column="config.isValueOnly"
                    :multi="config.multiple"
                    @change="updateParent"
                />
            </div>
            <div v-if="config.type === 'column_compare'">
                <el-tooltip
                    v-if="config.comment"
                    effect="dark"
                    :content="config.comment"
                    placement="top-start"
                >
                    <column-compare
                        v-model="formData[config.name]"
                        :columns="modelColumns[0]"
                        :only-value-column="config.isValueOnly"
                        @change="updateParent"
                    />
                </el-tooltip>
                <column-compare
                    v-else
                    v-model="formData[config.name]"
                    :columns="modelColumns[0]"
                    :only-value-column="config.isValueOnly"
                    @change="updateParent"
                />
            </div>
            <div v-if="config.type === 'column_compare_list'">
                <el-tooltip
                    v-if="config.comment"
                    effect="dark"
                    :content="config.comment"
                    placement="top-start"
                >
                    <column-compare-list
                        v-model="formData[config.name]"
                        :columns="modelColumns[0]"
                        :only-value-column="config.isValueOnly"
                        @change="updateParent"
                    />
                </el-tooltip>
                <column-compare-list
                    v-else
                    v-model="formData[config.name]"
                    :columns="modelColumns[0]"
                    :only-value-column="config.isValueOnly"
                    @change="updateParent"
                />
            </div>
            <div v-if="config.type === 'enum'">
                <enum-select
                    v-model="formData[config.name]"
                    :enum="config.enum"
                    @change="updateParent"
                />
            </div>
        </el-form-item>
    </div>
</template>

<script>
import {defineComponent, watch, ref} from 'vue';
import ColumnSelect from './columns/ColumnSelect';
import ColumnCompare from './columns/ColumnCompare';
import EnumSelect from './columns/EnumSelect';
import ColumnCompareList from './columns/ColumnCompareList';

export default defineComponent({
    name: 'RuleParams',
    components: {
        ColumnSelect,
        ColumnCompare,
        EnumSelect,
        ColumnCompareList,
    },

    props: {
        modelValue: {
            type: Object,
            required: true,
        },
        parentName: {
            type: String,
            required: true,
        },
        configList: {
            type: Array,
            required: true,
        },
        modelColumns: {
            type: Array,
            required: true,
        },
    },
    emits: ['update:modelValue'],
    setup(props, {emit}) {
        const formData = ref({...props.modelValue});
        console.log(props.configList);

        watch(
            () => props.modelValue,
            (newVal) => {
                formData.value = {...newVal};
            }
        );

        const controlWidth = (config) => {
            return config.width || 100;
        };

        const updateParent = () => {
            emit('update:modelValue', formData.value);
        };

        return {
            formData,
            updateParent,
            controlWidth
        };
    },
    data() {
        return {
        };
    },
});
</script>

<style scoped>
.inline-form-items {
  display: flex;
  align-items: left;
  justify-content: flex-start;
  flex-wrap: wrap; /* 如果空间不足，允许换行 */
  gap: 10px; /* 控制行内元素之间的间距 */
}

.inline-form-items .el-form-item {
  margin-bottom: 0; /* 移除默认的底部边距 */
  flex-shrink: 0; /* 防止元素缩小过多 */
}

.inline-form-items .el-input,
.inline-form-items .el-button,
.inline-form-items .el-checkbox {
  font-size: 12px; /* 调整字体大小以使其更紧凑 */
}

</style>