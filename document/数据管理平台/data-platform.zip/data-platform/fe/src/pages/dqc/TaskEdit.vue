<template>
    <div>
        <el-container>
            <sidebar :items="sidebarItems" />
            <el-main
                class="sidebar-main"
                style="padding: 0;"
            >
                <el-row>
                    <breadcrumb :data="breadcrumbItems" />
                </el-row>

                <el-row>
                    <el-container class="ruleedit">
                        <el-header>
                            <div>
                                <span class="rule-list-title">所选模型</span>
                            </div>
                            <div class="custom-table">
                                <div class="table-header">
                                    <div
                                        v-for="item in tableHeader"
                                        :key="item.prop"
                                        class="header-cell"
                                    >
                                        {{ item.label }}
                                    </div>
                                </div>
                                <div class="table-body">
                                    <div
                                        v-for="(row, rowIndex) in tableData"
                                        :key="rowIndex"
                                        class="body-row"
                                    >
                                        <div
                                            v-for="item in tableHeader"
                                            :key="item.prop"
                                            class="body-cell"
                                        >
                                            {{ row[item.prop] }}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </el-header>
                        <el-container style="margin-top: 10px;">
                            <el-aside width="200px">
                                <div>
                                    <span class="rule-list-title">规则列表<el-tag
                                        v-if="form.dataIds.length === 1"
                                        type="success"
                                    >单表模式</el-tag>
                                        <el-tag v-if="form.dataIds.length > 1">多表模式</el-tag></span>
                                </div>
                                <div>
                                    <el-input
                                        v-model="filterWord"
                                        style="width: 150px;"
                                        placeholder="输入关键词检索规则"
                                        @input="delayLoad"
                                    />
                                </div>
                                <el-menu>
                                    <el-submenu>
                                        <el-menu-item
                                            v-for="(rule, j) in optionRuleList"
                                            :key="j"
                                            :index="`${j}`"
                                            @click="selectUpdateRuleTemplate(rule)"
                                        >
                                            {{ rule.name }}
                                        </el-menu-item>
                                    </el-submenu>
                                </el-menu>
                            </el-aside>
                            <el-main>
                                <div>
                                    <span class="rule-list-title">任务配置</span>
                                </div>
                                <el-form
                                    ref="form"
                                    :model="form"
                                    label-width="100"
                                    style="width: 100%;"
                                    :rules="rules"
                                >
                                    <el-form-item
                                        label="任务名称"
                                        prop="title"
                                        label-position="left"
                                        style="width: 100%;"
                                    >
                                        <el-input
                                            v-model="form.title"
                                            :disabled="edit"
                                            style="width: 500px;"
                                        />
                                    </el-form-item>
                                    <el-form-item
                                        label="任务描述"
                                        prop="description"
                                        label-position="left"
                                    >
                                        <el-input
                                            v-model="form.description"
                                            type="textarea"
                                            style="width: 500px;"
                                        />
                                    </el-form-item>

                                    <el-tag>规则列表</el-tag>
                                    <div
                                        v-for="(item, index) in form.rules"
                                        :key="index"
                                    >
                                        <span class="rule-name">规则{{ index+1 }}: {{ item.name }}</span>
                                        <rule-params
                                            v-model="item.params"
                                            :config-list="item.config"
                                            :model-columns="modelColumns"
                                            :parent-name="`rules.${index}.params`"
                                        />
                                        <el-button
                                            size="small"
                                            type="warning"
                                            link
                                            @click="form.rules.splice(index, 1)"
                                        >
                                            删除
                                        </el-button>
                                        <el-divider class="custom-divider" />
                                    </div>

                                    <el-form-item>
                                        <el-button
                                            type="primary"
                                            size="large"
                                            @click="submitForm"
                                        >
                                            提交更改
                                        </el-button>
                                        <el-button
                                            v-if="form.id != null"
                                            type="success"
                                            size="large"
                                            @click="executeTask"
                                        >
                                            提交执行
                                        </el-button>
                                        <el-button
                                            v-if="edit"
                                            size="large"
                                            type="danger"
                                            @click="deleteJob"
                                        >
                                            删除
                                        </el-button>
                                        <el-button
                                            size="large"
                                            @click="cancelForm"
                                        >
                                            取消
                                        </el-button>
                                    </el-form-item>
                                </el-form>
                            </el-main>
                        </el-container>
                    </el-container>
                </el-row>
            </el-main>
        </el-container>
    </div>
</template>

<script>
import {ElMessage, ElMessageBox} from 'element-plus';

import * as dqcApi from '../../apis/dqc';
import _ from 'lodash';
import config from './config';
import Breadcrumb from '../partial/Breadcrumb';
import Sidebar from '../partial/SideBar';
import RuleParams from './components/RuleParams';

const emptyForm = {
    jobId: null,
    title: '',
    description: '',
    type: 'single',
    dataIds: [],
    triggerSource: 'manual',
    rules: [],
};

export default {
    components: {
        Breadcrumb,
        Sidebar,
        RuleParams,
    },
    beforeRouteEnter(to, from, next) {
        next(vm => {
            vm.init();
        });
    },
    props: {
    },
    setup() {
        return {};
    },
    data() {
        let meta = this.getMeta(this.$route);
        let sidebar = _.cloneDeep(config.sidebar);
        return {
            loading: false,
            timeoutSign: null,
            form: _.cloneDeep(emptyForm),
            connectorMap: {},
            filterWord: '',
            rules: {
                title: [{
                    required: true,
                    message: '请输入名称'
                }],
                description: [{
                    required: true,
                    message: '请输入任务描述'
                }],
            },
            jobId: this.$route.query.jobId,
            modelList: [],
            modelMap: {},
            sidebarItems: sidebar,
            breadcrumbItems: meta.breadcrumb,
            edit: meta.edit,
            fullRuleList: config.ruleList,
            tableData: [],
            tableHeader: [],
            ruleList: [],
            optionRuleList: [],
        };
    },
    computed: {
        modelColumns() {
            let columns = [];
            if (!this.form.dataIds) {
                return [];
            }
            this.form.dataIds.forEach(item => {
                columns.push(this.modelMap[item].columns);
            });
            return columns;
        },

    },
    methods: {
        init() {
            this.loadModel().then(_ => {
                this.loadData().then(_ => {
                    this.loadRules();
                    // let type = 'single';
                    // if (this.form.dataIds.length > 1) {
                    //     type = 'multi';
                    // }
                    // let ruleList = this.fullRuleList.filter(item => item.type === type);
                    // console.log(ruleList);
                    // this.ruleList = ruleList[0].rules;
                    // console.log(this.ruleList);
                    // this.optionRuleList = this.ruleList;
                });
            });
        },
        loadRules() {
            let type = 'single';
            if (this.form.dataIds.length > 1) {
                type = 'multi';
            }
            let query = {
                type: type,
                search: this.filterWord,
                size: 1000,
            };
            dqcApi.rule.get(query).then(data => {
                let optionRuleList = data.data;
                optionRuleList.forEach(item => {
                    item.type = item.ruleType;
                });
                this.optionRuleList = optionRuleList;
            });
        },
        delayLoad() {
            if (this.timeoutSign != null) {
                clearTimeout(this.timeoutSign);
            }
            this.timeoutSign = setTimeout(() => {
                this.timeoutSign = null;
                // this.filterRule();
                this.loadRules();
            }, 300);
        },
        filterRule() {
            console.log('filteRule' + this.filterWord);
            if (!this.filterWord) {
                this.optionRuleList = this.ruleList;
                return;
            }
            this.optionRuleList = this.ruleList.filter(item => {
                return item.name.includes(this.filterWord);
            });
            console.log(this.optionRuleList);
        },
        loadModel() {
            this.modelMap = {};
            return dqcApi.model.get({
                size: 1000,
            }).then(data => {
                this.modelList = data.data;
                this.modelList.forEach(item => {
                    this.modelMap[item.id] = item;
                });
                console.log(this.modelList);
            });
        },
        selectUpdateRuleTemplate(rule) {
            let params = {};
            rule.params.forEach(item => {
                if (item.default !== null && item.default !== undefined) {
                    params[item.name] = item.default;
                }
            });
            this.form.rules.push(
                {
                    params: params,
                    config: rule.params,
                    type: rule.type,
                    name: rule.name,
                }
            );
        },
        initTable() {
            let data = {};
            let tableHeader = [];
            this.form.dataIds.forEach((item, index) => {
                data[`模型${index + 1}`] = this.modelMap[item].name;
                tableHeader.push({
                    prop: `模型${index + 1}`,
                    label: `模型${index + 1}`,
                });
            });
            this.tableHeader = tableHeader;
            this.tableData = [data];
            if (this.form.dataIds.length > 1) {
                this.form.type = 'multi';
            }
        },
        loadData() {
            if (this.$route.query.id) {
                this.loading = true;
                return dqcApi.task.get({
                    id: this.$route.query.id
                }).then(data => {
                    if (data.data.length === 0) {
                        ElMessage.error('任务不存在');
                        return;
                    }
                    this.form = data.data[0];
                    this.loading = false;
                    this.initTable();
                });
            } else {
                console.log(this.$route);
                this.form = _.cloneDeep(emptyForm);
                this.form.dataIds = this.$route.query.dataIds.split(',');
                // jobId转换成int
                if (this.$route.query.jobId) {
                    this.jobId = parseInt(this.$route.query.jobId, 10);
                }
                this.form.jobId = this.jobId;
                this.initTable();
                return Promise.resolve();
            }
        },

        getMeta(route) {
            let breadcrumb = _.cloneDeep(config.breadcrumb);
            let edit = !!route.query.id;
            if (edit) {
                breadcrumb.push({
                    path: '/dqc/task_edit',
                    title: '编辑任务'
                });
            } else {
                breadcrumb.push({
                    path: '/dqc/task_edit',
                    title: '新建任务'
                });
            }
            return {
                breadcrumb,
                edit
            };
        },
        submitForm() {
            this.$refs.form.validate(valid => {
                if (valid) {
                    if (this.form.id != null) {
                        dqcApi.task.patch(this.form.id, this.form).then(res => {
                            if (res.status === 0) {
                                this.$router.push('/dqc/task_list').catch(() => {});
                            }
                        });
                    } else {
                        dqcApi.task.post(this.form).then(res => {
                            if (res.status === 0) {
                                this.$router.push('/dqc/task_list').catch(() => {});
                            }
                        });
                    }
                } else {
                    ElMessage.error('表单验证失败');
                }
            });
        },
        cancelForm() {
            this.$router.push('/dqc/task_list').catch(() => {});
        },
        nameValid(rule, value, callback) {
            if (!/^[a-zA-Z0-9_.]*$/.test(value)) {
                callback(new Error('请输入合法字符：[a-zA-Z0-9_.]'));
                return;
            }
            callback();
        },
        deletetask() {
            let id = this.$route.query.id;
            this.$confirm(`确认删除${id}么？`, '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'error'
            }).then(() => {
                dqcApi.task.delete({
                    pdb: this.$route.query.pdb,
                    id: id
                }).then(res => {
                    if (res.status === 0) {
                        this.$router.push('/dqc/task_list').catch(() => {});
                    }
                });
            });
        },
        executeTask() {
            if (!this.form.id) {
                ElMessage.error('请先保存任务后，重新进入');
                return;
            }
            ElMessageBox.confirm(
                '任务即将提交到执行环境，是否确认？',
                '任务提交提醒',
                {
                    confirmButtonText: 'OK',
                    cancelButtonText: 'Cancel',
                    type: 'success',
                }
            ) .then(() => {
                dqcApi.task.submitTask(this.form.id).then(res => {
                    if (res.status === 0) {
                        ElMessage.success('任务提交成功');
                    }
                });
            }).catch(() => {
                ElMessage({
                    type: 'info',
                    message: 'canceled',
                });
            });
        }
    }
};
</script>

<style lang="scss" scoped>

.el-form-item__label {
    flex-direction: row-reverse;
}

/* 基础布局 */
.ruleedit .el-container {
  height: 100vh;

}

/* 头部表格区域 */
.ruleedit .el-header {
  padding: 20px !important;
  background: white;
  height: 100%;
  border-radius: 8px;
  box-shadow: 0 2px 12px rgba(0,0,0,0.1);

  .el-tag {
    margin-bottom: 15px;
    font-size: 14px;
  }

  .el-table {
    ::v-deep(.el-table__header th) {
      background: #f8f9fa;
      color: #666;
    }
    ::v-deep(.el-table__row) {
      height: 48px;
    }
  }
}

/* 规则选择区域 */
.ruleedit .el-aside {
  background: white;
  border-radius: 8px;
  padding: 20px !important;
  box-shadow: 0 2px 12px rgba(0,0,0,0.1);

  .el-tag {
    margin-bottom: 15px;
    font-size: 14px;
  }

  .el-menu {
    border-right: none;

    .el-submenu__title {
      height: 40px;
      line-height: 40px;
      font-size: 14px;
      color: #333;

      &:hover {
        background: #f5f7fa;
      }
    }

    .el-menu-item {
      height: 36px;
      line-height: 36px;
      padding: 0 20px;

      &:hover {
        background: #f0f2f5;
      }
    }
  }
}

/* 主表单区域 */
.ruleedit .el-main {
  padding: 20px !important;
  box-shadow: 0 2px 12px rgba(0,0,0,0.1);
  border-radius: 8px;

  .el-tag {
    margin-bottom: 15px;
    font-size: 14px;
  }

  .el-form {
    background: white;
    border-radius: 8px;
    padding: 25px;
    box-shadow: 0 2px 12px rgba(0,0,0,0.1);

    .el-form-item {
      margin-bottom: 22px;

      .el-input {
        width: 300px;
      }

      .el-input__inner {
        border-radius: 4px;
      }
    }

    .el-button {
      width: 120px;
      margin-right: 10px;

      &:last-child {
        margin-right: 0;
      }
    }
  }
}

/* 响应式调整 */
@media (max-width: 768px) {
  .el-container {
    flex-direction: column;

    .el-aside {
      width: 100% !important;
      margin-top: 20px;
    }
  }
}

.rule-list-title {
    font-weight: bold;       /* 加粗字体 */
    font-size: 16px;         /* 设置字体大小 */
    color: #333;             /* 设置字体颜色 */
    margin-bottom: 10px;     /* 添加下方间距 */
    display: block;          /* 使其表现为块级元素（如果需要换行） */
    border-bottom: 2px solid #ccc; /* 添加下边框 */
    padding-bottom: 5px;     /* 下边框的内边距 */

    .el-tag {
        margin-bottom: 0px;
    }
}

.custom-table {
    display: grid;
    grid-template-rows: auto auto; /* 两行布局 */
    width: 100%;
    border: 1px solid #ccc; /* 外边框 */
}

.table-header, .body-row {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(100px, 1fr)); /* 根据内容自动调整列宽 */
}

.header-cell, .body-cell {
    padding: 10px;
    border-bottom: 1px solid #eee; /* 单元格底部边框 */
}

.header-cell {
    font-weight: bold;
    background-color: #f5f5f5; /* 表头背景色 */
    text-align: left;
}

.body-row:last-child .body-cell {
    border-bottom: none; /* 最后一行不需要底部边框 */
}

.body-cell {
    text-align: left;
}

.custom-divider {
  margin-top: 8px; /* 调整上间距 */
  margin-bottom: 8px; /* 调整下间距 */
}

.rule-name {
    font-size: 15px;
    margin-bottom: 10px;
}
</style>