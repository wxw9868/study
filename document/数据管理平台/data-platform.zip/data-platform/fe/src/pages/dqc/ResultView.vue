<template>
    <div>
        <el-container>
            <sidebar :items="sidebarItems" />
            <el-main
                class="sidebar-main"
                style="padding: 0;"
            >
                <el-row>
                    <breadcrumb :data="breadcrumbItems" />
                </el-row>
                <el-row>
                    <div
                        class="markdown-body"
                        v-html="renderedContent"
                    ></div>
                </el-row>
                <el-row justify="left">
                    <el-button
                        large
                        type="warning"
                        @click="goBack"
                    >
                        返回任务列表
                    </el-button>
                </el-row>
            </el-main>
        </el-container>
    </div>
</template>

<script>
import Breadcrumb from '../partial/Breadcrumb';
import Sidebar from '../partial/SideBar';
import config from './config';
import {ref, computed} from 'vue';
import MarkdownIt from 'markdown-it';
import hljs from 'highlight.js';
import 'highlight.js/styles/atom-one-light.css';

import * as dqcApi from '../../apis/dqc';

import {useDateFormatter} from '../common/date';

import _ from 'lodash';

export default {
    components: {
        Breadcrumb,
        Sidebar,

    },
    beforeRouteEnter(to, from, next) {
        next(vm => {
            vm.init();
        });
    },
    setup() {
        const form = ref({});
        const dateFormatter = useDateFormatter();
        const md = new MarkdownIt({
            html: true,
            linkify: true,
            typographer: true,
            breaks: true,
            highlight: function (str, lang) {
                if (lang && hljs.getLanguage(lang)) {
                    try {
                        return `<pre class="hljs"><code>${hljs.highlight(str, {language: lang}).value}</code></pre>`;
                    } catch (_) {
                        return;
                    }
                }
                return `<pre class="hljs"><code>${md.utils.escapeHtml(str)}</code></pre>`;
            },
        });

        // 计算渲染后的 HTML
        const renderedContent = computed(() => {
            console.log(md.render(form.value.mdResult || ''));
            return md.render(form.value.mdResult || '');
        });

        return {dateFormatter, md, renderedContent, form};
    },
    data: function () {
        let sidebar = _.cloneDeep(config.sidebar);
        return {
            onlyUser: '',
            sidebarItems: sidebar,
            breadcrumbItems: [],
        };
    },
    computed: {
    },
    methods: {
        init() {
            let meta = this.getMeta(this.$route);
            this.onlyUser = meta.onlyUser;
            this.page = 1;
            this.breadcrumbItems = meta.breadcrumb;
            this.loadData();
        },
        loadData() {
            if (this.$route.query.id) {
                this.loading = true;
                return dqcApi.task.get({
                    id: this.$route.query.id
                }).then(data => {
                    if (data.data.length === 0) {
                        ElMessage.error('任务不存在');
                        return;
                    }
                    this.form = data.data[0];
                    this.loading = false;
                    console.log(this.form.mdResult);
                });
            } else {
                ElMessage.error('任务不存在');
            }
        },
        getMeta(route) {
            let breadcrumb = _.cloneDeep(config.breadcrumb);
            let onlyUser = route.matched.some(record => record.meta.onlyUser);

            breadcrumb.push({
                path: '/dqc/result_view',
                title: '报告查看'
            });
            return {
                onlyUser,
                breadcrumb
            };
        },
        goBack() {
            this.$router.push({
                path: '/dqc/task_list'
            });
        }
    }
};
</script>

<style scoped>
::v-deep(.markdown-body) {
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Helvetica, Arial, sans-serif;
  line-height: 1.8;
  padding: 30px;
  color: #2d3748; /* 更柔和的深灰色 */
  word-wrap: break-word;
  background-color: #fdfdfd; /* 轻微偏白的背景色 */
  border-radius: 8px; /* 添加圆角 */
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05); /* 添加阴影 */
}

/* 标题样式 */
::v-deep(.markdown-body h1),
::v-deep(.markdown-body h2),
::v-deep(.markdown-body h3),
::v-deep(.markdown-body h4),
::v-deep(.markdown-body h5),
::v-deep(.markdown-body h6) {
  margin-bottom: 20px;
  font-weight: 700;
  line-height: 1.4;
  color: #1a202c; /* 深灰色标题 */
}

::v-deep(.markdown-body h1) {
  font-size: 2em;
  border-bottom: 2px solid #e2e8f0; /* 添加下划线效果 */
  padding-bottom: 10px;
}

::v-deep(.markdown-body h2) {
  font-size: 1.75em;
}

::v-deep(.markdown-body h3) {
  font-size: 1.5em;
}

/* 段落样式 */
::v-deep(.markdown-body p) {
  margin-top: 0;
  margin-bottom: 20px;
  font-size: 16px;
  color: #4a5568; /* 稍淡的灰色 */
}

/* 代码块样式 */
::v-deep(.markdown-body code) {
  font-family: 'SFMono-Regular', Consolas, 'Liberation Mono', Menlo, monospace;
  background-color: #edf2f7; /* 柔和的浅灰背景 */
  border-radius: 4px;
  padding: 0.2em 0.4em;
  font-size: 85%;
  color: #d63384; /* 粉色代码高亮 */
}

::v-deep(.markdown-body pre) {
  background-color: #f8fafc; /* 更浅的背景色 */
  border-radius: 6px;
  padding: 20px;
  overflow: auto;
  font-size: 85%;
  line-height: 1.5;
  border: 1px solid #e2e8f0; /* 添加边框 */
}

/* 表格样式 */
::v-deep(.markdown-body table) {
  margin-bottom: 20px;
  display: block;
  overflow-x: auto;
  border-collapse: collapse;
  width: 100%;
  font-size: 14px;
  text-align: left;
  border: 1px solid #cbd5e0; /* 柔和的边框颜色 */
  border-radius: 6px;
  overflow: hidden; /* 避免边框突出 */
}

::v-deep(.markdown-body th),
::v-deep(.markdown-body td) {
  padding: 14px;
  border: 1px solid #e2e8f0;
}

::v-deep(.markdown-body th) {
  background-color: #f0f4f8; /* 表头背景色 */
  color: #4a5568; /* 表头文字颜色 */
  font-weight: 600;
}

::v-deep(.markdown-body tr:nth-child(even)) {
  background-color: #fafafa; /* 偶数行背景色 */
}

::v-deep(.markdown-body tr:hover) {
  background-color: #edf2f7; /* 鼠标悬停效果 */
}

/* 引用块样式 */
::v-deep(.markdown-body blockquote) {
  margin: 0;
  padding: 0 1em;
  color: #718096; /* 引用文字颜色 */
  border-left: 4px solid #a0aec0; /* 引用左边框 */
  font-style: italic; /* 斜体 */
}

/* 列表样式 */
::v-deep(.markdown-body ul),
::v-deep(.markdown-body ol) {
  margin-top: 0;
  margin-bottom: 20px;
  padding-left: 2em;
}

::v-deep(.markdown-body li) {
  margin-bottom: 0.5em;
  color: #4a5568;
}

/* 高亮样式 */
::v-deep(.hljs) {
  padding: 0;
  background: transparent;
}

/* 按钮额外优化（可选） */
::v-deep(.el-button) {
  transition: all 0.3s ease; /* 添加过渡效果 */
}

::v-deep(.el-button:hover) {
  transform: translateY(-2px); /* 鼠标悬停时轻微上移 */
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15); /* 添加阴影 */
}

</style>