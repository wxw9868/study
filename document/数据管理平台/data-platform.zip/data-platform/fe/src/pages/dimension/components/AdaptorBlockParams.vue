<template>
    <div>
        <el-form-item
            label-width="80"
            label-position="left"
            style="width: 500px;"
            label="阻断类型"
            :prop="`${parentName}.type`"
            :rules="[{required: true, message: '请选择阻断类型', trigger: 'change'}]"
        >
            <el-select
                v-model="formData.type"
                placeholder="请选择阻断类型"
                @change="updateParent"
            >
                <el-option
                    value="ratio"
                    label="按比例"
                />
                <el-option
                    value="number"
                    label="按数量"
                />
            </el-select>
        </el-form-item>
        <el-form-item
            v-if="formData.type === 'number'"
            label="数量"
            label-width="80"
            label-position="left"
            :prop="`${parentName}.number`"
            :rules="[{required: true, message: '请输入数量', trigger: 'change'}]"
        >
            <el-input-number
                v-model="formData.number"
                @input="updateParent"
            />
        </el-form-item>

        <el-form-item
            v-if="formData.type === 'ratio'"
            label="比例"
            label-width="80"
            label-position="left"
            :prop="`${parentName}.ratio`"
            :rules="[{required: true, message: '请选择比例', trigger: 'change'}]"
        >
            <el-input-number
                v-model="formData.ratio"
                @input="updateParent"
            >
                <template #append>
                    %
                </template>
            </el-input-number>
        </el-form-item>
    </div>
</template>

<script>
import {defineComponent, watch, ref} from 'vue';

export default defineComponent({
    name: 'AdaptorBlockParams',
    components: {
    },

    props: {
        modelValue: {
            type: Object,
            required: true,
        },
        parentName: {
            type: String,
            required: true,
        }
    },
    emits: ['update:modelValue'],
    setup(props, {emit}) {
        const formData = ref({...props.modelValue});

        watch(
            () => props.modelValue,
            (newVal) => {
                formData.value = {...newVal};
            }
        );

        const updateParent = () => {
            emit('update:modelValue', formData.value);
        };

        return {
            formData,
            updateParent,
        };
    },
    data() {
        return {
        };
    },
});
</script>

  <style scoped>
  /* Add your styles here */
  </style>