<template>
    <div>
        <el-container>
            <sidebar :items="sidebarItems" />
            <el-main
                class="sidebar-main"
                style="padding: 0;"
            >
                <el-row>
                    <breadcrumb :data="breadcrumbItems" />
                </el-row>
                <el-row class="filter-row">
                    <el-form
                        :inline="true"
                        :model="filterForm"
                    >
                        <el-form-item label="类型">
                            <el-select
                                v-model="filterForm.type"
                                style="width: 150px"
                                placeholder="请选择操作类型"
                                clearable
                            >
                                <el-option
                                    v-for="item in eventLogsTypeList"
                                    :key="item.value"
                                    :value="item.value"
                                    :label="item.name"
                                />
                            </el-select>
                        </el-form-item>
                        <el-form-item label="维表ID">
                            <el-input
                                v-model="filterForm.did"
                                placeholder="请输入维表ID"
                            />
                        </el-form-item>
                        <el-form-item label="触发人">
                            <el-input
                                v-model="filterForm.creator"
                                placeholder="请输入邮箱前缀"
                            />
                        </el-form-item>
                        <el-form-item>
                            <el-button
                                type="success"
                                @click="delayLoad"
                            >
                                查询
                            </el-button>
                        </el-form-item>
                    </el-form>
                </el-row>
                <el-row>
                    <el-table
                        v-loading="loading"
                        :data="jobData"
                        empty-text="暂无数据"
                        border
                        style="width: 100%;"
                    >
                        <el-table-column
                            prop="did"
                            label="维表ID"
                        />
                        <el-table-column
                            prop="createTime"
                            label="操作时间"
                            :formatter="formatTableDate"
                        />
                        <el-table-column
                            prop="eventType"
                            label="留痕类型"
                        >
                            <template #default="scope">
                                {{ eventTypeMap[scope.row.eventType] || '未知类型' }}
                            </template>
                        </el-table-column>
                        <el-table-column
                            prop="content"
                            label="详细信息"
                            width="300"
                        >
                            <template #default="scope">
                                {{ truncateText(scope.row.content) }}
                                <div v-if="scope.row.content.length > 100">
                                    <json-viewer :data="scope.row.content" />
                                </div>
                            </template>
                        </el-table-column>
                        <el-table-column
                            prop="creator"
                            label="触发人"
                        />
                    </el-table>
                    <el-pagination
                        v-model:current-page="page"
                        v-model:page-size="size"
                        :page-sizes="[10, 20, 50, 100]"
                        :total="total"
                        background
                        layout="sizes, prev, pager, next"
                        @size-change="loadData"
                        @current-change="loadData"
                    />
                </el-row>
            </el-main>
        </el-container>
    </div>
</template>

<script>
import Breadcrumb from '../partial/Breadcrumb';
import Sidebar from '../partial/SideBar';
import config from './config';

import * as dimensionApi from '../../apis/dimension';
import {useDateFormatter} from '../common/date';
import JsonViewer from './components/JsonViewer';


import _ from 'lodash';

export default {
    name: 'EventLogs',
    components: {
        Breadcrumb,
        Sidebar,
        JsonViewer
    },
    beforeRouteEnter(to, from, next) {
        next(vm => {
            vm.init();
        });
    },
    setup() {
        const {formatTableDate} = useDateFormatter();
        return {formatTableDate};
    },
    data: function () {
        let sidebar = _.cloneDeep(config.sidebar);
        return {
            timeoutSign: null,
            loading: true,
            jobData: [],
            filterForm: {
                type: null,
                did: null,
                creator: null
            },
            onlyUser: '',
            sidebarItems: sidebar,
            breadcrumbItems: [],
            page: 1,
            size: 10,
            total: 10,
            echo: 0,
            eventLogsTypeList: config.eventLogsTypeList,
            eventTypeMap: config.eventTypeMap
        };
    },
    computed: {
    },
    methods: {
        init() {
            let meta = this.getMeta(this.$route);
            this.onlyUser = meta.onlyUser;
            this.page = 1;
            this.breadcrumbItems = meta.breadcrumb;
            this.loadData();
        },
        loadData() {
            this.loading = true;
            this.echo++;
            let query = {
                page: this.page,
                size: this.size,
                echo: this.echo
            };
            if (this.filterForm.did) {
                query.did = this.filterForm.did;
            }
            if (this.filterForm.type) {
                query.eventType = this.filterForm.type;
            }
            if (this.filterForm.creator) {
                query.creator = this.filterForm.creator;
            }
            dimensionApi.eventLogs.get(query).then(res => {
                if (res.status === 0 && res.echo === this.echo) {
                    this.jobData = res.data;
                    this.total = res.total;
                }
                this.loading = false;
            });
        },
        truncateText(text) {
            if (text.length > 100) {
                return text.slice(0, 100) + '...';
            }
            return text;
        },
        delayLoad() {
            if (this.timeoutSign != null) {
                clearTimeout(this.timeoutSign);
            }
            this.timeoutSign = setTimeout(() => {
                this.timeoutSign = null;
                this.page = 1;
                this.loadData();
            }, 300);
        },
        getMeta(route) {
            let breadcrumb = _.cloneDeep(config.breadcrumb);
            let onlyUser = route.matched.some(record => record.meta.onlyUser);

            breadcrumb.push({
                path: '/dimension/eventlogs',
                title: '操作日志'
            });
            return {
                onlyUser,
                breadcrumb
            };
        }
    }
};
</script>
