<template>
    <div>
        <el-form-item
            label-width="100"
            label-position="left"
            style="width: 520px;"
            label="任务类型"
            :prop="`${parentName}.activityTypeOp`"
            :rules="[{required: true, message: '', trigger: 'change'}]"
        >
            <el-select
                v-model="formData.activityTypeOp"
                placeholder="任务类型"
                style="width: 240px"
                >
                <el-option
                    v-for="item in options"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value"
                />
            </el-select>
        </el-form-item>
        <el-form-item
            label-width="100"
            label-position="left"
            style="width: 520px;"
            label="任务活动ID"
            :prop="`${parentName}.activityIdOp`"
            :rules="[{required: true, message: '请输入活动ID', trigger: 'change'}]"
        >
            <el-input
                v-model="formData.activityIdOp"
                @input="updateParent"
            />
        </el-form-item>
    </div>
</template>

<script>
import {defineComponent, watch, ref} from 'vue';

export default defineComponent({
    name: 'OperationAdaptorParams',
    components: {
    },

    props: {
        modelValue: {
            type: Object,
            required: true,
        },
        parentName: {
            type: String,
            required: true,
        }
    },
    emits: ['update:modelValue'],
    setup(props, {emit}) {
        const formData = ref({...props.modelValue});
        formData.value.activityTypeOp = 'cron_type';
        watch(
            () => props.modelValue,
            (newVal) => {
                formData.value = {...newVal};
            }
        );

        const updateParent = () => {
            emit('update:modelValue', formData.value);
        };

        return {
            formData,
            updateParent,
        };
    },
    data() {
        return {
            options: [
                { value: 'cron_type', label: '获取活动任务类型' },
            ]
        };
    }
});
</script>

  <style scoped>
  /* Add your styles here */
  </style>