<template>
    <div>
        <el-form-item
            label="提醒通知"
            :prop="`${parentName}.enabled`"
            :label-width="labelWidth"
        >
            <el-switch
                v-model="formData.enabled"
                @change="updateParent"
            />
        </el-form-item>
        <el-form-item
            v-if="formData.enabled"
            label="机器人"
            :prop="`${parentName}.robot`"
            :label-width="labelWidth"
            :rules="[{required: true, message: '请选择机器人', trigger: 'change'}]"
        >
            <robot-select
                v-model="formData.robot"
                @change="updateParent"
            />
        </el-form-item>
        <el-form-item
            v-if="formData.enabled"
            label="群号"
            :prop="`${parentName}.groupid`"
            :label-width="labelWidth"
            :rules="[{required: true, message: '请输入报警群号', trigger: 'change'}]"
        >
            <el-input
                v-model="formData.groupid"
                placeholder="报警群号"
                @input="updateParent"
            />
        </el-form-item>
    </div>
</template>

<script>

import {watch, ref} from 'vue';
import RobotSelect from '../../common/RobotSelect';

export default {
    name: 'NotieParams',
    components: {
        RobotSelect
    },
    props: {
        modelValue: {
            type: Object,
            default: () => ({})
        },
        parentName: {
            type: String,
            default: '',
            required: true
        },
        labelWidth: {
            type: String,
            default: '150'
        }
    },
    emits: ['update:modelValue'],
    setup(props, {emit}) {
        const formData = ref({...props.modelValue});
        watch(
            () => props.modelValue,
            (newVal) => {
                formData.value = {...newVal};
            }
        );

        const updateParent = () => {
            emit('update:modelValue', formData.value);
        };

        return {
            formData,
            updateParent
        };
    }
};
</script>