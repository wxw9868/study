<template>
    <div>
        <el-container>
            <sidebar :items="sidebarItems" />
            <el-main
                class="sidebar-main"
                style="padding: 0;"
            >
                <el-row>
                    <breadcrumb :data="breadcrumbItems" />
                </el-row>
                <el-row class="filter-row">
                    <el-form
                        :inline="true"
                        :model="filterForm"
                    >
                        <el-form-item label="维表ID">
                            <el-input
                                v-model="filterForm.did"
                                placeholder="请输入维表ID"
                            />
                        </el-form-item>
                        <el-form-item>
                            <el-button
                                type="success"
                                @click="loadData"
                            >
                                查询
                            </el-button>
                        </el-form-item>
                    </el-form>
                </el-row>
                <el-row>
                    <el-table
                        v-loading="loading"
                        :data="tableData"
                        empty-text="暂无数据"
                        border
                    >
                        <el-table-column
                            prop="did"
                            label="维表ID"
                        />
                        <el-table-column
                            prop="did"
                            label="维表名称"
                        >
                            {{ dataMeta.name }}
                        </el-table-column>
                        <el-table-column
                            prop="version"
                            label="数据版本"
                        />
                        <el-table-column
                            prop="commentInfo"
                            label="变更备注"
                        />
                        <el-table-column
                            prop="creator"
                            label="更新人"
                        />
                        <el-table-column
                            prop="createTime"
                            label="创建时间"
                            :formatter="formatTableDate"
                        />
                        <el-table-column
                            label="操作"
                            width="200"
                        >
                            <template #default="scope">
                                <div>
                                    <el-button
                                        size="small"
                                        type="primary"
                                        @click="viewData(scope.row.did, scope.row.version)"
                                    >
                                        查看
                                    </el-button>
                                    <el-button
                                        size="small"
                                        type="success"
                                        @click="diffData(scope.row.did, scope.row.version)"
                                    >
                                        DIFF
                                    </el-button>
                                    <el-button
                                        size="small"
                                        type="warning"
                                        @click="downloadData(scope.row.did, scope.row.version)"
                                    >
                                        下载
                                    </el-button>
                                </div>
                            </template>
                        </el-table-column>
                    </el-table>
                    <el-pagination
                        v-model:current-page="page"
                        v-model:page-size="size"
                        :page-sizes="[10, 20, 50, 100]"
                        :total="total"
                        background
                        layout="sizes, prev, pager, next"
                        @size-change="loadData"
                        @current-change="loadData"
                    />
                </el-row>
            </el-main>
            <el-dialog
                v-model="dialogTableVisible"
                title="数据查看"
                width="1000"
            >
                <div>
                    <el-table
                        :data="historyDataTableData"
                        border
                        widht="900"
                    >
                        <el-table-column
                            v-for="column in columns"
                            :key="column.prop"
                            :prop="column.prop"
                            :label="column.label"
                        />
                    </el-table>
                </div>
            </el-dialog>
            <el-dialog
                v-model="diffDialogTableVisible"
                title="数据DIFF"
                width="1000"
            >
                <div>
                    <code-diff
                        :old-string="leftData"
                        :new-string="rightData"
                        output-format="side-by-side"
                    />
                </div>
            </el-dialog>
        </el-container>
    </div>
</template>

<script>
import Breadcrumb from '../partial/Breadcrumb';
import Sidebar from '../partial/SideBar';
import config from './config';

import * as dimensionApi from '../../apis/dimension';
import {ref, watchEffect, unref} from 'vue';
import _ from 'lodash';
import {ElMessage} from 'element-plus';
import {useDateFormatter} from '../common/date';
import {CodeDiff} from 'v-code-diff';


export default {
    name: 'DataHistory',
    components: {
        Breadcrumb,
        Sidebar,
        CodeDiff
    },
    beforeRouteEnter(to, from, next) {
        next(vm => {
            vm.init();
        });
    },
    setup() {
        const columns = ref([]);
        const schema = ref({});
        const leftData = ref([]);
        const rightData = ref([]);
        const oldStr = ref('');
        const newStr = ref('');
        const {formatTableDate} = useDateFormatter();
        watchEffect(() => {
            if (!schema.value.properties) {
                return;
            }
            let order = Object.keys(schema.value.properties);
            if (schema.value.order) {
                order = schema.value.order;
            }
            columns.value = Object.values(order).map((key) => ({
                prop: key,
                label: schema.value.properties[key].title || key,
            }));
        });

        return {
            columns,
            schema,
            leftData,
            rightData,
            oldStr,
            newStr,
            formatTableDate
        };
    },
    data: function () {
        let sidebar = _.cloneDeep(config.sidebar);
        return {
            timeoutSign: null,
            loading: false,
            tableData: [],
            filterForm: {
                did: null
            },
            dataMeta: {},
            onlyUser: '',
            sidebarItems: sidebar,
            breadcrumbItems: [],
            page: 1,
            size: 10,
            total: 10,
            echo: 0,
            dataCache: {},
            metaCache: {},
            historyDataTableData: [],
            dialogTableVisible: false,
            diffDialogTableVisible: false,
        };
    },
    computed: {
    },
    methods: {
        init() {
            let meta = this.getMeta(this.$route);
            this.onlyUser = meta.onlyUser;
            this.page = 1;
            this.breadcrumbItems = meta.breadcrumb;
        },
        loadData() {
            if (_.isEmpty(this.filterForm.did)) {
                ElMessage.error('请选择要查询的维表');
                return;
            }
            this.loading = true;
            this.echo++;
            let query = {
                page: this.page,
                size: this.size,
                echo: this.echo,
                did: this.filterForm.did
            };
            dimensionApi.history.get(query).then(res => {
                if (res.status === 0 && res.echo === this.echo) {
                    this.tableData = res.data;
                    this.total = res.total;
                }
                this.loading = false;
            });
            this.fetchMeta(this.filterForm.did).then(meta => {
                this.schema = meta.dataSchema;
                this.dataMeta = meta;
            });
        },
        delayLoad() {
            if (this.timeoutSign != null) {
                clearTimeout(this.timeoutSign);
            }
            this.timeoutSign = setTimeout(() => {
                this.timeoutSign = null;
                this.page = 1;
                this.loadData();
            }, 300);
        },
        getMeta(route) {
            let breadcrumb = _.cloneDeep(config.breadcrumb);
            let onlyUser = route.matched.some(record => record.meta.onlyUser);

            breadcrumb.push({
                path: '/dimension/history',
                title: '数据历史'
            });
            return {
                onlyUser,
                breadcrumb
            };
        },
        generateCacheKey(did, version) {
            return `data-${did}-${version}`;
        },
        getDataFromCache(did, version) {
            const cacheKey = this.generateCacheKey(did, version);
            return this.dataCache[cacheKey] || null;
        },
        setDataToCache(did, version, data) {
            const cacheKey = this.generateCacheKey(did, version);
            this.dataCache[cacheKey] = data;
        },
        generateMetaKey(did) {
            return `meta-${did}`;
        },
        getMetaFromCache(did) {
            const cacheKey = this.generateMetaKey(did);
            return this.metaCache[cacheKey] || null;
        },
        setMetaToCache(did, data) {
            const cacheKey = this.generateMetaKey(did);
            this.metaCache[cacheKey] = data;
        },
        fetchData(did, version) {
            console.log('fetch data', version);
            if (version === 0) {
                return [];
            }
            console.log('fetch data..', version);
            const cachedData = this.getDataFromCache(did, version);
            if (cachedData) {
                console.log('Using cached data');
                return Promise.resolve(cachedData);
            } else {
                // 如果缓存中没有数据，则向服务器请求数据
                return dimensionApi.history.versionData({
                    did: did,
                    version: version
                }).then(res => {
                    if (res.data.content === null) {
                        return [];
                    }
                    let ret = res.data.content;
                    this.setDataToCache(did, version, ret);
                    return ret;
                }).catch(err => {
                    ElMessage.error('获取数据加载失败，请刷新页面');
                });
            }
        },
        fetchMeta(did) {
            const cachedData = this.getMetaFromCache(did);
            if (cachedData) {
                console.log('Meta Using cached data');
                return Promise.resolve(cachedData);
            } else {
                return dimensionApi.meta.get({
                    id: did
                }).then(res => {
                    this.setMetaToCache(did, res.data[0]);
                    return res.data[0];
                }).catch(_ => {
                    ElMessage.error('获取数据Meta失败，请刷新页面');
                });
            }
        },
        viewData(did, version) {
            this.fetchData(did, version).then(res => {
                this.historyDataTableData = res;
                this.dialogTableVisible = true;
            });
        },
        downloadData(did, version) {
            this.fetchData(did, version).then(res => {
                let txtContent = this.jsonListToFormattedText(res);
                const blob = new Blob([txtContent], {type: 'text/plain;charset=utf-8'});
                const url = URL.createObjectURL(blob);
                const link = document.createElement('a');
                link.href = url;
                link.download = `download_${did}_${version}.txt`;
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
                URL.revokeObjectURL(url);
            });
        },
        jsonListToFormattedText(jsonList, definedOrder) {
            if (!jsonList || jsonList.length === 0) {
                return '';
            }
            let keys = Object.keys(jsonList[0]);
            if (definedOrder) {
                keys = definedOrder;
            }
            let formatted = keys.join('\t') + '\n';
            jsonList.forEach(item => {
                const values = keys.map(key => item[key] || ''); // 处理可能不存在的属性
                formatted += values.join('\t') + '\n';
            });
            return formatted;
        },
        diffData(did, version) {
            let prom1 = this.fetchData(did, version);
            let prom2 = this.fetchData(did, version - 1);
            Promise.all([prom1, prom2]).then(res => {
                this.leftData = this.jsonListToFormattedText(res[1], unref(this.schema.order));
                this.rightData = this.jsonListToFormattedText(res[0], unref(this.schema.order));
                this.diffDialogTableVisible = true;
            }).catch(err => {console.log(err);});
        }
    }
};
</script>
