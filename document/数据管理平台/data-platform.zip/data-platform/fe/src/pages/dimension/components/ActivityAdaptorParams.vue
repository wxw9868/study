<template>
    <div>
        <el-form-item
            label="活动ID"
            :prop="`${parentName}.activityId`"
            style="width: 500px;"
            label-width="80"
            label-position="left"
            :rules="[{required: true, message: '请输入活动ID', trigger: 'change'}]"
        >
            <el-input
                v-model="formData.activityId"
                @input="updateParent"
            />
        </el-form-item>
        <el-form-item
            label="玩法ID"
            :prop="`${parentName}.playId`"
            label-width="80"
            label-position="left"
            style="width: 500px;"
            :rules="[{required: true, message: '请输入玩法ID', trigger: 'change'}]"
        >
            <el-input
                v-model="formData.playId"
                @input="updateParent"
            />
        </el-form-item>
    </div>
</template>

<script>
import {defineComponent, watch, ref} from 'vue';

export default defineComponent({
    name: 'AcitivityAdaptorParams',
    components: {
    },

    props: {
        modelValue: {
            type: Object,
            required: true,
        },
        parentName: {
            type: String,
            required: true,
        }
    },
    emits: ['update:modelValue'],
    setup(props, {emit}) {
        const formData = ref({...props.modelValue});

        watch(
            () => props.modelValue,
            (newVal) => {
                formData.value = {...newVal};
            }
        );

        const updateParent = () => {
            emit('update:modelValue', formData.value);
        };

        return {
            formData,
            updateParent,
        };
    },
    data() {
        return {
        };
    },
});
</script>

  <style scoped>
  /* Add your styles here */
  </style>