/**
 * @file config.js
 */
export default {
    sidebar: [{
        name: '维表列表',
        index: '/dimension/list',
        icon: 'el-icon-s-cooperation'
    }, {
        name: '数据历史',
        index: '/dimension/history',
        icon: 'el-icon-s-cooperation'
    }, {
        name: '操作日志',
        index: '/dimension/eventlogs',
        icon: 'el-icon-s-cooperation'
    }],
    breadcrumb: [{
        path: '/dimension/list',
        title: '维表管理'
    }],
    eventLogsTypeList: [
        {
            name: '创建维表',
            value: '1'
        },
        {
            name: '编辑维表',
            value: '2'
        },
        {
            name: '编辑数据',
            value: '3'
        },
        {
            name: '数据同步',
            value: '4'
        },
        {
            name: '自动数据配送',
            value: '5'
        },
        {
            name: '手动触发配送',
            value: '6'
        },
        {
            name: '配送版本变更',
            value: '7'
        }
    ],
    eventTypeMap: {
        '1': '创建维表',
        '2': '编辑维表',
        '3': '编辑数据',
        '4': '数据同步',
        '5': '自动数据配送',
        '6': '手动触发配送',
        '7': '配送版本变更',
    },
    // 一一对应
    targetTypeList: [
        {
            name: 'AFS',
            value: 'afs',
        }
    ],
    targetComponentMap: {
        afs: 'AfsParams'
    },

    // 数据类型
    dataTypeList: [
        {
            name: '单行数据',
            value: 1,
        },
        {
            name: '多行数据',
            value: 2
        }
    ],

    sourceTypeList: [
        {
            name: '表格管理',
            value: 1
        },
        {
            name: '外部系统',
            value: 2
        }
    ],
    // 适配器类型
    adaptorTypeList: [
        {
            name: '活动平台',
            value: 'activity'
        },
        {
            name: '如流知识库',
            value: 'ku'
        },
        {
            name: '搜索运营平台',
            value: 'operation'
        }
    ],
    adaptorParamsMap: {
        activity: 'activityAdaptorParams',
        ku: 'kuAdaptorParams',
        operation: 'operationAdaptorParams'
    },
    // 触发器类型
    triggerTypeList: [
        {
            name: '手动触发',
            value: 'manual'
        },
        {
            name: '系统触发',
            value: 'schedule'
        }
    ],
    triggerTypeParamsMap: {
        manual: 'triggerManualParams',
        schedule: 'triggerScheduleParams'
    },
};
