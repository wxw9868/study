<template>
    <div>
        <el-container>
            <sidebar :items="sidebarItems" />
            <el-main
                class="sidebar-main"
                style="padding: 0;"
            >
                <el-row>
                    <breadcrumb :data="breadcrumbItems" />
                </el-row>
                <el-row v-loading="loading">
                    <div class="box-row">
                        <el-form
                            ref="jobForm"
                            :model="jobForm"
                            label-width="150"
                            style="width: 100%;"
                            :rules="rules"
                        >
                            <el-form-item
                                label="维表名"
                                prop="name"
                                style="width: 100%;"
                            >
                                <el-input
                                    v-model="jobForm.name"
                                    :disabled="edit"
                                />
                            </el-form-item>
                            <el-form-item
                                label="维表中文名"
                                prop="chname"
                            >
                                <el-input v-model="jobForm.chname" />
                            </el-form-item>
                            <el-form-item
                                label="数据类型"
                                prop="dtype"
                            >
                                <el-segmented
                                    v-model="jobForm.dtype"
                                    :options="dataTypeList"
                                >
                                    <template #default="{ item }">
                                        <div class="flex flex-col items-center gap-2 p-2">
                                            <div>{{ item.name }}</div>
                                        </div>
                                    </template>
                                </el-segmented>
                                <el-tooltip placement="top">
                                    <template #content>
                                        1. 单行数据适用于条数小于1万行的数据，后端会把数据存储在一个字段内<br>2.如果数据量级特别大，使用多行数据，目前多行文本暂不支持
                                    </template>
                                    <el-icon>
                                        <QuestionFilled />
                                    </el-icon>
                                    <el-button>Top center</el-button>
                                </el-tooltip>
                                <!-- <el-select v-model="jobForm.dtype">
                                    <el-option
                                        v-for="item in dataTypeList"
                                        :key="item.name"
                                        :label="item.name"
                                        :value="item.value"
                                    />
                                </el-select> -->
                            </el-form-item>

                            <el-form-item
                                label="数据Schema"
                                prop="dataSchema"
                                style="width: 800px;"
                            >
                                <data-scheme
                                    v-model="jobForm.dataSchema"
                                    class="data-scheme"
                                />
                            </el-form-item>
                            <el-form-item
                                label="源数据类型"
                                prop="stype"
                            >
                                <el-segmented
                                    v-model="jobForm.stype"
                                    :options="sourceTypeList"
                                >
                                    <template #default="{ item }">
                                        <div class="flex flex-col items-center gap-2 p-2">
                                            <div>{{ item.name }}</div>
                                        </div>
                                    </template>
                                </el-segmented>
                                <el-tooltip placement="top">
                                    <template #content>
                                        1. 表格管理指的是数据在本平台上面编辑<br>2.外部系统指的是将外部数据源同步到平台，平台上只允许查看，不允许编辑
                                    </template>
                                    <el-icon>
                                        <QuestionFilled />
                                    </el-icon>
                                </el-tooltip>
                                <!-- <el-select
                                    v-model="jobForm.stype"
                                    placeholder="原数据类型"
                                >
                                    <el-option
                                        v-for="item in sourceTypeList"
                                        :key="item.name"
                                        :label="item.name"
                                        :value="item.value"
                                    />
                                </el-select> -->
                            </el-form-item>
                            <el-divider />

                            <div v-if="jobForm.stype===2">
                                <el-form-item
                                    label="外部数据适配器"
                                    prop="adaptor"
                                >
                                    <el-segmented
                                        v-model="jobForm.adaptor"
                                        :options="adaptorTypeList"
                                    >
                                        <template #default="{ item }">
                                            <div class="flex flex-col items-center gap-2 p-2">
                                                <div>{{ item.name }}</div>
                                            </div>
                                        </template>
                                    </el-segmented>
                                    <!-- <el-select
                                        v-model="jobForm.adaptor"
                                        placeholder="选择适配器"
                                    >
                                        <el-option
                                            v-for="item in adaptorTypeList"
                                            :key="item.name"
                                            :label="item.name"
                                            :value="item.value"
                                        />
                                    </el-select> -->
                                </el-form-item>
                                <el-form-item
                                    v-if="jobForm.adaptor"
                                    label="适配器参数"
                                    prop="adaptorParams"
                                >
                                    <component
                                        :is="getAdaptorParamsComponent"
                                        v-model="jobForm.adaptorParams"
                                        parent-name="adaptorParams"
                                    />
                                </el-form-item>
                                <el-form-item
                                    label="适配器触发参数"
                                    prop="adaptorTriggerParams"
                                >
                                    <trigger-schedule-params
                                        v-model="jobForm.adaptorTriggerParams"
                                        parent-name="adaptorTriggerParams"
                                    />
                                </el-form-item>

                                <el-form-item
                                    label="适配器阻断参数"
                                    prop="adaptorBlockParams"
                                >
                                    <adaptor-block-params
                                        v-model="jobForm.adaptorBlockParams"
                                        parent-name="adaptorBlockParams"
                                    />
                                    <el-tooltip placement="top">
                                        <template #content>
                                            超过制定阈值后，会阻断自动更新
                                        </template>
                                        <el-icon>
                                            <QuestionFilled />
                                        </el-icon>
                                    </el-tooltip>
                                </el-form-item>
                                <el-divider />
                            </div>

                            <el-form-item
                                label="目标配置类型"
                                prop="targetType"
                            >
                                <el-segmented
                                    v-model="jobForm.targetType"
                                    :options="targetTypeList"
                                >
                                    <template #default="{ item }">
                                        <div class="flex flex-col items-center gap-2 p-2">
                                            <div>{{ item.name }}</div>
                                        </div>
                                    </template>
                                </el-segmented>
                                <!-- <el-select
                                    v-model="jobForm.targetType"
                                    placeholder="选择目标配置类型"
                                >
                                    <el-option
                                        v-for="item in targetTypeList"
                                        :key="item.name"
                                        :label="item.label"
                                        :value="item.name"
                                    />
                                </el-select> -->
                            </el-form-item>


                            <el-form-item
                                label="目的地参数"
                                prop="targetParams"
                            >
                                <component
                                    :is="getTargetParamsComponent"
                                    v-model="jobForm.targetParams"
                                    parent-name="targetParams"
                                />
                            </el-form-item>

                            <el-divider />


                            <el-form-item
                                label="触发器类型"
                                prop="triggerType"
                            >
                                <el-segmented
                                    v-model="jobForm.triggerType"
                                    :options="triggerTypeList"
                                >
                                    <template #default="{ item }">
                                        <div class="flex flex-col items-center gap-2 p-2">
                                            <div>{{ item.name }}</div>
                                        </div>
                                    </template>
                                </el-segmented>
                                <el-tooltip placement="top">
                                    <template #content>
                                        1. 手动配送：编辑数据后，平台上手动点击配送按钮触发配送<br>2.系统触发：由系统来自动触发配送
                                    </template>
                                    <el-icon>
                                        <QuestionFilled />
                                    </el-icon>
                                    <el-button>Top center</el-button>
                                </el-tooltip>
                                <!-- <el-select
                                    v-model="jobForm.triggerType"
                                    placeholder="选择触发器类型"
                                >
                                    <el-option
                                        v-for="item in triggerTypeList"
                                        :key="item.name"
                                        :label="item.name"
                                        :value="item.value"
                                    />
                                </el-select> -->
                            </el-form-item>
                            <el-form-item
                                label="触发器参数"
                                prop="triggerParams"
                            >
                                <component
                                    :is="getTriggerParamsComponent"
                                    v-model="jobForm.triggerParams"
                                    parent-name="triggerParams"
                                />
                            </el-form-item>

                            <el-divider />
                            <el-form-item
                                label="提醒配置"
                                prop="noticeConfig"
                            >
                                <notice-params
                                    v-model="jobForm.noticeConfig"
                                    parent-name="noticeConfig"
                                />
                            </el-form-item>
                            <el-form-item
                                label="报警配置"
                                prop="alarmConfig"
                            >
                                <alarm-params
                                    v-model="jobForm.alarmConfig"
                                    parent-name="alarmConfig"
                                />
                            </el-form-item>
                            <el-form-item>
                                <el-button
                                    type="primary"
                                    size="large"
                                    @click="submitForm"
                                >
                                    提交
                                </el-button>
                                <el-button
                                    v-if="edit"
                                    size="large"
                                    type="danger"
                                    @click="deleteJob"
                                >
                                    删除
                                </el-button>
                                <el-button
                                    size="large"
                                    @click="cancelForm"
                                >
                                    取消
                                </el-button>
                            </el-form-item>
                        </el-form>
                    </div>
                </el-row>
            </el-main>
        </el-container>
    </div>
</template>

<script>
import * as dimensionApi from '../../apis/dimension';
import Breadcrumb from '../partial/Breadcrumb';
import Sidebar from '../partial/SideBar';
import config from './config';
import _ from 'lodash';
import AfsParams from './components/AfsParams';
import ActivityAdaptorParams from './components/ActivityAdaptorParams';
import KuAdaptorParams from './components/KuAdaptorParams';
import OperationAdaptorParams from './components/OperationAdaptorParams';
import TriggerScheduleParams from './components/TriggerScheduleParams';
import DataScheme from './components/DataScheme';
import AlarmParams from './components/AlarmParams';
import NoticeParams from './components/NoticeParams';
import AdaptorBlockParams from './components/AdaptorBlockParams';
import {ElMessage} from 'element-plus';

const emptyForm = {
    name: '',
    chname: '',
    dataSchema: {},
    targetType: '',
    targetParams: {},
    dtype: 1,
    stype: 1,
    adaptor: '',
    adaptorParams: {},
    adaptorTriggerParams: {},
    adaptorBlockParams: {},
    triggerType: '',
    triggerParams: {},
    alarmConfig: {},
    status: 0
};

export default {
    components: {
        Breadcrumb,
        Sidebar,
        AfsParams,
        ActivityAdaptorParams,
        KuAdaptorParams,
        OperationAdaptorParams,
        TriggerScheduleParams,
        DataScheme,
        AlarmParams,
        NoticeParams,
        AdaptorBlockParams
    },
    beforeRouteEnter(to, from, next) {
        next(vm => {
            vm.init();
        });
    },
    data: function () {
        let meta = this.getMeta(this.$route);
        let sidebar = _.cloneDeep(config.sidebar);
        return {
            loading: false,
            timeoutSign: null,
            jobForm: _.cloneDeep(emptyForm),
            rules: {
                name: [{
                    required: true,
                    message: '请输入维表名称'
                }, {
                    validator: this.nameValid,
                    trigger: 'blur'
                }],
                chname: [{
                    required: true,
                    message: '请输入中文名称'
                }],
                stype: [{
                    required: true,
                    message: '请选择源数据类型'
                }],
                targetType: {
                    required: true,
                    message: '请选择目标配置类型'
                },
                dtype: {
                    required: true,
                    message: '请选择数据类型'
                },
                adaptor: {
                    required: true,
                    message: '外部数据请选择数据适配器并填写适配器参数'
                },
                triggerType: {
                    required: true,
                    message: '请选择触发类型'
                },
                adaptorParams: {
                    required: true,
                    message: '请填写适配器参数'
                },
                targetParams: {
                    required: true,
                    message: '请填写目的地参数'
                },
                triggerParams: {
                    required: true,
                    message: '请填写触发器参数'
                },
                dataSchema: [{
                    required: true,
                    message: '请输入数据schema'
                }, {
                    validator: this.jsonSchemaValid,
                    trigger: 'blur'
                }]
            },
            sidebarItems: sidebar,
            breadcrumbItems: meta.breadcrumb,
            edit: meta.edit,
            targetTypeList: config.targetTypeList,
            targetComponentMap: config.targetComponentMap,
            dataTypeList: config.dataTypeList,
            sourceTypeList: config.sourceTypeList,
            adaptorTypeList: config.adaptorTypeList,
            adaptorParamsMap: config.adaptorParamsMap,
            triggerTypeList: config.triggerTypeList,
            triggerTypeParamsMap: config.triggerTypeParamsMap
        };
    },
    computed: {
        getTargetParamsComponent() {
            return this.targetComponentMap[this.jobForm.targetType];
        },
        getAdaptorParamsComponent() {
            return this.adaptorParamsMap[this.jobForm.adaptor];
        },
        getTriggerParamsComponent() {
            return this.triggerTypeParamsMap[this.jobForm.triggerType];
        }
    },

    methods: {
        init() {
            this.loadData();
        },
        delayLoad() {
            if (this.timeoutSign != null) {
                clearTimeout(this.timeoutSign);
            }
            this.timeoutSign = setTimeout(() => {
                this.timeoutSign = null;
                this.loadTemplate();
            }, 300);
        },
        loadData() {
            if (this.$route.query.name) {
                this.loading = true;
                dimensionApi.meta.get({
                    name: this.$route.query.name
                }).then(data => {
                    if (data.data.length === 0) {
                        ElMessage.error('任务不存在');
                        return;
                    }
                    this.jobForm = data.data[0];
                    this.jobForm.createTime = undefined;
                    this.jobForm.updateTime = undefined;
                    this.loading = false;
                });
            } else {
                return;
            }
        },

        getMeta(route) {
            let breadcrumb = _.cloneDeep(config.breadcrumb);
            let edit = !!route.query.name;
            if (edit) {
                breadcrumb.push({
                    path: '/dimension/edit',
                    title: '编辑任务'
                });
            } else {
                breadcrumb.push({
                    path: '/dimension/edit',
                    title: '新建任务'
                });
            }
            return {
                breadcrumb,
                edit
            };
        },
        submitForm() {
            this.$refs.jobForm.validate(valid => {
                if (valid) {
                    if (this.jobForm.id != null) {
                        this.jobForm.version = undefined;
                        dimensionApi.meta.patch(this.jobForm.id, this.jobForm).then(res => {
                            if (res.status === 0) {
                                this.$router.push('/dimension/list').catch(() => {});
                            }
                        });
                    } else {
                        dimensionApi.meta.post(this.jobForm).then(res => {
                            if (res.status === 0) {
                                this.$router.push('/dimension/list').catch(() => {});
                            }
                        });
                    }
                } else {
                    ElMessage.error('表单验证失败');
                }
            });
        },
        cancelForm() {
            this.$router.push('/dimension/list').catch(() => {});
        },
        nameValid(rule, value, callback) {
            if (!/^[a-zA-Z0-9_.]*$/.test(value)) {
                callback(new Error('请输入合法字符：[a-zA-Z0-9_.]'));
                return;
            }
            callback();
        },
        emailValid(rule, value, callback) {
            if (!/^[a-zA-Z0-9_;]*$/.test(value)) {
                callback(new Error('email必须是分号分割的uuap用户'));
                return;
            }
            callback();
        },
        messageValid(rule, value, callback) {
            if (!/^[a-zA-Z0-9_,]*$/.test(value)) {
                callback(new Error('短信接收列表必须是逗号' + '","' + '分割的uuap用户或手机号'));
                return;
            }
            callback();
        },
        jsonSchemaValid(rule, value, callback) {
            if (!value.properties || typeof value.properties !== 'object') {
                callback(new Error('schema非法'));
                return;
            }
            let valid = true;
            let msg = '';
            Object.keys(value.properties).forEach(propertyName => {
                const property = value.properties[propertyName];
                if (!property.title) {
                    msg = `属性"${propertyName}"没有 "title"属性，这个词会作为字段名，请设置`;
                    valid = false;
                }
            });
            if (value.order && value.order.length !== Object.keys(value.properties).length) {
                callback(new Error('order长度必须等于properties的长度'));
                return;
            }
            if (!valid) {
                callback(new Error(msg));
                return;
            }
            callback();
        },
        deleteJob() {
            let name = this.$route.query.name;
            this.$confirm(`确认删除${name}么？`, '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'error'
            }).then(() => {
                dimensionApi.meta.delete({
                    pdb: this.$route.query.pdb,
                    name: name
                }).then(res => {
                    if (res.status === 0) {
                        this.$router.push('/dimension/list').catch(() => {});
                    }
                });
            });
        },
    }
};
</script>

<style scoped>
.el-alert {
    padding: 0;
}

.data-scheme {
    width: 100%;
    height: 300px;
    overflow-y: scroll;
}
</style>