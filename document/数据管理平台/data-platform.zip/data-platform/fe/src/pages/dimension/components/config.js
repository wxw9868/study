export default {
    AfsClusterList: [
        {
            name: 'wudang',
            path: 'afs://wudang.afs.baidu.com:9902'
        },
        {
            name: 'wolong',
            path: 'afs://wolong.afs.baidu.com:9902'
        },
        {
            name: 'kunpeng',
            path: 'afs://kunpeng.afs.baidu.com:9902'
        },
        {
            name: 'baihua',
            path: 'afs://baihua.afs.baidu.com:9902'
        },
        {
            name: 'cnn-bd-main',
            path: 'afs://cnn-bd-main.afs.baidu.com:9902',
        },
        {
            name: 'xingtian',
            path: 'afs://xingtian.afs.baidu.com:9902'
        }
    ]
};