<template>
    <div>
        <el-button
            type="primary"
            text
            @click="showDialog"
        >
            查看详情
        </el-button>
        <el-dialog
            v-model="dialogVisible"
            title="详细数据"
            width="800"
            append-to-body
        >
            <pre>{{ formattedJson }}</pre>
        </el-dialog>
    </div>
</template>

<script>
import {ref} from 'vue';

export default {
    name: 'JsonViewer',
    props: {
        data: {
            type: String,
            required: true,
        },
    },
    setup(props) {
        const dialogVisible = ref(false);
        const formattedJson = ref('');

        const showDialog = () => {
            try {
                const jsonObj = JSON.parse(props.data);
                formattedJson.value = JSON.stringify(jsonObj, null, 2);
                dialogVisible.value = true;
            } catch (error) {
                alert('无效的 JSON 字符串');
            }
        };

        return {
            dialogVisible,
            formattedJson,
            showDialog,
        };
    },
};
</script>

  <style scoped>
  /* 可选：添加一些样式 */
  </style>