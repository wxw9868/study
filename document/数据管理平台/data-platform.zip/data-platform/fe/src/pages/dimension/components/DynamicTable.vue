<template>
    <div>
        <el-alert
            v-if="!editable"
            title="数据外部系统同步，不允许系统重复编辑"
            type="info"
            :closable="false"
        />

        <el-button
            v-if="editable"
            type="primary"
            @click="addRow"
        >
            添加单条
        </el-button>
        <el-button
            v-if="editable"
            type="warning"
            @click="addMultiRow"
        >
            添加多条
        </el-button>

        <el-button
            v-if="editable"
            type="danger"
            @click="filterDupRow"
        >
            数据去重
        </el-button>

        <el-button
            v-if="editable && dupRowIndexList.length > 0"
            type="danger"
            @click="confirmFilterDupRow"
        >
            确认数据去重
        </el-button>
        <!-- <el-upload
            action="#"
            :on-change="handleFileUpload"
            :before-upload="beforeUpload"
            :file-list="fileList"
            :on-remove="handleRemove"
            :limit="1"
            :on-exceed="handleExceed"
            accept=".csv"
        >
            <template #trigger>
                <el-button
                    type="primary"
                >
                    通过文件上传
                </el-button>
            </template>
            <template #tip>
                <div class="el-upload__tip">
                    只能上传.csv文件
                </div>
            </template>
        </el-upload> -->
        <!-- <el-button
            v-if="editable"
            type="success"
            @click="parseUploadFile"
        /> -->
        <el-table
            ref="tableRef"
            :data="tableData"
            border
            height="1000"
        >
            <el-table-column
                v-if="dupRowIndexList.length > 0"
                type="selection"
                width="55"
            />
            <el-table-column
                type="index"
                width="100"
                label="序号"
            />
            <el-table-column
                v-for="column in columns"
                :key="column.prop"
                :prop="column.prop"
                :label="column.label"
            />
            <el-table-column
                v-if="editable"
                align="right"
                width="150"
                label="操作"
            >
                <!-- <template #header>
                    <el-input
                        v-model="search"
                        size="small"
                        placeholder="Type to search"
                    />
                </template> -->

                <template
                    #default="scope"
                >
                    <el-button
                        v-if="editable"
                        size="small"
                        @click="handleEdit(scope.$index, scope.row)"
                    >
                        Edit
                    </el-button>
                    <el-button
                        v-if="editable"
                        size="small"
                        type="danger"
                        @click="removeRow(scope.$index)"
                    >
                        Delete
                    </el-button>
                </template>
            </el-table-column>
        </el-table>


        <el-dialog
            v-model="dialogTableVisible"
            title="添加行"
            width="500"
        >
            <div>
                <vue-form
                    v-model="formData"
                    :schema="schema"
                    @submit="confirmAdd"
                />
            </div>
        </el-dialog>

        <el-dialog
            v-model="dialogMultiRowVisible"
            title="添加多行"
            width="800"
        >
            <el-table
                :data="[]"
                style="width: 100%"
                empty-text=""
            >
                <template #empty>
                    请按照顺序输入数据\t分割
                </template>
                <el-table-column
                    v-for="column in columns"
                    :key="column.prop"
                    :prop="column.prop"
                    :label="column.label"
                    width="180"
                />
            </el-table>
            <el-form :model="multiRowFormData">
                <el-form-item
                    label=""
                    label-width="0"
                >
                    <el-input
                        v-model="multiRowFormData.text"
                        autocomplete="off"
                        type="textarea"
                        :autosize="{ minRows: 10 }"
                        @keydown="handleTabKey"
                    />
                </el-form-item>
            </el-form>
            <template #footer>
                <div class="dialog-footer">
                    <el-button @click="dialogMultiRowVisible = false">
                        取消
                    </el-button>
                    <el-button
                        type="primary"
                        @click="confirmAddMultiRow"
                    >
                        确认
                    </el-button>
                </div>
            </template>
        </el-dialog>
        <el-dialog
            v-model="dialogPreviewVisible"
            title="解析数据预览"
            width="800"
        >
            <el-table :data="previewTableData">
                <el-table-column
                    v-for="column in columns"
                    :key="column.prop"
                    :prop="column.prop"
                    :label="column.label"
                />
            </el-table>
            <template #footer>
                <div class="dialog-footer">
                    <el-button @click="dialogPreviewVisible = false">
                        取消
                    </el-button>
                    <el-button
                        type="primary"
                        @click="confirmPreviewData"
                    >
                        确认
                    </el-button>
                </div>
            </template>
        </el-dialog>
    </div>
</template>

<script>
import {defineComponent, ref, watch, watchEffect, unref, reactive} from 'vue';
import Ajv from 'ajv';
import VueForm from '@lljj/vue3-form-element';
import _ from 'lodash';
import * as dimensionApi from '../../../apis/dimension';
import {ElMessage, ElMessageBox} from 'element-plus';
import {useUniqueByKeys} from '../../common/unique';

export default defineComponent({
    components: {
        VueForm
    },
    props: {
        schema: {
            type: Object,
            required: true,
        },
        modelValue: {
            type: Array,
            required: true,
        },
        editable: {
            type: Boolean,
            default: false
        },
        metaId: {
            type: String,
            required: true
        }
    },
    emits: ['update:modelValue'],
    setup(props, {emit}) {
        const columns = ref([]);
        const dialogTableVisible = ref(false);
        const dialogFormVisible = ref(false);
        const dialogMultiRowVisible = ref(false);
        const dialogPreviewVisible = ref(false);
        const formData = ref({});
        const formLabelWidth = '140px';

        const {uniqueByKeys} = useUniqueByKeys();
        const tableData = ref(props.modelValue);
        const errors = ref([]);
        const validColumns = ref([]);
        const columnNameWithOrder = ref([]);
        const dupRowIndexList = ref([]);
        const newTableData = ref([]);
        const tableRef = ref(null);
        const previewTableData = ref([]);

        const uniqueKeys = ref([]);

        const multiRowFormData = reactive({
            text: ''
        });
        const ajv = new Ajv();
        let validate = ajv.compile(props.schema);

        const editModeState = reactive(
            {
                editMode: false,
                editIndex: -1
            }
        );

        // const fileList = ref([]);
        // const parsedData = ref([]);

        // const handleRemove = (file, fileList) => {
        //     parsedData.value = [];
        // };


        // const parseMultilineString = (data) => {
        //     let parseReq = {
        //         id: props.metaId,
        //         text: data,
        //     };
        //     dimensionApi.meta.parseText(parseReq).then(res => {
        //         console.log(res);
        //     });
        //     const lines = data.split('\n').filter(Boolean);
        //     const result = [];
        //     lines.forEach(line => {
        //         const values = line.split('\t');
        //         const obj = {};
        //         if (values.length !== columnNameWithOrder.value.length) {
        //             return;
        //         }
        //         columnNameWithOrder.value.forEach((header, index) => {
        //             obj[header] = values[index];
        //         });
        //         if (Object.keys(obj).length === validColumns.value.length) {
        //             result.push(obj);
        //         }
        //     });
        //     return result;
        // };

        // const parseCSVContent = (content) => {
        //     return parseMultilineString(content);
        // };

        // const handleFileUpload = (file, fileList) => {
        //     const reader = new FileReader();
        //     reader.onload = (e) => {
        //         const content = e.target.result;
        //         parsedData.value = parseCSVContent(content);
        //     };
        //     reader.readAsText(file.raw); // 注意：这里使用了file.raw来获取原始的File对象
        // };

        const validateData = () => {
            errors.value = [];
            tableData.value.forEach((row, index) => {
                const valid = validate(row);
                if (!valid) {
                    validate.errors.forEach((err) => {
                        errors.value.push(`Row ${index + 1}: ${err.message}`);
                    });
                }
            });
        };

        const addRow = () => {
            formData.value = {};
            dialogTableVisible.value = true;
        };

        const removeRow = (index) => {
            tableData.value.splice(index, 1);
        };


        const addMultiRow = () => {
            multiRowFormData.text = '';
            dialogMultiRowVisible.value = true;
        };
        const filterDupRow = () => {
            let [uniqueRows, dupIndex] = uniqueByKeys(tableData.value, uniqueKeys.value);
            if (dupIndex.length <= 0) {
                ElMessage.success('未检测到重复数据');
                return;
            }
            dupRowIndexList.value = dupIndex;
            newTableData.value = uniqueRows;
            dupIndex.forEach((index) => {
                tableRef.value.toggleRowSelection(tableData.value[index], true);
            });
            let message = `共检测出${dupRowIndexList.value.length}条重复数据，请check后点击【确认数据去重】按钮。去重后数据不会保存，请点击保存按钮`;
            ElMessageBox.alert(message, '重复检测提醒', {
                confirmButtonText: '我知道了',
            });
        };
        const confirmFilterDupRow = () => {
            tableData.value = newTableData.value;
            dupRowIndexList.value = [];
            newTableData.value = [];
            ElMessage.success('已去重');
        };
        const removeDupRows = () => {
            const uniqueRows = uniqueByKeys(tableData.value, uniqueKeys.value);
            tableData.value = uniqueRows;
        };

        const confirmAddMultiRow = () => {
            // let dataParsed = parseMultilineString(multiRowFormData.text);
            let parseReq = {
                id: props.metaId,
                text: multiRowFormData.text,
            };
            dimensionApi.meta.parseText(parseReq).then(res => {
                let dataParsed = res.data;
                let filterRow = [];
                previewTableData.value = [];
                dataParsed.forEach((row) => {
                    if (validate(row)) {
                        filterRow.push(row);
                        // tableData.value.push(row);
                        previewTableData.value.push(row);
                    }
                });
                ElMessage.success(`共解析出${dataParsed.length}条数据， 验证${filterRow.length}行数据`);
                // dialogMultiRowVisible.value = false;
                if (previewTableData.value.length > 0) {
                    dialogPreviewVisible.value = true;
                }
            });

        };

        const confirmPreviewData = () => {
            for (let i = 0; i < previewTableData.value.length; i++) {
                tableData.value.push(_.clone(previewTableData.value[i]));
            }
            dialogPreviewVisible.value = false;
            dialogMultiRowVisible.value = false;
        };
        const parseUploadFile = (file) => {
            ElMessage.success('todo');
        };
        const confirmAdd = (data) => {
            if (editModeState.editMode === true) {
                tableData.value[editModeState.editIndex] = _.clone(unref(data));
                editModeState.editMode = false;
            } else {
                tableData.value.push(_.clone(unref(data)));
            }
            dialogTableVisible.value = false;
        };

        const handleEdit = (index, row) => {
            formData.value = _.clone(row);
            editModeState.editIndex = index;
            editModeState.editMode = true;
            dialogTableVisible.value = true;
        };

        const handleTabKey = (event) => {
            if (event.key === 'Tab') {
                event.preventDefault();
                // 这里可以添加自定义逻辑
                multiRowFormData.text += '\t';
            }
        };
        watchEffect(() => {
            let order = Object.keys(props.schema.properties);
            if (props.schema.order) {
                order = props.schema.order;
            }
            columnNameWithOrder.value = order;
            columns.value = Object.values(order).map((key) => ({
                prop: key,
                label: props.schema.properties[key].title || key,
            }));
            validColumns.value = Object.keys(props.schema.properties);
            validate = ajv.compile(props.schema);

            let customUniqueKeys = order;
            if (props.modelValue.uniqueKeys) {
                customUniqueKeys = props.modelValue.uniqueKeys;
            }
            uniqueKeys.value = customUniqueKeys;
        });
        watch(() => props.modelValue, (newVal) => {
            tableData.value = newVal;
        });
        watch(tableData, (newVal) => {
            emit('update:modelValue', newVal);
        });

        return {
            columns,
            tableData,
            validateData,
            errors,
            addRow,
            addMultiRow,
            removeRow,
            confirmAdd,
            handleEdit,
            parseUploadFile,
            confirmAddMultiRow,
            editModeState,
            dialogTableVisible,
            dialogFormVisible,
            dialogMultiRowVisible,
            dialogPreviewVisible,
            formLabelWidth,
            formData,
            multiRowFormData,
            dupRowIndexList,
            tableRef,
            previewTableData,
            uniqueByKeys,
            removeDupRows,
            filterDupRow,
            confirmFilterDupRow,
            confirmPreviewData,
            handleTabKey
        };
    },
    data() {
        return {
        };
    },
});
</script>

  <style>

  .el-table .warning-row {
  --el-table-tr-bg-color: var(--el-color-warning-light-9);
}
  </style>