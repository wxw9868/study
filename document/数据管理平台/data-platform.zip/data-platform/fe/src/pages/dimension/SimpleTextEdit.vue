<template>
    <div>
        <el-container>
            <sidebar :items="sidebarItems" />
            <el-main
                class="sidebar-main"
                style="padding: 0;"
            >
                <el-row>
                    <breadcrumb :data="breadcrumbItems" />
                </el-row>
                <el-row>
                    <dynamic-table
                        v-model="tableData"
                        style="width:100%;margin:auto;"
                        :schema="dataSchema"
                        :meta-id="$route.query.id"
                        :editable="dataEditable"
                    />
                </el-row>
                <el-row>
                    <el-button
                        v-if="dataEditable"
                        type="success"
                        @click="confirmSave"
                    >
                        保存
                    </el-button>
                    <el-button
                        v-if="manualDeliver"
                        type="warning"
                        @click="confirmDeliver"
                    >
                        配送
                    </el-button>
                </el-row>
            </el-main>
        </el-container>

        <el-dialog
            v-model="dialogFormVisible"
            title="数据变更"
            width="500"
        >
            <el-form
                ref="saveForm"
                :model="form"
                :rules="rules"
            >
                <el-form-item
                    label="变更备注"
                    label-width="100"
                    prop="commentInfo"
                >
                    <el-input
                        v-model="form.commentInfo"
                        autocomplete="off"
                    />
                </el-form-item>
            </el-form>
            <template #footer>
                <div class="dialog-footer">
                    <el-button @click="dialogFormVisible = false">
                        取消
                    </el-button>
                    <el-button
                        type="primary"
                        @click="save"
                    >
                        确认修改
                    </el-button>
                </div>
            </template>
        </el-dialog>
    </div>
</template>

<script>
import Breadcrumb from '../partial/Breadcrumb';
import Sidebar from '../partial/SideBar';
import config from './config';
import DynamicTable from './components/DynamicTable';
import {ElMessage, ElMessageBox} from 'element-plus';
import * as dimensionApi from '../../apis/dimension';
import {useUniqueByKeys} from '../common/unique';

import _ from 'lodash';

export default {
    name: 'SimpleTextEdit',
    components: {
        Breadcrumb,
        Sidebar,
        DynamicTable
    },
    beforeRouteEnter(to, from, next) {
        next(vm => {
            vm.init();
        });
    },
    setup() {
        const {uniqueByKeys} = useUniqueByKeys();

        return {
            uniqueByKeys
        };
    },
    data: function () {
        let sidebar = _.cloneDeep(config.sidebar);
        return {
            timeoutSign: null,
            loading: true,
            jobData: [],
            filterForm: {
                word: ''
            },
            meta: {},
            tableData: [],
            onlyUser: '',
            originTableData: [],
            sidebarItems: sidebar,
            breadcrumbItems: [],
            dataSchema: {
                'properties': {
                    test: {
                        type: 'string'
                    }
                }
            },
            page: 1,
            size: 10,
            total: 10,
            echo: 0,
            dataCache: {},
            dialogFormVisible: false,
            form: {
                commentInfo: ''
            },
            rules: {
                commentInfo: [
                    {
                        required: true,
                        message: '请输入变更备注',
                    }
                ]
            }
        };
    },
    computed: {
        dataEditable() {
            if (this.meta.stype === 1) {
                return true;
            }
            return false;
        },
        manualDeliver() {
            if (this.meta.triggerType === 'manual') {
                return true;
            }
            return false;
        }
    },
    methods: {
        init() {
            let meta = this.getMeta(this.$route);
            this.onlyUser = meta.onlyUser;
            this.page = 1;
            this.breadcrumbItems = meta.breadcrumb;
            this.loadMeta();
        },
        loadMeta() {
            this.loading = true;
            this.echo++;
            let query = {
                pdb: this.$route.query.pdb,
                name: this.$route.query.name,
                echo: this.echo
            };
            dimensionApi.meta.get(query).then(res => {
                if (res.status === 0 && res.echo === this.echo) {
                    this.meta = res.data[0];
                    this.dataSchema = this.meta.dataSchema;
                }
                this.loading = false;
            });
            query = {
                did: this.$route.query.id,
            };
            dimensionApi.history.latestData(query).then(res => {
                if (res.data == null || res.data.content == null) {
                    this.tableData = [];
                    this.originTableData = [];
                } else {
                    this.tableData = res.data.content;
                    this.originTableData = _.cloneDeep(res.data.content);
                }
            });
        },
        getMeta(route) {
            let breadcrumb = _.cloneDeep(config.breadcrumb);
            let onlyUser = route.matched.some(record => record.meta.onlyUser);

            breadcrumb.push({
                path: '/dimension/edit',
                title: '数据编辑'
            });
            return {
                onlyUser,
                breadcrumb
            };
        },
        confirmSave() {
            if (_.isEqual(this.tableData, this.originTableData)) {
                ElMessage.error('未检测到任何修改');
                return;
            }
            this.form.commentInfo = '';
            this.dialogFormVisible = true;
        },
        confirmDeliver() {
            ElMessageBox.confirm(
                '将会触发配送最新版本，是否继续?',
                '操作确认',
                {
                    confirmButtonText: '确认',
                    cancelButtonText: '取消',
                    type: 'success',
                }
            ).then(() => {
                dimensionApi.meta.deliverData({
                    id: this.$route.query.id,
                    version: 0
                }).then(res => {
                    ElMessage({
                        type: 'success',
                        message: `${res.msg} 触发成功`,
                    });
                }).catch(() => {});

            }).catch(() => {
                ElMessage({
                    type: 'info',
                    message: '操作取消',
                });
            });
        },
        save() {
            this.$refs.saveForm.validate(valid => {
                if (valid) {
                    let postData = {
                        did: parseInt(this.$route.query.id, 10),
                        content: this.tableData,
                        commentInfo: this.form.commentInfo
                    };
                    dimensionApi.history.publishData(postData).then(res => {
                        ElMessage.success('保存成功');
                        this.$router.push('/dimension/list').catch(() => {});
                    });
                }
            });

        }
    }
};
</script>
