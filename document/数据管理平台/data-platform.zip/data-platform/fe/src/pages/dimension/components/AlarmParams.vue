<template>
    <div>
        <el-form-item
            label="延迟更新报警"
            :prop="`${parentName}.enabled`"
            label-width="150"
        >
            <el-switch
                v-model="formData.enabled"
                @change="updateParent"
            />
        </el-form-item>
        <el-form-item
            v-if="formData.enabled"
            label="预期完成时间"
            :prop="`${parentName}.basedTime`"
            :rules="[{required: true, message: '请输入期望完成时间', trigger: 'change'}]"
            label-width="150"
        >
            <el-time-picker
                v-model="formData.basedTime"
                :disabled-seconds="disabledSeconds"
                :disabled-minutes="disabledMinutes"
                value-format="HH:mm"
                @change="updateParent"
            />
        </el-form-item>
        <el-form-item
            v-if="formData.enabled"
            label="超时时间（分钟）"
            :prop="`${parentName}.timeout`"
            label-width="150"
            :rules="[{required: true, message: '请输入超时时间', trigger: 'change'}]"
        >
            <el-input-number
                v-model="formData.timeout"
                placeholder="请输入超时时间，秒"
                @input="updateParent"
            />
        </el-form-item>
        <el-form-item
            v-if="formData.enabled"
            label="机器人"
            :prop="`${parentName}.robot`"
            label-width="150"
            :rules="[{required: true, message: '请选择机器人', trigger: 'change'}]"
        >
            <robot-select
                v-model="formData.robot"
                @change="updateParent"
            />
        </el-form-item>
        <el-form-item
            v-if="formData.enabled"
            label="群号"
            :prop="`${parentName}.groupid`"
            label-width="150"
            :rules="[{required: true, message: '请输入报警群号', trigger: 'change'}]"
        >
            <el-input
                v-model="formData.groupid"
                placeholder="报警群号"
                @input="updateParent"
            />
        </el-form-item>
    </div>
</template>

<script>

import {watch, ref} from 'vue';
import RobotSelect from '../../common/RobotSelect';

export default {
    name: 'AlarmConfig',
    components: {
        RobotSelect
    },
    props: {
        modelValue: {
            type: Object,
            default: () => ({})
        },
        parentName: {
            type: String,
            default: '',
            required: true
        }
    },
    emits: ['update:modelValue'],
    setup(props, {emit}) {
        const formData = ref({...props.modelValue});
        watch(
            () => props.modelValue,
            (newVal) => {
                formData.value = {...newVal};
            }
        );

        const updateParent = () => {
            emit('update:modelValue', formData.value);
        };

        const disabledSeconds = (hour, minute) => {
            let result = [];
            for (let i = 1; i <= 59; i++) {
                result.push(i);
            }
            return result;

        };

        const disabledMinutes = (hour) => {
            let result = [];
            for (let i = 1; i <= 59; i++) {
                if (i % 5 !== 0) {
                    result.push(i);
                }
            }
            return result;
        };

        return {
            formData,
            disabledSeconds,
            updateParent,
            disabledMinutes
        };
    }
};
</script>