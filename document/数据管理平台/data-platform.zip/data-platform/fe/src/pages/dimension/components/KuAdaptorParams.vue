<template>
    <div>
        <el-form-item
            label-width="80"
            label-position="left"
            style="width: 500px;"
            label="URL"
            :prop="`${parentName}.url`"
            :rules="[{required: true, message: '请输入URL', trigger: 'change'}]"
        >
            <el-input
                v-model="formData.url"
                @input="updateParent"
            />
        </el-form-item>
        <el-form-item
            label="Token"
            label-width="80"
            label-position="left"
            :prop="`${parentName}.token`"
            :rules="[{required: true, message: '请输入Token', trigger: 'change'}]"
        >
            <el-input
                v-model="formData.token"
                @input="updateParent"
            />
        </el-form-item>
    </div>
</template>

<script>
import {defineComponent, watch, ref} from 'vue';

export default defineComponent({
    name: 'KuAdaptorParams',
    components: {
    },

    props: {
        modelValue: {
            type: Object,
            required: true,
        },
        parentName: {
            type: String,
            required: true,
        }
    },
    emits: ['update:modelValue'],
    setup(props, {emit}) {
        const formData = ref({...props.modelValue});

        watch(
            () => props.modelValue,
            (newVal) => {
                formData.value = {...newVal};
            }
        );

        const updateParent = () => {
            emit('update:modelValue', formData.value);
        };

        return {
            formData,
            updateParent,
        };
    },
    data() {
        return {
        };
    },
});
</script>

  <style scoped>
  /* Add your styles here */
  </style>