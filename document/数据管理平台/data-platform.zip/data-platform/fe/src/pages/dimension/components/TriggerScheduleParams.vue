<template>
    <div>
        <el-form-item
            label="触发类型"
            :prop="`${parentName}.type`"
            style="width: 500px;"
            label-width="80"
            label-position="left"
            :rules="[{required: true, message: '请选择触发类型', trigger: 'change'}]"
        >
            <el-segmented
                v-model="formData.type"
                :options="typeList"
                @change="updateParent"
            >
                <template #default="{ item }">
                    <div class="flex flex-col items-center gap-2 p-2">
                        <div>{{ item.name }}</div>
                    </div>
                </template>
            </el-segmented>
            <el-tooltip placement="top">
                <template #content>
                    1. 固定时间单次触发：每天固定时间点触发配送一次当前最新版本数据<br>2.例行触发：系统例行5分钟检测一次数据，如果有变更，自动触发配送
                </template>
                <el-icon>
                    <QuestionFilled />
                </el-icon>
                <el-button>Top center</el-button>
            </el-tooltip>
            <!-- <el-select
                v-model="formData.type"
                style="width: 240px"
                placeholder="请选择触发类型"
                @change="updateParent"
            >
                <el-option
                    v-for="item in typeList"
                    :key="item.value"
                    :value="item.value"
                    :label="item.name"
                />
            </el-select> -->
        </el-form-item>
        <!-- <div v-if="formData.type==='period'">
            当前例行周期5分钟
        </div> -->
        <el-form-item
            v-if="formData.type === 'fixedTime'"
            style="width: 500px;"
            label-width="80"
            label-position="left"
            label="固定时间"
            :prop="`${parentName}.fixedTime`"
            :rules="[{required: true, message: '请选择触发时间', trigger: 'change'}]"
        >
            <el-time-picker
                v-model="formData.fixedTime"
                :disabled-seconds="disabledSeconds"
                :disabled-minutes="disabledMinutes"
                value-format="HH:mm"
                @change="updateParent"
            />
        </el-form-item>
    </div>
</template>

<script>
import {defineComponent, watch, ref} from 'vue';

export default defineComponent({
    name: 'TriggerScheduleParams',
    components: {
    },

    props: {
        modelValue: {
            type: Object,
            required: true,
        },
        parentName: {
            type: String,
            required: true,
        }
    },
    emits: ['update:modelValue'],
    setup(props, {emit}) {
        const formData = ref({...props.modelValue});

        const disabledSeconds = (hour, minute) => {
            let result = [];
            for (let i = 1; i <= 59; i++) {
                result.push(i);
            }
            return result;

        };
        const disabledMinutes = (hour) => {
            let result = [];
            for (let i = 1; i <= 59; i++) {
                if (i % 5 !== 0) {
                    result.push(i);
                }
            }
            return result;
        };
        watch(
            () => props.modelValue,
            (newVal) => {
                formData.value = {...newVal};
            }
        );

        const updateParent = () => {
            emit('update:modelValue', formData.value);
        };

        return {
            disabledSeconds,
            disabledMinutes,
            formData,
            updateParent,
        };
    },
    data() {
        return {
            typeList: [
                {
                    name: '固定时间单次触发',
                    value: 'fixedTime'
                },
                {
                    name: '例行触发',
                    value: 'period'
                }
            ],
            periodTimeList: [
                {
                    name: '每分钟',
                    value: 'minute'
                },
                {
                    name: '每小时',
                    value: 'hour'
                }
            ]
        };
    },
});
</script>

  <style scoped>
  /* Add your styles here */
  </style>