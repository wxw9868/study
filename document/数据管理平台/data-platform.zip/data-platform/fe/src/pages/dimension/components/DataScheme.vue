<template>
    <div>
        <json-editor-vue
            v-model="schemaData"
            mode="text"
            :stringified="false"
        />
    </div>
</template>

<script>
import JsonEditorVue from 'json-editor-vue';

import {ref, watch} from 'vue';

export default {
    name: 'DataScheme',
    components: {
        JsonEditorVue
    },
    props: {
        modelValue: {
            type: Object,
            required: true,
        },
    },
    emits: ['update:modelValue'],
    setup(props, {emit}) {
        const schemaData = ref(props.modelValue);

        watch(
            () => props.modelValue,
            (newVal) => {
                schemaData.value = newVal;
            },
            {immediate: true, deep: true}
        );

        watch(
            schemaData,
            (newVal) => {
                emit('update:modelValue', schemaData.value);
            },
            {immediate: true, deep: true}
        );

        return {
            schemaData
        };
    },
};
</script>