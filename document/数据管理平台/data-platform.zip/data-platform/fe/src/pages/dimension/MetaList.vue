<template>
    <div>
        <el-container>
            <sidebar :items="sidebarItems" />
            <el-main
                class="sidebar-main"
                style="padding: 0;"
            >
                <el-row>
                    <breadcrumb :data="breadcrumbItems" />
                </el-row>
                <el-row class="filter-row">
                    <el-form
                        :inline="true"
                        :model="filterForm"
                    >
                        <el-form-item label="查询">
                            <el-input
                                v-model="filterForm.word"
                                style="width: 300px;"
                                placeholder="请输入维表名称或者中文名称进行模糊检索"
                                @input="delayLoad"
                            />
                        </el-form-item>
                    </el-form>
                </el-row>
                <el-row class="button-row">
                    <el-button
                        type="success"
                        @click="addData"
                    >
                        <el-icon class="el-icon--left">
                            <Plus />
                        </el-icon>
                        添加维表
                    </el-button>
                </el-row>
                <el-row>
                    <el-table
                        v-loading="loading"
                        :data="jobData"
                        empty-text="暂无数据"
                        border
                        style="width: 100%;"
                    >
                        <el-table-column
                            prop="id"
                            label="维表ID"
                        />
                        <el-table-column
                            prop="name"
                            label="维表名称"
                        />
                        <el-table-column
                            prop="chname"
                            label="维表中文名称"
                        />
                        <el-table-column
                            prop="version"
                            label="最新版本"
                        />
                        <el-table-column
                            prop="onlineVersion"
                            label="线上版本"
                        />
                        <el-table-column
                            prop="creator"
                            width="180px"
                            label="创建人"
                        />
                        <el-table-column
                            label="操作"
                            width="230px"
                        >
                            <template #default="scope">
                                <div>
                                    <el-button
                                        type="primary"
                                        size="small"
                                        @click="editMeta(scope.row.name)"
                                    >
                                        编辑
                                    </el-button>
                                    <el-button
                                        type="success"
                                        size="small"
                                        @click="editData(scope.row.name, scope.row.id)"
                                    >
                                        编辑数据
                                    </el-button>
                                    <el-button
                                        v-if="scope.row.targetType === 'afs'"
                                        type="warning"
                                        size="small"
                                        @click="viewMetaStructure(scope.row)"
                                    >
                                        表结构
                                    </el-button>
                                </div>
                            </template>
                        </el-table-column>
                    </el-table>
                    <el-pagination
                        v-model:current-page="page"
                        v-model:page-size="size"
                        :page-sizes="[10, 20, 50, 100]"
                        :total="total"
                        background
                        layout="sizes, prev, pager, next"
                        @size-change="loadData"
                        @current-change="loadData"
                    />
                </el-row>
            </el-main>

            <el-dialog
                v-model="dialogTableVisible"
                title="表结构"
                width="800"
            >
                <table-structure
                    :schema="curMetaSchema"
                    :target-params="curTargetParams"
                    :meta-name="curMetaName"
                />
            </el-dialog>
        </el-container>
    </div>
</template>

<script>
import Breadcrumb from '../partial/Breadcrumb';
import Sidebar from '../partial/SideBar';
import config from './config';

import * as dimensionApi from '../../apis/dimension';

import {useDateFormatter} from '../common/date';
import TableStructure from './components/TableStructure.vue';

import _ from 'lodash';

export default {
    components: {
        Breadcrumb,
        Sidebar,
        TableStructure
    },
    beforeRouteEnter(to, from, next) {
        next(vm => {
            vm.init();
        });
    },
    setup() {
        const dateFormatter = useDateFormatter();
        return {dateFormatter};
    },
    data: function () {
        let sidebar = _.cloneDeep(config.sidebar);
        return {
            timeoutSign: null,
            loading: true,
            jobData: [],
            filterForm: {
                word: ''
            },
            onlyUser: '',
            sidebarItems: sidebar,
            breadcrumbItems: [],
            page: 1,
            size: 10,
            total: 10,
            echo: 0,
            curMetaSchema: {},
            curTargetParams: {},
            curMetaName: '',
            dialogTableVisible: false,
        };
    },
    computed: {
    },
    methods: {
        init() {
            let meta = this.getMeta(this.$route);
            this.onlyUser = meta.onlyUser;
            this.page = 1;
            this.breadcrumbItems = meta.breadcrumb;
            this.loadData();
        },
        loadData() {
            this.loading = true;
            this.echo++;
            let query = {
                pdb: this.$route.query.pdb,
                search: this.filterForm.word,
                page: this.page,
                size: this.size,
                echo: this.echo
            };
            if (this.onlyUser) {
                query.owner = this.user.username;
            }
            dimensionApi.meta.get(query).then(res => {
                if (res.status === 0 && res.echo === this.echo) {
                    this.jobData = res.data;
                    this.total = res.total;
                }
                this.loading = false;
            });
        },
        delayLoad() {
            if (this.timeoutSign != null) {
                clearTimeout(this.timeoutSign);
            }
            this.timeoutSign = setTimeout(() => {
                this.timeoutSign = null;
                this.page = 1;
                this.loadData();
            }, 300);
        },
        addData() {
            this.$router.push('/dimension/edit').catch(() => {});
        },
        editMeta(name) {
            this.$router.push({
                path: '/dimension/edit',
                query: {
                    name: name
                }
            }).catch(() => {});
        },
        editData(name, id) {
            this.$router.push({
                path: '/dimension/simpletext/edit',
                query: {
                    name: name,
                    id: id
                }}).catch(() => {});
        },
        viewMetaStructure(row) {
            this.dialogTableVisible = true;
            this.curMetaSchema = row.dataSchema;
            this.curTargetParams = row.targetParams;
            this.curMetaName = row.name;
        },
        getMeta(route) {
            let breadcrumb = _.cloneDeep(config.breadcrumb);
            let onlyUser = route.matched.some(record => record.meta.onlyUser);

            breadcrumb.push({
                path: '/dimension/list',
                title: '维表列表'
            });
            return {
                onlyUser,
                breadcrumb
            };
        }
    }
};
</script>
