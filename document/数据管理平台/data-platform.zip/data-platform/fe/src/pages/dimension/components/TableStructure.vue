<template>
    <div>
        <el-tabs
            type="border-card"
            class="structure-tabs"
        >
            <el-tab-pane>
                <template #label>
                    <span class="custom-tabs-label">
                        <el-icon><calendar /></el-icon>
                        <span>表结构</span>
                    </span>
                </template>
                <el-table
                    :data="schemaRowTable"
                    height="500"
                    style="width: 100%"
                >
                    <el-table-column
                        prop="column"
                        label="列名"
                        width="180"
                    />
                    <el-table-column
                        prop="type"
                        label="类型"
                    />
                    <el-table-column
                        prop="label"
                        label="列名（title)"
                        width="180"
                    />
                    <el-table-column
                        prop="comment"
                        label="备注（description)"
                        width="180"
                    />
                </el-table>
            </el-tab-pane>
            <el-tab-pane>
                <template #label>
                    <span class="custom-tabs-label">
                        <el-icon><copy-document /></el-icon>
                        <span>建表语句</span>
                    </span>
                </template>
                <pre>{{ createTableSql }}</pre>
                <el-button
                    type="success"
                    text
                    bg
                    @click="copy"
                >
                    Copy
                </el-button>
            </el-tab-pane>
        </el-tabs>
    </div>
</template>

<script>

import {ref, watchEffect} from 'vue';
import {Calendar, CopyDocument} from '@element-plus/icons-vue';
import useClipboard from 'vue-clipboard3';
import {ElMessage} from 'element-plus';

export default {
    name: 'TableStructure',
    components: {
        Calendar,
        CopyDocument
    },
    props: {
        schema: {
            type: Object,
            default: () => ({})
        },
        metaName: {
            type: String,
            default: ''
        },
        targetParams: {
            type: Object,
            default: () => ({})
        }
    },
    setup(props, {emit}) {
        const schemaRowTable = ref([]);
        const createTableSql = ref('');
        const typeMap = {
            string: 'string',
            integer: 'int',
            number: 'float',
            bool: 'boolean',
            boolean: 'boolean',
            object: 'MAP<STRING, STRING>',
            array: 'ARRAY<STRING>'
        };

        const {toClipboard} = useClipboard();

        const copy = async () => {
            try {
                await toClipboard(createTableSql.value);
                ElMessage.success('复制成功');
            } catch (e) {
                ElMessage.error('复制失败');
            }
        };
        watchEffect(() => {
            let order = Object.keys(props.schema.properties);
            if (props.schema.order) {
                order = props.schema.order;
            }
            schemaRowTable.value = Object.values(order).map((key) => ({
                column: key,
                label: props.schema.properties[key].title || key,
                comment: props.schema.properties[key].description || '',
                type: props.schema.properties[key].hiveType || typeMap[props.schema.properties[key].type] || ''
            }));
        });

        watchEffect(() => {
            let columns = schemaRowTable.value.map(item => {
                return `    ${item.column} ${item.type} comment "${item.label}"`;
            });
            let columnSql = columns.join(',\n');
            let tableName = props.schema.tableName || props.metaName;
            createTableSql.value = `
CREATE or REPLACE TEMPORARY VIEW ${tableName} (
${columnSql}
) USING CSV OPTIONS (
  hadoop.job.ugi = '${props.targetParams.ugi}',
  sep = '\\t',
  path = '${props.targetParams.cluster}/${props.targetParams.path}'
`;
        });

        return {
            schemaRowTable,
            createTableSql,
            copy
        };
    }
};
</script>

<style>

.structure-tabs > .el-tabs__content {
  /* padding: 32px; */
  color: #6b778c;
  /* font-size: 32px;
  font-weight: 600; */
}
.structure-tabs .custom-tabs-label .el-icon {
  vertical-align: middle;
}
.structure-tabs .custom-tabs-label span {
  vertical-align: middle;
  margin-left: 4px;
}
</style>