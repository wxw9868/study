/*
 * @Author: yandong03 yandong03@baidu.com
 * @Date: 2024-07-18 11:04:08
 * @LastEditors: yandong03 yandong03@baidu.com
 * @LastEditTime: 2024-07-18 11:04:08
 * @FilePath: /fe/src/router/index.js
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
import {createRouter, createWebHistory} from 'vue-router';
import DimensionList from '../pages/dimension/MetaList';
import DimensionEdit from '../pages/dimension/MetaEdit';
import EventLogs from '../pages/dimension/EventLogs';
import DataHistory from '../pages/dimension/DataHistory';
import SimpleTextEdit from '../pages/dimension/SimpleTextEdit';
import RobotList from '../pages/manage/RobotList';
import DqcMeta from '../pages/dqc/DqcList';
import DqcEdit from '../pages/dqc/DqcEdit';
import ScienceTask from '../pages/science/AbTest.vue';
import ScienceTaskHistory from '..//pages/science/TaskHistory';
import TaskResult from '../pages/science/TaskResult';
import AbTest from '../pages/science/AbTestResult';
import PackageFeature from '../pages/feature/Feature.vue';
import UserSelect from '../pages/feature/UserSelect.vue';
import FeatureEdit from '../pages/feature/FeatureEdit.vue';
import UserAnalysis from '../pages/feature/UserAnalysis.vue';
import SavePoint from '../pages/manage/Savepoint.vue';
import AsyncTaskResult from '../pages/manage/TaskResult';

import DqcConnector from '../pages/dqc/DqcConnector.vue';
import ConnectorEdit from '../pages/dqc/ConnectorEdit.vue';

import DqcModel from '../pages/dqc/DqcModel.vue';
import ModelEdit from '../pages/dqc/ModelEdit.vue';
import DqcJob from '../pages/dqc/JobList.vue';
import JobEdit from '../pages/dqc/JobEdit.vue';

import DqcTask from '../pages/dqc/TaskList.vue';
import TaskEdit from '../pages/dqc/TaskEdit.vue';

import DqcRule from '../pages/dqc/DqcRule';
import RuleEdit from '../pages/dqc/RuleEdit';

import DqcResultView from '../pages/dqc/ResultView';

const router = createRouter({
    history: createWebHistory(import.meta.env.BASE_URL),
    routes: [
        {
            path: '/',
            name: 'home',
            component: DimensionList
        },
        {
            path: '/dimension/list',
            name: 'dimensionList',
            component: DimensionList
        },
        {
            path: '/dimension/edit',
            name: 'dimensionEdit',
            component: DimensionEdit
        },
        {
            path: '/dimension/eventlogs',
            name: 'eventLogs',
            component: EventLogs
        },
        {
            path: '/dimension/history',
            name: 'dimensionHistory',
            component: DataHistory
        },
        {
            path: '/dimension/simpletext/edit',
            name: 'simpleTextEdit',
            meta: {
                editable: true
            },
            component: SimpleTextEdit
        },
        {
            path: '/manage/robotlist',
            name: 'robotList',
            component: RobotList
        },
        {
            path: '/manage/taskresult',
            name: 'asyncTaskResult',
            component: AsyncTaskResult
        },
        {
            path: '/dqc/list',
            name: 'DqcMeta',
            component: DqcMeta
        },
        {
            path: '/dqc/edit',
            name: 'DqcEdit',
            component: DqcEdit
        },
        {
            path: '/dqc/connector_list',
            name: 'DqcConnector',
            component: DqcConnector
        },
        {
            path: '/dqc/connector_edit',
            name: 'ConnectorEdit',
            component: ConnectorEdit
        },
        {
            path: '/dqc/model_list',
            name: 'DqcModel',
            component: DqcModel
        },
        {
            path: '/dqc/model_edit',
            name: 'ModelEdit',
            component: ModelEdit
        },
        {
            path: '/dqc/job_list',
            name: 'DqcJob',
            component: DqcJob
        },
        {
            path: '/dqc/job_edit',
            name: 'JobEdit',
            component: JobEdit
        },
        {
            path: '/dqc/task_list',
            name: 'DqcTask',
            component: DqcTask
        },
        {
            path: '/dqc/task_children_list',
            name: 'DqcChildrenTask',
            component: DqcTask
        },
        {
            path: '/dqc/task_edit',
            name: 'TaskEdit',
            component: TaskEdit,
        },
        {
            path: '/dqc/rule_list',
            name: 'DqcRule',
            component: DqcRule
        },
        {
            path: '/dqc/rule_edit',
            name: 'RuleEdit',
            component: RuleEdit,
        },
        {
            path: '/dqc/result_view',
            name: 'ResultView',
            component: DqcResultView,
        },
        {
            path: '/manage/savepoint',
            name: 'SavePoint',
            meta: {
                type: 'savepoint',
                breadcrumb: {
                    path: '/manage/savepoint',
                    title: '保存点'
                },
            },
            component: SavePoint,
        },
        {
            path: '/science/abtest',
            name: 'AbTest',
            meta: {
                type: 'abtest',
                breadcrumb: {
                    path: '/science/abtest',
                    title: '虚拟AB'
                },
            },
            component: ScienceTask
        },
        {
            path: '/science/taskhistory',
            name: 'TaskHistory',
            component: ScienceTaskHistory
        },
        {
            path: '/science/taskresult',
            name: 'TaskResult',
            component: TaskResult
        },
        {
            path: '/science/abestresult',
            name: 'AbTestResult',
            component: AbTest
        },
        {
            path: '/feature/feature',
            name: 'PackageFeature',
            component: PackageFeature
        },
        {
            path: '/feature/user_select',
            name: 'PackageSelect',
            component: UserSelect
        },
        {
            path: '/feature/edit',
            name: 'FeatureEdit',
            meta: {
                editable: true
            },
            component: FeatureEdit
        },
        {
            path: '/feature/view',
            name: 'FeatureView',
            meta: {
                editable: false
            },
            component: FeatureEdit
        },
        {
            path: '/feature/analysis',
            name: 'FeatureAnalysis',
            meta: {
            },
            component: UserAnalysis
        },
        {
            path: '/feature/user_select/list',
            name: 'UserSelectList',
            meta: {
                type: 'user_select',
                breadcrumb: {
                    path: '/feature/user_select/list',
                    title: '用户包圈选'
                },
            },
            component: UserSelect
        },
    ]
});

export default router;


