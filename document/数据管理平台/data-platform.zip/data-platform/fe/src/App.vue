<template>
    <div class="container">
        <el-container>
            <el-header style="padding: 0;">
                <main-header />
            </el-header>
            <el-main style="padding: 0; height: 100%;">
                <router-view class="body" />
            </el-main>
        </el-container>
    </div>
</template>

<style lang="less">
/** css reset */
html {
    color: #000;
    background: #fff;
}

body,
div,
dl,
dt,
dd,
ul,
ol,
li,
h1,
h2,
h3,
h4,
h5,
h6,
pre,
code,
form,
fieldset,
legend,
input,
textarea,
p,
blockquote
{
    margin: 0;
    padding: 0;
    // font-family: "Helvetica Neue", Helvetica, "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", sans-serif;
    box-sizing: border-box;
}

// table {
//     border-collapse: collapse;
//     border-spacing: 0;
// }

fieldset,
img {
    border: 0;
}

// address,
// caption,
// cite,
// code,
// dfn,
// em,
// strong,
// th,
// var {
//     font-style: normal;
//     font-weight: normal;
// }

// ol,
// ul {
//     list-style: none;
// }

caption,
th {
    text-align: left;
}

// h1,
// h2,
// h3,
// h4,
// h5,
// h6 {
//     font-size: 100%;
//     font-weight: normal;
// }

q::before,
q::after {
    content: '';
}

abbr,
acronym {
    border: 0;
    font-variant: normal;
}

sup {
    vertical-align: text-top;
}

sub {
    vertical-align: text-bottom;
}

input,
textarea,
select {
    font-family: inherit;
    font-size: inherit;
    *font-size: 100%;
    font-weight: inherit;
}

legend {
    color: #000;
}

body {
    min-height: 100%;
}

/** css reset end */

html,
body,
.container {
    height: 100%;
}

.body {
    height: 100%;
}

a {
    text-decoration: none;
}

.el-container {
    height: 100%;
}

.el-aside {
    height: 100%;
}

.sidebar-main {
    margin: 0 10px;
}

.filter-row {
    border: 1px solid #d7dae2;
    border-radius: 4px;
    padding: 20px 20px 0 20px;
}

.box-row {
    border: 1px solid #d7dae2;
    border-radius: 4px;
    padding: 20px 20px 0 20px;
}

.button-row {
    margin: 10px 0;
}

.el-form-item.is-error {
    .input-tag-wrapper,
    .input-tag-wrapper:focus {
        border-color: #f56c6c;
    }
}

.ejob-form-inline {
    margin-bottom: 5px;

    .el-form-item {
        display: inline-block;
        margin-right: 10px;
        vertical-align: top;
    }
}

.pagination {
    margin: 10px 0;
    text-align: right;
}
</style>
