<script setup>
import TheWelcome from '../components/TheWelcome.vue';
</script>

<template>
    <main>
        <the-welcome />
    </main>
</template>
