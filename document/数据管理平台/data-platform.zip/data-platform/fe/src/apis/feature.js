import {ResourceBase} from './base';

const module = 'feature';

export const userFeature = new ResourceBase(module, 'user_feature');
