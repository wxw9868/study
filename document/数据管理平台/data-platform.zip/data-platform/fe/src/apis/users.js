import {ResourceBase} from './base';

const module = 'users';
export const currentUser = new ResourceBase(module, 'current');
