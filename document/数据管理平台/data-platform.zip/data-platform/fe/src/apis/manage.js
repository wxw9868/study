/**
 * @file meta.js
 */

import {ResourceBase} from './base';

const module = 'manage';

export const meta = new ResourceBase(module, 'meta');
export const asyncTask = new ResourceBase(module, 'async_task');

