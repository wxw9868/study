/**
 * @file meta.js
 */

import {ResourceBase} from './base';

const module = 'dimension';

class History extends ResourceBase {
    publishData(data) {
        return this.fetch(`/api/${this.module}/${this.resource}/publish_data`, {
            method: 'POST',
            data
        });
    }
    latestData(params) {
        return this.fetch(`/api/${this.module}/${this.resource}/latest_data`, {
            method: 'GET',
            params
        });
    }
    versionData(params) {
        return this.fetch(`/api/${this.module}/${this.resource}/version_data`, {
            method: 'GET',
            params
        });
    }
    nearestData(params) {
        return this.fetch(`/api/${this.module}/${this.resource}/nearest_data`, {
            method: 'GET',
            params
        });
    }
}


class Meta extends ResourceBase {
    deliverData(params) {
        return this.fetch(`/api/${this.module}/${this.resource}/deliver_data`, {
            method: 'GET',
            params,
        });
    }
    parseText(data) {
        return this.fetch(`/api/${this.module}/${this.resource}/parse_text`, {
            method: 'POST',
            data,
        });
    }
}


export const meta = new Meta(module, 'meta');
export const history = new History(module, 'history');
export const eventLogs = new ResourceBase(module, 'event_logs');

