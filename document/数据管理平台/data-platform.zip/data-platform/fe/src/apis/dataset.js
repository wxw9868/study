/**
 * @file meta.js
 */

import {ResourceBase} from './base';

const module = 'dataset';

export const meta = new ResourceBase(module, 'meta');

