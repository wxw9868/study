/**
 * @file meta.js
 */

import {ResourceBase} from './base';

const module = 'function';

class Meta extends ResourceBase {
    functionSetData(params) {
        return this.fetch(`/api/${this.module}/${this.resource}/function_set_data`, {
            method: 'GET',
            params,
        });
    }
    functionData(params) {
        return this.fetch(`/api/${this.module}/${this.resource}/function_data`, {
            method: 'GET',
            params,
        });
    }
}


export const meta = new Meta(module, 'meta');

