/**
 * @file base.js
 *
 *
 */
import {ElMessage} from 'element-plus';

export function fetchJson(url, {method = 'GET', data, params} = {}) {
    let init = {
        method,
        credentials: 'include',
        cache: 'no-cache',
        headers: new Headers({
            'Content-Type': 'application/json'
        })
    };
    if (data) {
        init.body = JSON.stringify(data);
    }
    if (params) {
        let query = Object.keys(params).map(key => `${encodeURIComponent(key)}=${encodeURIComponent(params[key])}`)
            .join('&')
            .replace(/%20/g, '+');
        if (query) {
            url = `${url}?${query}`;
        }
    }
    return fetch(url, init).then(function (response) {
        if (!response.ok) {
            return new Promise((resolve, reject) => {
                let res = {
                    status: response.status
                };
                if (response.status >= 500) {
                    res.message = '服务器处理错误';
                    reject(res);
                } else {
                    response.json().then(data => {
                        res.message = data;
                        reject(res);
                    });
                }
            });
        }
        return response.json();
    });
}


export class ResourceFetch {
    constructor(module, resource) {
        this.module = module;
        this.resource = resource;
        this.url = `/api/${module}/${resource}`;
    }
    fetch(url, {method = 'GET', data, params} = {}, catchException = true, catchStatusError = true) {
        let promise =  fetchJson(url, {
            method,
            data,
            params
        });
        if (catchStatusError) {
            promise = promise.then(res => {
                if (res.status !== 0) {
                    ElMessage({
                        title: '请求错误',
                        message: res.message,
                        type: 'warning',
                        duration: 30000
                    });
                }
                return res;
            });
        }
        if (catchException) {
            promise = promise.catch(err => {
                ElMessage({
                    title: '请求异常',
                    message: JSON.stringify(err.message),
                    type: 'error',
                    duration: 30000
                });
                return new Promise((resolve, reject) => {
                    reject(err);
                });
            });
        }
        return promise;
    }
}


export class ResourceBase extends ResourceFetch {
    getOne(pk, catchException, catchStatusError) {
        let url = `${this.url}/${pk}`;
        return this.fetch(url, {
            method: 'GET'
        }, catchException, catchStatusError);
    }
    get(params, catchException, catchStatusError) {
        return this.fetch(this.url, {
            method: 'GET',
            params
        }, catchException, catchStatusError);
    }
    post(data, catchException, catchStatusError) {
        return this.fetch(this.url, {
            method: 'POST',
            data
        }, catchException, catchStatusError);
    }
    put(pk, data, catchException, catchStatusError) {
        let url = `${this.url}/${pk}`;
        return this.fetch(url, {
            method: 'PUT',
            data
        }, catchException, catchStatusError);
    }
    delete(params, catchException, catchStatusError) {
        return this.fetch(this.url, {
            method: 'DELETE',
            params
        }, catchException, catchStatusError);
    }
    patch(pk, data, catchException, catchStatusError) {
        let url = `${this.url}/${pk}`;
        return this.fetch(url, {
            method: 'PATCH',
            data
        }, catchException, catchStatusError);
    }
}
