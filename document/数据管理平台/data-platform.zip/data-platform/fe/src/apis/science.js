import {ResourceBase} from './base';

const module = 'science';

class ScienceTask extends ResourceBase {
    setSuccess(params) {
        return this.fetch(`/api/${this.module}/${this.resource}/set_success`, {
            method: 'GET',
            params,
        });
    }
    GetAbTestResult(params) {
        return this.fetch(`/api/${this.module}/${this.resource}/get_abtest_result`, {
            method: 'GET',
            params,
        });
    }
}

export const task = new ScienceTask(module, 'task');
export const taskHistory = new ResourceBase(module, 'task_history');