/**
 * @file meta.js
 */

import {ResourceBase} from './base';

const module = 'dqc';


class Meta extends ResourceBase {
    parseSql(data) {
        return this.fetch(`/api/${this.module}/${this.resource}/parse_sql`, {
            method: 'POST',
            data,
        });
    }
    checkFormula(data) {
        return this.fetch(`/api/${this.module}/${this.resource}/check_formula`, {
            method: 'POST',
            data,
        });
    }
}

class Task extends ResourceBase {
    submitTask(id) {
        return this.fetch(`/api/${this.module}/${this.resource}/submit/${id}`, {
            method: 'POST',
        });
    }
    taskWithChildren(ids) {
        return this.fetch(`/api/${this.module}/${this.resource}/task_with_children`, {
            method: 'GET',
            params: {
                id: ids
            }
        });
    }
}

export const meta = new Meta(module, 'meta');

export const connector = new ResourceBase(module, 'connector');
export const model = new ResourceBase(module, 'model');
export const job = new ResourceBase(module, 'job');
export const task = new Task(module, 'task');
export const rule = new ResourceBase(module, 'rule');


