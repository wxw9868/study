module.exports = {
    extends: [
        '@ecomfe/stylelint-config/baidu/default',
    ]
};