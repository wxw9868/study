/*
 * @Description: eslint配置文件
 * @FilePath: .eslintrc.js
 */
module.exports = {
    root: true,
    env: {
        node: true
    },
    extends: [
        '@ecomfe/eslint-config/baidu/default',
        'plugin:vue/vue3-essential',
        'eslint:recommended',
        'plugin:vue/vue3-strongly-recommended',
        'plugin:vue/strongly-recommended',
        'plugin:vue/vue3-recommended',
        'plugin:vue/recommended'
    ],
    parserOptions: {
        ecmaVersion: 2020
    },
    rules: {
        'vue/component-name-in-template-casing': ['error', 'kebab-case'],
        // 'vue/max-attributes-per-line': [
        //     'error',
        //     {
        //         singleline: 1,
        //         multiline: {
        //             max: 1,
        //             allowFirstLine: false
        //         }
        //     }
        // ],
        'vue/html-indent': [
            'error',
            4,
            {
                attribute: 1,
                baseIndent: 1,
                closeBracket: 0,
                alignAttributesVertically: true,
                ignores: []
            }
        ],
        'vue/html-self-closing': [
            'error',
            {
                html: {
                    void: 'never',
                    normal: 'never',
                    component: 'always'
                },
                svg: 'always',
                math: 'always'
            }
        ],
        'vue/html-closing-bracket-spacing': [
            'error',
            {
                startTag: 'never',
                endTag: 'never',
                selfClosingTag: 'always'
            }
        ],
        indent: ['error', 4, {flatTernaryExpressions: false, SwitchCase: 1}],
        // 要求使用骆驼拼写法 https://cn.eslint.org/docs/rules/camelcase
        camelcase: ['error'],
        'no-console': process.env.NODE_ENV === 'production' ? 'warn' : 'off',
        'no-debugger': process.env.NODE_ENV === 'production' ? 'warn' : 'off',
        '@typescript-eslint/no-explicit-any': ['off'],
        '@typescript-eslint/no-var-requires': 0,
        '@typescript-eslint/explicit-module-boundary-types': 'off',
        '@typescript-eslint/no-unused-vars': ['off'],
        '@typescript-eslint/no-non-null-assertion': ['off'],
        '@typescript-eslint/ban-types': ['off'],
        'vue/no-v-model-argument': ['off'],
        'vue/no-unused-refs': ['error'],
        'vue/max-attributes-per-line': ['error', {
            'singleline': 1,
            'multiline': 1
        }]
    },
    globals: {
        BMap: true,
        BMapLib: true
    }
};