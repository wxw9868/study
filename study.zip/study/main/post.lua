wrk.method = "POST"
wrk.headers["Authorization"] = "Basic Zm9vOmJhcg=="
wrk.headers["Content-Type"] = "application/json"
wrk.body ='{"value": "bar"}'
