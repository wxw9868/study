package readwritefile

import "testing"

func TestReadWriteFile(t *testing.T) {
	ReadWriteFile()
}
