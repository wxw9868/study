package practise

import (
	"testing"
)

func TestPoint(t *testing.T) {
	Point()
}

func TestPrintOddAndEven(t *testing.T) {
	PrintOddAndEven()
}

func TestStudyContext(t *testing.T) {
	StudyContext()
}
